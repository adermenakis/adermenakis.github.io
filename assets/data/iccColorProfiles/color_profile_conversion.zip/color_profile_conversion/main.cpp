/**
 * Simple QtOpenGL Sample
 * tuomo.hirvonen @ digia 2010
 *
 */


#include <QtGui/QApplication>
#include "glwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    GLWindow w;
#ifndef Q_WS_MAEMO_5
    w.showMaximized();
#else
    w.showFullScreen();         // Show full screen in Maemo
#endif

    return a.exec();
}
