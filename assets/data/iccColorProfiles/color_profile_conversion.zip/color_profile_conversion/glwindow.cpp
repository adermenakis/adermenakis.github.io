/**
 * Simple QtOpenGL Sample
 * tuomo.hirvonen @ digia 2010
 *
 */


#include "glwindow.h"
#include <ctime>
#include <GLES2/gl2.h>
#include "plugin.h"
#include <lcms2.h>
#include <QFile>

float vertexData[] =
{
    -1, -1, 0, 0,
     1, -1, 1, 0,
    -1,  1, 0, 1,
     1,  1, 1, 1
};

unsigned short indices[] =
{
	0, 1, 2, 2, 1, 3
};

const char * vertexShaderStr =
"attribute vec4 position;\n"
"varying mediump vec2 v_texCoord;\n"
"attribute vec2 texCoord;\n"
"void main(){\n"
  "gl_Position = position;\n"
  "v_texCoord = texCoord;}";

const char * fragmentShaderStr =
"precision mediump float;\n"
"#ifdef	USE_MATRIX\n"
"uniform mat3 transform;\n"
"uniform vec3 offset;\n"
"#endif	// USE_MATRIX\n"
"\n"
"uniform sampler2D screenTexture;\n"
"#if defined(USE_LUT_IN) || defined(USE_LUT_OUT)\n"
"uniform vec4 scaleOffset;\n"
"#endif	//  defined(USE_LUT_IN) || defined(USE_LUT_OUT)\n"
"#ifdef	USE_LUT_IN\n"
"uniform sampler2D lutIn;\n"
"#endif	// USE_LUT_IN\n"
"#ifdef	USE_LUT_OUT\n"
"uniform sampler2D lutOut;\n"
"#endif	// USE_LUT_OUT\n"
"\n"
"varying mediump vec2 v_texCoord;\n"
"\n"
"void main()\n"
"{\n"
"	vec4 color;\n"
"\n"
"	color = texture2D(screenTexture, v_texCoord);\n"
"\n"
"#ifdef	USE_LUT_IN\n"
"	color.r = texture2D(lutIn, vec2(color.r * scaleOffset.x + scaleOffset.y, 0)).r;\n"
"	color.g = texture2D(lutIn, vec2(color.g * scaleOffset.x + scaleOffset.y, 0)).g;\n"
"	color.b = texture2D(lutIn, vec2(color.b * scaleOffset.x + scaleOffset.y, 0)).b;\n"
"#endif	// USE_LUT_IN\n"
"#ifdef	USE_SQR_IN\n"
"	color.rgb *= color.rgb;\n"
"#endif	// USE_SQR_IN\n"
"\n"
"#ifdef	USE_MATRIX\n"
"	color.rgb = transform * color.rgb + offset;\n"
"#endif	// USE_MATRIX\n"
"\n"
"#ifdef	USE_LUT_OUT\n"
"	color.r = texture2D(lutOut, vec2(color.r * scaleOffset.z + scaleOffset.w, 0)).r;\n"
"	color.g = texture2D(lutOut, vec2(color.g * scaleOffset.z + scaleOffset.w, 0)).g;\n"
"	color.b = texture2D(lutOut, vec2(color.b * scaleOffset.z + scaleOffset.w, 0)).b;\n"
"#endif	// USE_LUT_OUT\n"
"\n"
"	gl_FragColor = color;\n"
"}\n";

GLWindow::GLWindow(QWidget *parent): QGLWidget(parent), m_texture(0), m_lutIn(0), m_lutOut(0),
    m_file("/home/user/MyDocs/FBO.csv"), m_iterationCtr(0), m_out(&m_file)
{
    if(m_file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
    }

        // Set some Qt-attributes to make the rendering faster.
    setAutoFillBackground( false );
    setAttribute (Qt::WA_OpaquePaintEvent);
    setAttribute( Qt::WA_NoSystemBackground );
    setAttribute( Qt::WA_NativeWindow );
    setAttribute( Qt::WA_PaintOnScreen, true );
    setAttribute( Qt::WA_StyledBackground,false);
    setAutoBufferSwap(false);

    qreal vals[] = {0.412383, 0.357385, 0.18048,
            0.212635, 071517, 0.072192,
            0.01933, 0.119195, 0.950528};

    m_scaleOffset = QVector4D(255.0f/256.0f, 0.5/256.0f, 255.0f/256.0f, 0.5/256.0f);
    m_transform = QMatrix3x3(vals);

    // Set the shader strings
    for (int i = 0; i < 16; ++i)
    {
        QString str;

        if ((i & 1) != 0)
        {
            if ((i & 8) != 0)
            {
                str += "#define USE_SQR_IN\n";
            }
            else
            {
                str += "#define USE_LUT_IN\n";
            }
        }

        if ((i & 2) != 0)
        {
            str += "#define USE_MATRIX\n";
        }

        if ((i & 4) != 0)
        {
            str += "#define USE_LUT_OUT\n";
        }

        str += fragmentShaderStr;

        m_ShaderSrcCode.push_back(str);
    }

    // Startup the timer which will call updateGL as fast as it can.
    m_timer = new QTimer(this);
    m_timer->setInterval(1);
    QObject::connect(m_timer, SIGNAL(timeout()), this, SLOT(updateGL()));
    m_timer->start();
}

GLWindow::~GLWindow()
{
    if (m_texture != 0)
    {
        glDeleteTextures(1, &m_texture);
    }

    if (m_lutIn != 0)
    {
        glDeleteTextures(1, &m_lutIn);
    }

    if (m_lutOut != 0)
    {
        glDeleteTextures(1, &m_lutOut);
    }
}

void GLWindow::resizeGL(int width, int height)
{
        // Reset the Gl viewport for current resolution.
    glViewport(0,0, width, height);
}

#ifndef	NDEBUG
#define CHECK_GL_ERROR()        \
       do      \
       {       \
               GLint error;    \
       \
               error = glGetError();   \
       \
               if (error != GL_NO_ERROR)       \
               {       \
                    qDebug() << "[" << __FILE__ << ":" << __LINE__ << "]" << error ; \
               }       \
       }       \
       while (false)
#else   // NDEBUG
#define CHECK_GL_ERROR()
#endif	// NDEBUG

void GLWindow::setShader(const int index)
{
    m_sampleProgram = new QGLShaderProgram(context(), this);
    m_sampleProgram->addShaderFromSourceCode(QGLShader::Vertex, vertexShaderStr);
    m_sampleProgram->addShaderFromSourceCode(QGLShader::Fragment, m_ShaderSrcCode[index]);

    CHECK_GL_ERROR();

    qDebug() << "Link " << m_sampleProgram->link();                                                         // Link our program. Its now ready for use.

    CHECK_GL_ERROR();

    qDebug() << "Log: " << m_sampleProgram->log();

    CHECK_GL_ERROR();

    m_sampleProgram->bind();

    CHECK_GL_ERROR();

    m_sampleProgram->setUniformValue("lutIn", 1);                         // Set projection to the shader
    m_sampleProgram->setUniformValue("lutOut", 2);                        // Set projection to the shader
    m_sampleProgram->setUniformValue("screenTexture", 0);                        // Set projection to the shader
    m_sampleProgram->setUniformValue("transform", m_transform);                        // Set projection to the shader
    m_sampleProgram->setUniformValue("offset", m_offset);                        // Set projection to the shader
    m_sampleProgram->setUniformValue("scaleOffset", m_scaleOffset);                        // Set projection to the shader

    CHECK_GL_ERROR();

    m_sampleProgram->release();

    CHECK_GL_ERROR();
}

void GLWindow::paintGL()
{    
    if (m_iterationCtr == 0)
    {
        m_out << std::time(0) << "\n";
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);                             // Clear the background and depth-buffer for this frame

    GLint position = m_sampleProgram->attributeLocation("position");
    GLint texCoord = m_sampleProgram->attributeLocation("texCoord");

    m_sampleProgram->bind();
    m_sampleProgram->enableAttributeArray(position);
    m_sampleProgram->enableAttributeArray(texCoord);
    m_sampleProgram->setAttributeArray(position, &vertexData[0], 2, 4 * sizeof(float));               // Set vertexarray to the shader
    m_sampleProgram->setAttributeArray(texCoord, &vertexData[2], 2, 4 * sizeof(float));               // Set vertexarray to the shader

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, m_lutOut);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, m_lutIn);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, m_texture);

#ifndef	NDEBUG
    CHECK_GL_ERROR();
    glValidateProgram(m_sampleProgram->programId());
#endif	// NDEBUG
/*
    CHECK_GL_ERROR();

    GLint length_, length;
    glGetProgramiv(m_sampleProgram->programId(), GL_INFO_LOG_LENGTH, &length);
    char *data = new char[length];
    CHECK_GL_ERROR();

    qDebug() << "Info Log Length : " << length;
    glGetProgramInfoLog(m_sampleProgram->programId(), length, &length_, data);

    qDebug() << "Info Log Length_ : " << length_;

    qDebug() << data;

    delete[] data;
*/
    CHECK_GL_ERROR();
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, indices);                   // draw the quad.
    CHECK_GL_ERROR();
    m_sampleProgram->disableAttributeArray(position);                              // Disable the program
    m_sampleProgram->disableAttributeArray(texCoord);                              // Disable the program

    m_sampleProgram->release();

    swapBuffers();                                                                  // Swap buffers manually since automatic swapping was disabled in a constructor.

    if(m_iterationCtr++ >= 1000)
    {
        m_out << std::time(0) << "\n";
        m_timer->stop();
        m_file.close();
        close();
    }
}

void GLWindow::initializeGL()
{
    glFrontFace(GL_CCW);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glEnable(GL_TEXTURE_2D);
    glClearColor(0.1f, 0.4f, 0.1f, 1.0f);                                           // Clear the background with dark-green

    qDebug() << "Registering lCMS Plugin " << register_shader_plugin();

    cmsHPROFILE hInProfile, hOutProfile;
    cmsHTRANSFORM hTransform;

    int srcProfile = TYPE_RGB_8;
    int dstProfile = TYPE_RGB_8;

    QFile d50(":/embeddedICC");
    d50.open(QIODevice::ReadOnly);
    QByteArray d50Array = d50.readAll();

    QFile d55(":/adobeRGB");
    d55.open(QIODevice::ReadOnly);
    QByteArray d55Array = d55.readAll();


    // Load the color profiles (source and destination)
    hInProfile = cmsOpenProfileFromMem(d50Array.constData(), d50Array.size());
    hOutProfile = cmsOpenProfileFromMem(d55Array.constData(), d55Array.size());

    // Create the transformation
    hTransform = cmsCreateTransform(hInProfile,
                                    srcProfile,
                                    hOutProfile,
                                    dstProfile,
                                    INTENT_PERCEPTUAL, 0);

    // Close the handles since LittleCMS requires only the
    // transformation handle
    cmsCloseProfile(hInProfile);
    cmsCloseProfile(hOutProfile);

    cmsDeleteTransform(hTransform);

    float matrix[9];
    float offset[3];
    unsigned char lutIn[256*3];
    unsigned char lutOut[256*3];

    int shaderID = get_shader_values_lcms(matrix, offset, lutIn, lutOut);

    qDebug() << shaderID;

    glGenTextures(1, &m_lutIn);
    glActiveTexture(GL_TEXTURE1);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, m_lutIn);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 256, 1, 0, GL_RGB, GL_UNSIGNED_BYTE, lutIn);

    // Set nearest filtering mode for texture minification
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    // Set bilinear filtering mode for texture magnification
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Wrap texture coordinates by repeating
    // f.ex. texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glGenTextures(1, &m_lutOut);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, m_lutOut);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 256, 1, 0, GL_RGB, GL_UNSIGNED_BYTE, lutOut);

    // Set nearest filtering mode for texture minification
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    // Set bilinear filtering mode for texture magnification
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Wrap texture coordinates by repeating
    // f.ex. texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    QPixmap pixmap;

    // Loading cube.png to texture unit 0
    glActiveTexture(GL_TEXTURE0);
    if (pixmap.load(QString(":/TEST.png")))
    {
        qDebug() << "Loaded Image";
    }

    m_texture = bindTexture(pixmap, GL_TEXTURE_2D);

    // Set nearest filtering mode for texture minification
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    // Set bilinear filtering mode for texture magnification
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Wrap texture coordinates by repeating
    // f.ex. texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    m_scaleOffset = QVector4D(255.0f/256.0f, 0.5/256.0f, 255.0f/256.0f, 0.5/256.0f);
    m_transform = QMatrix3x3(matrix);
    //m_transform = m_transform.transposed();
    m_offset = QVector3D(offset[0], offset[1], offset[2]);

    setShader(shaderID);
}
