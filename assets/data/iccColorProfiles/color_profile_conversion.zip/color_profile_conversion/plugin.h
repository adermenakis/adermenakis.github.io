#ifndef __MY_PLUGIN_H_
#define __MY_PLUGIN_H_

#ifdef __cplusplus
extern "C"
{

#endif

int register_shader_plugin();
unsigned int get_shader_values_lcms(float * matrix, float * offset, unsigned char * lut_in, unsigned char * lut_out);

#ifdef __cplusplus
}
#endif

#endif // __MY_PLUGIN_H_
