#include <lcms2.h>
#include <lcms2_plugin.h>

#define MIN(x,y) (x < y) ? x : y

#include "plugin.h"

#ifdef __cplusplus
extern "C"
{
#endif

static float shader_matrix[9];
static float shader_offset[3];
static unsigned char shader_lut_in[256][3];
static unsigned char shader_lut_out[256][3];
static unsigned int shader_flags = 0xFFFFFFFF;

unsigned int get_shader_values_lcms(float * matrix, float * offset, unsigned char * lut_in, unsigned char * lut_out)
{
    memcpy(matrix, shader_matrix, sizeof(shader_matrix));
    memcpy(offset, shader_offset, sizeof(shader_offset));
    memcpy(lut_in, shader_lut_in, sizeof(shader_lut_in));
    memcpy(lut_out, shader_lut_out, sizeof(shader_lut_out));

    return shader_flags;
}

cmsBool shader_inspector(cmsPipeline** Lut, cmsUInt32Number Intent, cmsUInt32Number* InputFormat, cmsUInt32Number* OutputFormat, cmsUInt32Number* dwFlags)
{
    cmsStage* stage;
    int i, j, index;

    shader_flags = 0;

    if ((cmsPipelineInputChannels(*Lut) != 3) || (cmsPipelineOutputChannels(*Lut) != 3) || (cmsPipelineStageCount(*Lut) > 3))
    {
        shader_flags = 0xFFFFFFFF;

        return FALSE;
    }

    stage = cmsPipelineGetPtrToFirstStage(*Lut);

    while (stage != NULL)
    {
        if (cmsStageType(stage) == cmsSigIdentityElemType)
        {
            stage = cmsStageNext(stage);
        }
        else
        {
            break;
        }
    }

    if (stage == NULL)
    {
        return FALSE;
    }


    if ((cmsStageInputChannels(stage) != 3) || (cmsStageOutputChannels(stage) != 3))
    {
        shader_flags = 0xFFFFFFFF;

        return FALSE;
    }

    if (cmsStageType(stage) == cmsSigCurveSetElemType)
    {
        _cmsStageToneCurvesData* stageToneCurvesData = (_cmsStageToneCurvesData*)cmsStageData(stage);

        if (stageToneCurvesData == NULL)
        {
            shader_flags = 0xFFFFFFFF;

            return FALSE;
        }

        if ((stageToneCurvesData->TheCurves == NULL) || ((stageToneCurvesData->nCurves != 1) && (stageToneCurvesData->nCurves != 3)))
        {
            shader_flags = 0xFFFFFFFF;

            return FALSE;
        }

        for (i = 0; i < 3; ++i)
        {
            for (j = 0; j < 256; ++j)
            {
                int temp = stageToneCurvesData->nCurves - 1;
                index = MIN(i, temp);
                shader_lut_in[j][i] = cmsEvalToneCurveFloat(stageToneCurvesData->TheCurves[index], j / 255.0f) * 255.0f + 0.5f;
            }
        }

        shader_flags |= 1;

        stage = cmsStageNext(stage);

        while (stage != NULL)
        {
            if (cmsStageType(stage) == cmsSigIdentityElemType)
            {
                stage = cmsStageNext(stage);
            }
            else
            {
                break;
            }
        }
    }

    if (stage != NULL)
    {
        if ((cmsStageInputChannels(stage) != 3) || (cmsStageOutputChannels(stage) != 3))
        {
            shader_flags = 0xFFFFFFFF;

            return FALSE;
        }

        if (cmsStageType(stage) == cmsSigMatrixElemType)
        {
            _cmsStageMatrixData* stageMatrixData = (_cmsStageMatrixData*)cmsStageData(stage);

            if (stageMatrixData == NULL)
            {
                shader_flags = 0xFFFFFFFF;

                return FALSE;
            }

            if (stageMatrixData->Double == NULL)
            {
                shader_flags = 0xFFFFFFFF;

                return FALSE;
            }

            for (i = 0; i < 9; ++i)
            {
                shader_matrix[i] = stageMatrixData->Double[i];
            }

            if (stageMatrixData->Offset != NULL)
            {
                for (i = 0; i < 3; ++i)
                {
                    shader_offset[i] = stageMatrixData->Offset[i];
                }
            }
            else
            {
                for (i = 0; i < 3; ++i)
                {
                    shader_offset[i] = 0.0f;
                }
            }

            shader_flags |= 2;

            stage = cmsStageNext(stage);

            while (stage != NULL)
            {
                if (cmsStageType(stage) == cmsSigIdentityElemType)
                {
                    stage = cmsStageNext(stage);
                }
                else
                {
                    break;
                }
            }
        }
    }


    if (stage != NULL)
    {
        if ((cmsStageInputChannels(stage) != 3) || (cmsStageOutputChannels(stage) != 3))
        {
            shader_flags = 0xFFFFFFFF;

            return FALSE;
        }

	if (cmsStageType(stage) == cmsSigCurveSetElemType)
	{
            _cmsStageToneCurvesData* stageToneCurvesData = (_cmsStageToneCurvesData*)cmsStageData(stage);

            if (stageToneCurvesData == NULL)
            {
                shader_flags = 0xFFFFFFFF;

                return FALSE;
            }

            if ((stageToneCurvesData->TheCurves == NULL) || ((stageToneCurvesData->nCurves != 1) && (stageToneCurvesData->nCurves != 3)))
            {
                shader_flags = 0xFFFFFFFF;

                return FALSE;
            }

            for (i = 0; i < 3; ++i)
            {
                for (j = 0; j < 256; ++j)
                {
                    int temp = stageToneCurvesData->nCurves - 1;
                    index = MIN(i, temp);
                    shader_lut_out[j][i] = cmsEvalToneCurveFloat(stageToneCurvesData->TheCurves[index], j / 255.0f) * 255.0f + 0.5f;
                }
            }

            shader_flags |= 4;

            stage = cmsStageNext(stage);

            while (stage != NULL)
            {
                if (cmsStageType(stage) == cmsSigIdentityElemType)
                {
                    stage = cmsStageNext(stage);
                }
                else
                {
                    break;
                }
            }
        }
    }

    if (stage != NULL)
    {
        if (cmsStageType(stage) != cmsSigIdentityElemType)
        {
            shader_flags = 0xFFFFFFFF;
        }
    }

    return FALSE;
}

cmsPluginOptimization Plugin =
{
    {
        cmsPluginMagicNumber,
        2000,
        cmsPluginOptimizationSig,
        NULL
    },
    shader_inspector
};

int register_shader_plugin()
{
    return cmsPlugin(&Plugin);
}

#ifdef __cplusplus
}
#endif

