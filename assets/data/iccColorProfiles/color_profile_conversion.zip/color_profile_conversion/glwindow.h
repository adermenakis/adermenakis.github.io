/**
 * Simple QtOpenGL Sample
 * tuomo.hirvonen @ digia 2010
 *
 */

#ifndef GLWINDOW_H
#define GLWINDOW_H

#include <QGLWidget>
#include <QTimer>
#include <QtOpenGL/qglshaderprogram.h>
#include <QHash>
#include <QFile>

class QTimer;
class QTextStream;

class GLWindow : public QGLWidget
{
    Q_OBJECT
public:
    GLWindow(QWidget *parent = 0);
    ~GLWindow();

    void resizeGL(int width, int height);
    void initializeGL();
    void paintGL();

private:
    QGLShaderProgram *m_sampleProgram;
    QMatrix3x3 m_transform;
    QVector4D m_scaleOffset;
    QVector3D m_offset;
    GLuint m_texture, m_lutIn, m_lutOut;
    QList<QString> m_ShaderSrcCode;
    QFile m_file;
    int m_iterationCtr;
    QTimer *m_timer;
    QTextStream m_out;

    void setShader(const int index);

};

#endif // GLWINDOW_H
