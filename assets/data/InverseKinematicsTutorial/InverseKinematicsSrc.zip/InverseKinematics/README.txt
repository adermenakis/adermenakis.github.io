This is the Inverse Kinematics tutorial by Alexandros Dermenakis

For the full exaplanation of the mathematics behind consule http://www.alexandrosdermenakis/inversekinematicstutorial

Before compiling the code in VS2010 make use you have installed glut on the system.

Thanks for downloading :-)