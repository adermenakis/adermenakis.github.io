/*******************************************************************/
/*          FAT diriver for  MP3 Player                            */
/*                                                                 */
/* Platform   : AVRStudio4.13 b528 + WinAVR20070525                */
/*              optimize -0s                                       */
/* Author     : bozai(Zhang Qibo)                                  */
/* E-mail     : sudazqb@163.com                                    */
/* MSN        : zhangqibo_1985@hotmail.com                         */
/* Date       : 2006-06-14                                         */
/*******************************************************************/
/*2007-11-09: now the songs may placed in any directory, but the   */
/*            total number of folder the card has should less than */
/*            127 for we use 512Bytes EEPROM to stored the info    */
/*2007-10-08: fix a bug (but it never works), so stupid I am,      */ 
/*            take & as &&                                         */
/*2006-06-14: still the bug of FAT                                 */
/*2006-05-04: fix bug of FAT init, add read capacity check         */ 

/* Modified by : Alexandros Dermenakis							   *
 * email: alexandros.dermenakis@gmail.com		                   */
 
#include "fat.h"
#include "../display/display.h"
#include <stdio.h>

DWORD FirstDirClust;    //first directory cluster
DWORD FirstDataSector;	// The first sector number of data
WORD BytesPerSector;	// Bytes per sector
WORD FATsectors;		// The amount sector a FAT occupied
WORD SectorsPerClust;	// Sector per cluster
DWORD FirstFATSector;	// The first FAT sector
DWORD FirstDirSector;	// The first Dir sector
DWORD RootDirSectors;	// The sector number a Root dir occupied 
DWORD RootDirCount;		// The count of directory in root dir
BYTE FAT32_Enable;

#define FAT_ReadSector MMC_SD_ReadSingleBlock

unsigned char FAT_Init()//Initialize of FAT  need initialize SD first
{
	struct bootsector710 *bs  = 0;
	struct bpb710        *bpb = 0;
	struct partrecord    *pr  = 0;

	DWORD hidsec=0;
	DWORD Capacity;
	
	Capacity = MMC_SD_ReadCapacity();
	if(Capacity<0xff)return 1;

	if(FAT_ReadSector(0,gBuffer))return 1;
	bs = (struct bootsector710 *)gBuffer;
	
	
	pr = (struct partrecord *)((struct partsector *)gBuffer)->psPart;//first partition
	hidsec = pr->prStartLBA;//the hidden sectors
	
	if(hidsec >= Capacity/BUFFER_SIZE)
	{
		hidsec = 0;
	}
	else 
	{
		if(FAT_ReadSector(pr->prStartLBA,gBuffer))return 1;//read the bpb sector
		bs = (struct bootsector710 *)gBuffer;
		if(bs->bsJump[0]!=0xE9 && bs->bsJump[0]!=0xEB)
		{
			hidsec = 0;
			if(FAT_ReadSector(0,gBuffer))return 1;//read the bpb sector
			bs = (struct bootsector710 *)gBuffer;	
		}
	}
	
	if(bs->bsJump[0]!=0xE9 && bs->bsJump[0]!=0xEB)//dead with the card which has no bootsect
	{
		return 1;
	}
	
	bpb = (struct bpb710 *)bs->bsBPB;

	if(bpb->bpbFATsecs)//detemine thd FAT type  //do not support FAT12
	{
		FAT32_Enable=0;	//FAT16
		FATsectors		= bpb->bpbFATsecs; //the sectors number occupied by one fat talbe
		FirstDirClust = 2;
	}
	else
	{
		FAT32_Enable=1;	//FAT32
		FATsectors		= bpb->bpbBigFATsecs; //the sectors number occupied by one fat talbe
		FirstDirClust = bpb->bpbRootClust;
	}

	BytesPerSector	= bpb->bpbBytesPerSec;
	SectorsPerClust	= (BYTE)bpb->bpbSecPerClust;
	FirstFATSector	= bpb->bpbResSectors+hidsec;
	RootDirCount	= bpb->bpbRootDirEnts;
	RootDirSectors	= (RootDirCount*32)>>9;
	FirstDirSector	= FirstFATSector+bpb->bpbFATs*FATsectors;
	FirstDataSector	= FirstDirSector+RootDirSectors;

	return 0;
}

//read one sector of one cluster, parameter part indicate which sector
unsigned char FAT_LoadPartCluster(unsigned long cluster,unsigned part,BYTE * buffer)
{
	DWORD sector;
	sector=FirstDataSector+(DWORD)(cluster-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
	if(FAT_ReadSector(sector+part,buffer))return 1;
	
	return 0;
}

//Return the cluster number of next cluster of file
//Suitable for system which has limited RAM
unsigned long FAT_NextCluster(unsigned long cluster)
{
	DWORD sector;
	DWORD offset;
	if(FAT32_Enable)offset = cluster/128;
	else offset = cluster/256;
	if(cluster<2)return 0x0ffffff8;
	sector=FirstFATSector+offset;//calculate the actual sector
	if(FAT_ReadSector(sector,gBuffer))return 0x0ffffff8;//read fat table / return 0xfff8 when error occured

	if(FAT32_Enable)
	{
		offset=cluster%128;//find the position
		sector=((unsigned long *)gBuffer)[offset];	
	}
	else
	{
		offset=cluster%256;//find the position
		sector=((unsigned int *)gBuffer)[offset];
	}
	return (unsigned long)sector;//return the cluste number
}

//copy item
void CopyDirentruyItem(SongStruct *Desti,struct direntry *Source)
{
	BYTE i;
	for(i=0;i<8;i++)Desti->deName[i] = Source->deName[i];
	Desti->deName[8] = '\0';
	Desti->deHighClust = Source->deHighClust;
	Desti->deStartCluster = Source->deStartCluster;
	Desti->deFileSize = Source->deFileSize;
}

void WriteFolderCluster(WORD addr,DWORD cluster)
{
	eeprom_write_byte(addr,cluster>>24);
	eeprom_write_byte(addr+1,cluster>>16);
	eeprom_write_byte(addr+2,cluster>>8);
	eeprom_write_byte(addr+3,cluster>>0);
}

DWORD GetFolderCluster(WORD addr)
{
	DWORD temp;
	temp = eeprom_read_byte(addr);
	temp <<= 8;
	temp += eeprom_read_byte(addr+1);
	temp <<= 8;
	temp += eeprom_read_byte(addr+2);
	temp <<= 8;
	temp += eeprom_read_byte(addr+3);
	
	return temp;
}

BYTE SearchFolder(DWORD cluster,WORD *addr)
{
	DWORD sector;
	DWORD tempclust;
	unsigned char cnt;
	unsigned int offset;
	struct direntry *item = 0;
	
	if(cluster==0 && FAT32_Enable==0)// root directory
	{
		for(cnt=0;cnt<RootDirSectors;cnt++)
		{
			if(FAT_ReadSector(FirstDirSector+cnt,gBuffer))return 1;
			for(offset=0;offset<BUFFER_SIZE;offset+=32)
			{
				item=(struct direntry *)(&gBuffer[offset]);//pointer convert
				//find a valid item and display it
				if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
				{
					if(item->deAttributes & ATTR_DIRECTORY )
					{
						if(*addr==RECORD_ADDR_END)return 0;
						else
						{
							WriteFolderCluster(*addr,item->deStartCluster+(((unsigned long)item->deHighClust)<<16));
							*addr+=4;
						}
					}
				}
			}
		}
	}
	else//other folders
	{
		tempclust=cluster;
		while(1)
		{
			sector=FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
			for(cnt=0;cnt<SectorsPerClust;cnt++)
			{
				if(FAT_ReadSector(sector+cnt,gBuffer)) return 1;
				for(offset=0;offset<BUFFER_SIZE;offset+=32)
				{
					item=(struct direntry *)(&gBuffer[offset]);
					if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
					{				
						if(item->deAttributes & ATTR_DIRECTORY )
						{
							if(*addr==RECORD_ADDR_END)return 0;
							else
							{
								WriteFolderCluster(*addr,item->deStartCluster+(((unsigned long)item->deHighClust)<<16));
								*addr+=4;
							}
						}
					}
				}
			}
			tempclust=FAT_NextCluster(tempclust);//next cluster
			if(tempclust == 0x0fffffff || tempclust == 0x0ffffff8 || (FAT32_Enable == 0 && tempclust == 0xffff))break;
		}
	}
	return 0;		
}



BYTE SearchInit()
{	
	WORD addr = RECORD_ADDR_START;
	WORD temp_addr;
	DWORD cluster;
	
	if(FAT32_Enable)
		WriteFolderCluster(addr,FirstDirClust);
	else 
		WriteFolderCluster(RECORD_ADDR_START,0);
	
	addr += 4;
	
	WriteFolderCluster(addr, 0xffffffff);
	temp_addr = addr;
	addr = RECORD_ADDR_START;
	while(1)
	{
		cluster = GetFolderCluster(addr);
		if(cluster == 0xffffffff)return 0;
		else
		{
			SearchFolder(cluster,&temp_addr);
			if(GetFolderCluster(temp_addr) != 0xffffffff)
				WriteFolderCluster(temp_addr,0XFFFFFFFF);
			if(temp_addr == RECORD_ADDR_END)
			{
				WriteFolderCluster(temp_addr - 4,0XFFFFFFFF);
				break;
			}
		}
		addr+=4;
	}
}

int8_t FAT_GetNumOfSongs(uint16_t *out_size)
{
	DWORD sector;
	DWORD cluster;
	DWORD tempclust;
	uint8_t cnt;
	uint32_t offset;
	
	struct direntry *item = 0;
	
	*out_size = 0;
	WORD addr = RECORD_ADDR_START;
	
	while(1)
	{
		cluster = GetFolderCluster(addr);
		addr += 4;
		if(cluster == 0xffffffff) break;
		else
		{
			//*music_record_addr = addr - 4;	/* record in which record found the right file */
			if(cluster==0 && FAT32_Enable==0)// root directory
			{
				for(cnt=0;cnt<RootDirSectors;cnt++)
				{
					if(FAT_ReadSector(FirstDirSector+cnt,gBuffer))return 1;
					for(offset=0;offset<BUFFER_SIZE;offset+=32)
					{
						item=(struct direntry *)(&gBuffer[offset]);//pointer convert
						//find a valid item and display it
						if(GetAudioType(item) != INV)
							(*out_size)++;
					}
				}
			}
			else//other folders
			{
				tempclust=cluster;
				while(1)
				{
					sector=FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
					for(cnt=0;cnt<SectorsPerClust;cnt++)
					{
						if(FAT_ReadSector(sector+cnt,gBuffer)) return 1;
						for(offset=0;offset<BUFFER_SIZE;offset+=32)
						{
							item=(struct direntry *)(&gBuffer[offset]);
							if((item->deName[0] != '.') && (item->deName[0] != 0x00) &&
									(item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
							{
								if(GetAudioType(item) != INV)
									(*out_size)++;
							}
						}
					}
					tempclust=FAT_NextCluster(tempclust);//next cluster
					if(tempclust == 0x0fffffff || tempclust == 0x0ffffff8 ||
						(FAT32_Enable == 0 && tempclust == 0xffff))break;
				}
			}
		}
	}

	return 0;
}

int8_t FAT_GetSongs(uint8_t fromSong, uint8_t numOfSongs, struct SongStruct* out_songs)
{
	DWORD sector;
	DWORD cluster;
	DWORD tempclust;
	uint8_t cnt;
	uint8_t song_ctr = 0;
	uint8_t song_index = 0;
	uint32_t offset;
	
	struct direntry *item = 0;

	WORD addr = RECORD_ADDR_START;
	
	while(1)
	{
		cluster = GetFolderCluster(addr);
		addr += 4;
		if(cluster == 0xffffffff) break;
		else
		{
			//*music_record_addr = addr - 4;	/* record in which record found the right file */
			if(cluster==0 && FAT32_Enable==0)// root directory
			{
				for(cnt=0; cnt < RootDirSectors; cnt++)
				{
					if(FAT_ReadSector(FirstDirSector+cnt,gBuffer))return 1;
					for(offset = 0; offset < BUFFER_SIZE; offset += 32)
					{
						item=(struct direntry *)(&gBuffer[offset]);//pointer convert
						//find a valid item and display it
						BYTE songFormat = GetAudioType(item);
						if(songFormat != INV)
						{
							if(song_index == numOfSongs) return 0;
							if(fromSong <= song_ctr)
							{
								CopyDirentruyItem(&out_songs[song_index],item);
								out_songs[song_index].songFormat = songFormat;
								song_index++;
							}
							song_ctr++;
						}
					}
				}
			}
			else//other folders
			{
				tempclust=cluster;
				while(1)
				{
					sector=FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
					for(cnt = 0; cnt < SectorsPerClust; cnt++)
					{
						if(FAT_ReadSector(sector+cnt,gBuffer)) return 1;
						for(offset = 0; offset < BUFFER_SIZE; offset+=32)
						{
							item=(struct direntry *)(&gBuffer[offset]);
							if((item->deName[0] != '.') && (item->deName[0] != 0x00) &&
									(item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
							{
								BYTE songFormat = GetAudioType(item);
								if(songFormat != INV)
								{
									if(song_index == numOfSongs) return 0;
									if(fromSong <= song_ctr)
									{
										CopyDirentruyItem(&out_songs[song_index],item);
										out_songs[song_index].songFormat = songFormat;
										song_index++;
									}
									song_ctr++;
								}
							}
						}
					}
					tempclust=FAT_NextCluster(tempclust);//next cluster
					if(tempclust == 0x0fffffff || tempclust == 0x0ffffff8 ||
						(FAT32_Enable == 0 && tempclust == 0xffff))break;
				}
			}
		}
	}
	
	while(song_index < numOfSongs)
	{
		out_songs[song_index++].deName[0] = 0;
	}

	return 0;
}

Media_Format_t GetAudioType(struct direntry *item)
{
	if((item->deExtension[0] == 'M')&&(item->deExtension[1] == 'P')&&(item->deExtension[2] == '3'))
		return MP3;
	else if((item->deExtension[0] == 'W')&&(item->deExtension[1] == 'M')&&(item->deExtension[2] == 'A'))
		return WMA;
	else if((item->deExtension[0] == 'M')&&(item->deExtension[1] == 'I')&&(item->deExtension[2] == 'D'))
		return MID;
	else if((item->deExtension[0] == 'W')&&(item->deExtension[1] == 'A')&&(item->deExtension[2] == 'V'))
		return WAV;
	
	return INV;
}
