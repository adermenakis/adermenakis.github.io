/*******************************************************************/
/*          Header file of MMC_SD.c  for  MP3 Player               */
/*                                                                 */
/* Note: MMC is not tested                                         */
/*                                                                 */
/* Platform   : AVRStudio4.13 b528 + WinAVR20070122                */
/*              optimize -0s                                       */
/* Author     : bozai(Zhang Qibo)                                  */
/* E-mail     : sudazqb@163.com                                    */
/* MSN        : zhangqibo_1985@hotmail.com                         */
/* Date       : 2006-05-09                                         */
/*******************************************************************/
/*  2007-05-04: add read capacity function                         */
/*  2007-04-21:                                                    */
/*  Enable some code incase that when SD reset                     */
/*  faild program can't jump the loop                              */
/*******************************************************************/

/* Modified by : Alexandros Dermenakis							   *
 * email: alexandros.dermenakis@gmail.com		                   */
 
#ifndef __MMC_SD_h__
#define __MMC_SD_h__

#include "../config.h"

#define SPI_CS_Assert()   MMC_SD_PORT &= ~_BV(MMC_SD_CS_PIN)  
#define SPI_CS_Deassert() MMC_SD_PORT |=  _BV(MMC_SD_CS_PIN)


extern void MMC_SD_Init(void);
extern uint8_t MMC_SD_Reset(void);
extern uint8_t MMC_SD_ReadSingleBlock(uint32_t sector, uint8_t* buffer);
extern uint32_t MMC_SD_ReadCapacity();
extern void SPI_High(void);


#endif
