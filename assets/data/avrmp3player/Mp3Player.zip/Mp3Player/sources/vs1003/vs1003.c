/*******************************************************************/
/*          VS1003 diriver for  Mega8 MP3 Player                   */
/*                                                                 */
/* Platform   : AVRStudio4.13 b528 + WinAVR20070122                */
/*              optimize -0s                                       */
/* Author     : bozai(Zhang Qibo)                                  */
/* E-mail     : sudazqb@163.com                                    */
/* MSN        : zhangqibo_1985@hotmail.com                         */
/* Date       : 2006-05-09                                         */
/*******************************************************************/
/*2007-10-19: use new delay function                               */
/*2007-05-04: add slow start up code, and add enough delay         */
/*2007-04-21:                                                      */

/* Modified by : Alexandros Dermenakis							   *
 * email: alexandros.dermenakis@gmail.com		                   */
 
#include<avr/io.h>
#include"vs1003.h"
#include<util/delay.h>

#include "../display/display.h"

void VS1003B_Send_Zeros(void)
{
	uint16_t count = 0;
	uint8_t j = 0;
	
	while(count < 2048)//recommand 2048 zeros honoring DREQ goto next songs
	{
		if((VS1003B_PIN & _BV(VS1003B_DREQ))!=0)
		{
			for(j=0;j<32;j++)
			{
				VS1003B_WriteDAT(0x00);
				count++;
			}
		}
	}
}

//low speed
void VS1003B_SPI_Low(void)
{
	SPCR =   _BV(SPE)|_BV(MSTR)|_BV(SPR1)|_BV(SPR0);
	SPSR &= ~_BV(SPI2X);
}

//full speed
void VS1003B_SPI_High(void)
{
	SPCR =  _BV(SPE)|_BV(MSTR);
	//SPSR &= ~_BV(SPI2X);
	SPSR |= _BV(SPI2X);
}

//write one byte to vs1003
unsigned char VS1003B_WriteByte(unsigned char CH)
{   
	SPDR = CH;
	while(!(SPSR & _BV(SPIF)));
	return SPDR;
}

//read one byte from vs1003
unsigned char VS1003B_ReadByte()
{
    SPDR = 0xff;
	while(!(SPSR & _BV(SPIF)));
	return SPDR;
}

//config register
void VS1003B_WriteCMD(unsigned char addr, unsigned int dat)
{
	VS1003B_XDCS_H();
	VS1003B_XCS_L();
	VS1003B_WriteByte(0x02);
	VS1003B_WriteByte(addr);
	VS1003B_WriteByte(dat>>8);
	VS1003B_WriteByte(dat);
	VS1003B_XCS_H();
}

//read register
unsigned int VS1003B_ReadCMD(unsigned char addr)
{
	unsigned int temp;
	VS1003B_XDCS_H();
	VS1003B_XCS_L();
	VS1003B_WriteByte(0x03);
	VS1003B_WriteByte(addr);
	temp = VS1003B_ReadByte();
	temp <<= 8;
	temp += VS1003B_ReadByte();
	VS1003B_XCS_H();
	return temp;
}

//write data (music data)
void VS1003B_WriteDAT(unsigned char dat)
{
	VS1003B_XDCS_L();
	VS1003B_WriteByte(dat);
	VS1003B_XDCS_H();
	VS1003B_XCS_H();
}

// 1 means fail, 0 OK!
unsigned char VS1003B_Init()
{
	unsigned char retry;
	VS1003B_INI();
	VS1003B_DDR &=~_BV(VS1003B_DREQ);
	VS1003B_XCS_H();
	VS1003B_XDCS_H();
	VS1003B_XRESET_L();
	_delay_ms(20);
	VS1003B_XRESET_H(); //chip select
	VS1003B_SPI_Low(); //low speed
	_delay_ms(20); //delay

	retry=0;

	while(VS1003B_ReadCMD(SCI_CLOCKF) != CLOCK_REG) //set PLL register
	{
		VS1003B_WriteCMD(SCI_CLOCKF,CLOCK_REG);
		if(retry++ > 100 )return 1;
	}

	_delay_ms(20);
	
	VS1003B_WriteCMD(SCI_AUDDATA,0x000a);
	
	retry=0;
	while(VS1003B_ReadCMD(SCI_VOL) != 0xfefe) //set Volume
	{
		VS1003B_WriteCMD(SCI_VOL,0xfefe);
		if(retry++ >100 )return 1;
	}

	VS1003B_WriteCMD(SCI_AUDDATA,0xac45);

	retry=0;
	while(VS1003B_ReadCMD(SCI_VOL) != DEFAULT_VOLUME) //set Volume
	{
		VS1003B_WriteCMD(SCI_VOL,DEFAULT_VOLUME);
		if(retry++ >100 )return 1;
	}

	retry=0;
	while(VS1003B_ReadCMD(SCI_MODE) != 0x0800) //set mode register
	{
		VS1003B_WriteCMD(SCI_MODE,0x0800);
		if(retry++ >100 )return 1;
	}

	_delay_ms(20);

	VS1003B_SoftReset();

	_delay_ms(20);

	VS1003B_SPI_High();
	return 0;
}

//VS1003 soft reset
void VS1003B_SoftReset()
{
	VS1003B_WriteCMD(SCI_MODE,0x0804);
//	VS1003B_Delay(0xffff); //wait at least 1.35ms
	_delay_ms(20);
}


