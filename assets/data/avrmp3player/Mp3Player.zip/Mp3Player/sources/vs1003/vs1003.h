/*******************************************************************/
/*          Head file of VS1003B.c  for  Mega8 MP3 Player          */
/*                                                                 */
/* Platform   : AVRStudio4.13 b528 + WinAVR20070525                */
/*              optimize -0s                                       */
/* Author     : bozai(Zhang Qibo)                                  */
/* E-mail     : sudazqb@163.com                                    */
/* MSN        : zhangqibo_1985@hotmail.com                         */
/* Date       : 2006-05-09                                         */
/*******************************************************************/
/*2007-05-04: add slow start up code, and add enough dealy         */
/*2007-04-21:                                                      */
/*******************************************************************/

/* Modified by : Alexandros Dermenakis							   *
 * email: alexandros.dermenakis@gmail.com		                   */
 
#ifndef __VS1003B_H__
#define __VS1003B_H__

#include "../config.h"

#define SCI_MODE 0X00
#define SCI_STATUS 0x01
#define SCI_BASS 0x02
#define SCI_CLOCKF 0x03
#define SCI_DECODE_TIME 0x04
#define SCI_AUDDATA 0x05
#define SCI_WRAM 0x06
#define SCI_WRAMADDR 0x07
#define SCI_HDAT0 0x08
#define SCI_HDAT1 0x09
#define SCI_AIADDR 0x0A
#define SCI_VOL 0x0B
#define SCI_AICTRL0 0x0C
#define SCI_AICTRL1 0x0D
#define SCI_AICTRL2 0x0E
#define SCI_AICTRL3 0x0F

#define VS1003B_XCS_H()    VS1003B_PORT |=  _BV(VS1003B_XCS)
#define VS1003B_XCS_L()    VS1003B_PORT &= ~_BV(VS1003B_XCS)

#define VS1003B_XRESET_H()    VS1003B_PORT |=  _BV(VS1003B_XRESET)
#define VS1003B_XRESET_L()    VS1003B_PORT &= ~_BV(VS1003B_XRESET)

#define VS1003B_XDCS_H()    VS1003B_PORT |=  _BV(VS1003B_XDCS)
#define VS1003B_XDCS_L()    VS1003B_PORT &= ~_BV(VS1003B_XDCS)

extern void VS1003B_Send_Zeros(void);
extern void VS1003B_SPI_Low(void);
extern void VS1003B_SPI_High(void);
extern unsigned char VS1003B_WriteByte(unsigned char CH);
extern unsigned char VS1003B_ReadByte();
extern void VS1003B_WriteCMD(unsigned char addr, unsigned int dat);
extern unsigned int VS1003B_ReadCMD(unsigned char addr);
extern void VS1003B_WriteDAT(unsigned char dat);
extern unsigned char VS1003B_Init();
extern void VS1003B_SoftReset();
#endif
