#ifndef __LCD_5110_h__
#define __LCD_5110_h__

#include "../config.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include "font_6x8_iso8859_1.h"


void LCD5110_write_char(uint8_t c);
void LCD5110_write_char_inverted(uint8_t c);

void LCD5110_progress_bar(uint8_t progress, uint8_t line);
void LCD5110_writeString(char* str);

void LCD5110_writeStringln_inverted(char* str);
void LCD5110_writeString_block(int cursorPos, char** str);

void LCD5110_writeStringln(char* str);

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_writeCommand
  Description  :  Sends command to display controller.
  Argument(s)  :  command -> command to be sent
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_writeCommand (uint8_t command );

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_writeData
  Description  :  Sends data to display controller.
  Argument(s)  :  data -> data to be sent
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_writeData (uint8_t data );

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_gotoXY
  Description  :  Sets cursor location to xy location corresponding to basic font size.
  Argument(s)  :  x - range: 0 to 84
                  y -> range: 0 to 5
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_gotoXY ( uint8_t x, uint8_t y );

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_clear
  Description  :  Clears the display
  Argument(s)  :  None.
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_clear ( void );

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_init
  Description  :  LCD controller initialization.
  Argument(s)  :  None.
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_init ( void );

void long_delay(void);

#endif //__LCD_5110_h__
