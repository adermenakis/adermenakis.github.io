// Uwe Zimmermann
// 2012-02-20
/*
   driving a NOKIA 5110 LCD from an ATmega16
   using bit-banging
   inspired by CC Dharmani, Chennai (India)
   http://www.dharmanitech.com
*/

/* pinout

ATmega16

       PB0|1     40|PA0  RS
       PB1|2     39|PA1  RW
       PB2|3     38|PA2  E
       PB3|4     37|PA3
       PB4|5     36|PA4  D4
  MOSI PB5|6     35|PA5  D5
  MISO PB6|7     34|PA6  D6
  SCK  PB7|8     33|PA7  D7
    /Reset|9     32|Aref
       Vcc|10    31|Gnd
       Gnd|11    30|AVcc
     Xtal2|12    29|PC7
     Xtal1|13    28|PC6
  RxD  PD0|14    27|PC5
  TxD  PD1|15    26|PC4  RST
       PD2|16    25|PC3  SCE
       PD3|17    24|PC2  D/C
       PD4|18    23|PC1  DI
       PD5|19    22|PC0  SCL
       PD6|20    21|PD7

*/

/* Optimized by : Alexandros Dermenakis							   *
 * email: alexandros.dermenakis@gmail.com		                   */
 
#include "lcd_5110.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#ifdef USE_5110

void LCD5110_write_char(uint8_t c)
{
	LCD5110_writeData(pgm_read_byte(&smallFont[c][0]));
	LCD5110_writeData(pgm_read_byte(&smallFont[c][1])); 
	LCD5110_writeData(pgm_read_byte(&smallFont[c][2]));
	LCD5110_writeData(pgm_read_byte(&smallFont[c][3]));
	LCD5110_writeData(pgm_read_byte(&smallFont[c][4]));
	LCD5110_writeData(pgm_read_byte(&smallFont[c][5]));
}

void LCD5110_write_char_inverted(uint8_t c)
{
	LCD5110_writeData(~pgm_read_byte(&smallFont[c][0]));
	LCD5110_writeData(~pgm_read_byte(&smallFont[c][1]));
	LCD5110_writeData(~pgm_read_byte(&smallFont[c][2]));
	LCD5110_writeData(~pgm_read_byte(&smallFont[c][3]));
	LCD5110_writeData(~pgm_read_byte(&smallFont[c][4]));
	LCD5110_writeData(~pgm_read_byte(&smallFont[c][5]));
}

//Displays progress of played song in a status bar. 21 Annoying if-statements...
//Optimize function by using arithmetics on the characters! :)
void LCD5110_progress_bar(uint8_t progress, uint8_t line)
{
	uint8_t i;
	//char str[6];
	// 84 characater: 0 -> 83
	
	LCD5110_gotoXY(0,line);
	
	LCD5110_writeData(0x18);
	LCD5110_writeData(0x18);
	
	LCD5110_writeData(0x00);
	
	for(i = 0; i < progress*78/100; i++)
		LCD5110_writeData(0x18);
	
	LCD5110_gotoXY(82,line);
	
	LCD5110_writeData(0x18);
	LCD5110_writeData(0x18);
	
//	sprintf(str, "%x", progress);
//	LCD5110_writeString(str);
}

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_writeCommand
  Description  :  Sends command to display controller.
  Argument(s)  :  command -> command to be sent
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_writeCommand (uint8_t command )
{
    uint8_t i;
    ClearSCE;       //enable LCD
    ClearDC;        // set LCD into command mode
    ClearSCL;
    for (i=0; i<8; i++)
    {
      if (command & 0b10000000)
      {
        SetDI;
      }
      else
      {
        ClearDI;
      }
//    _delay_us(1);
      SetSCL;       // minimum 100 ns
//    _delay_us(1);
      ClearSCL;     // minimum 100 ns
      command <<= 1;
    }
    SetSCE;         // disable LCD
}

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_writeData
  Description  :  Sends data to display controller.
  Argument(s)  :  data -> data to be sent
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_writeData (uint8_t data )
{
    uint8_t i;
    ClearSCE;       // enable LCD
    SetDC;          // set LCD in data mode
    ClearSCL;
    for (i=0; i<8; i++)
    {
      if (data & 0b10000000)
      {
        SetDI;
      }
      else
      {
        ClearDI;
      }
//    _delay_us(1);
      SetSCL;       // minimum 100 ns
//    _delay_us(1);
      ClearSCL;     // minimum 100 ns
      data <<= 1;
    }
    SetSCE;         // disable LCD
}

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_gotoXY
  Description  :  Sets cursor location to xy location corresponding to basic font size.
  Argument(s)  :  x - range: 0 to 84
                  y -> range: 0 to 5
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_gotoXY ( uint8_t x, uint8_t y )
{
    LCD5110_writeCommand (0x80 | x);   //column
    LCD5110_writeCommand (0x40 | y);   //row
}

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_clear
  Description  :  Clears the display
  Argument(s)  :  None.
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_clear ( void )
{
    uint16_t i;

    LCD5110_gotoXY (0,0);   // start with (0,0) position

    for(i=0; i<84*48/8; i++)
      LCD5110_writeData( 0x00 );

    LCD5110_gotoXY (0,0);   // bring the XY position back to (0,0)
}

/*--------------------------------------------------------------------------------------------------
  Name         :  LCD5110_init
  Description  :  LCD controller initialization.
  Argument(s)  :  None.
  Return value :  None.
--------------------------------------------------------------------------------------------------*/
void LCD5110_init ( void )
{
    LCD_5110_DDR = 0b00011111;
    _delay_ms(100);

    ClearSCE;                  // Enable LCD

    ClearRST;                  // reset LCD
    _delay_ms(100);
    SetRST;

    SetSCE;                    //disable LCD

    LCD5110_writeCommand( 0x21 );  // LCD Extended Commands.
    LCD5110_writeCommand( 0xC0 );  // Set LCD Vop (Contrast).
    LCD5110_writeCommand( 0x04 );  // Set Temp coefficent.
    LCD5110_writeCommand( 0x13 );  // LCD bias mode 1:48.
    LCD5110_writeCommand( 0x20 );  // LCD Standard Commands, Horizontal addressing mode.
    LCD5110_writeCommand( 0x0c );  // LCD in normal mode.

    LCD5110_clear();
}

void long_delay(void)
{
  uint8_t j;
  
  for (j=0; j<20; j++)
  {
    _delay_ms(1000);
  }
}

void LCD5110_writeString(char* str)
{
	int ctr = 0;
	
	while(str[ctr])
	{
		LCD5110_write_char((uint8_t)str[ctr]);
		ctr++;
	}
}

void LCD5110_writeStringln(char* str)
{
	int ctr = 0;
	// 14 characters + NULL
	while(str[ctr])
	{
		LCD5110_write_char((uint8_t)str[ctr]);
		ctr++;
	}
	
	while(ctr < 14)
	{
		LCD5110_write_char(' ');
		ctr++;
	}
}

void LCD5110_writeFileNameln(char* str)
{
	int ctr = 0;
	// 14 characters + NULL
	while(ctr < 8)
	{
		LCD5110_write_char((int)str[ctr]);
		ctr++;
	}
	
	while(ctr < 14)
	{
		LCD5110_write_char(' ');
		ctr++;
	}	
}

void LCD5110_writeFileName(char* str)
{
	int ctr = 0;
	// 14 characters + NULL
	while(ctr < 8)
	{
		LCD5110_write_char((uint8_t)str[ctr]);
		ctr++;
	}
}

void LCD5110_writeStringln_inverted(char* str)
{
	int ctr = 0;
	// 14 characters + NULL
	while(str[ctr])
	{
		LCD5110_write_char_inverted((uint8_t)str[ctr]);
		ctr++;
	}
	
	while(ctr < 14)
	{
		LCD5110_write_char_inverted(' ');
		ctr++;
	}
}

void LCD5110_writeString_block(int cursorPos, char** str)
{
	int ctr = 0;
	while(ctr < 6)
	{
		if(cursorPos == ctr)
			LCD5110_writeStringln_inverted(str[ctr]);
		else	
			LCD5110_writeStringln(str[ctr]);
		ctr++;
	}
	
}

#endif // USE_5110
