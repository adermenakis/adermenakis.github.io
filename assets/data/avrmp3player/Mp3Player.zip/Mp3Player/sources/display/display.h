#ifndef __DISPLAY_H__
#define __DISPLAY_H__



#ifdef USE_5110
#include "lcd_5110.h"
#define display_char(x) LCD5110_write_char(x)
#define display_init() LCD5110_init()
#define display_clear() LCD5110_clear()
#define display_print(x) LCD5110_writeString(x)
#define display_println(x) LCD5110_writeStringln(x)
#define display_writeString_block(x,y) LCD5110_writeString_block(x,y)
#define display_progress_bar(x) LCD5110_progress_bar(x,4)
#define display_volume_bar(x) LCD5110_progress_bar(x,0)
#elif USE_4478
// TODO: Put here the 4478
#endif



#endif // __DISPLAY_H__
