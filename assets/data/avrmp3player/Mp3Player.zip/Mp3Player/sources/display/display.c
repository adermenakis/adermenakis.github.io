#include "../config.h"
#include "lcd_5110.h"

void display_init()
{
#ifdef USE_5510
LCD5510_init();
#elif USE_4478
// TODO: Put here the 4478
#endif
}

void display_clear()
{
#ifdef USE_5510
LCD5510_init();
#elif USE_4478
// TODO: Put here the 4478
#endif
}
