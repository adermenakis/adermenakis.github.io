/**
 *     Copyright 2012 Alexandros Dermenakis
 *
 *  This file is part of the Mp3 Player.
 *  Mp3 Player is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *
 *  Mp3 Player is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 * 	along with the Mp3 Player. If not, see http://www.gnu.org/licenses/.
**/

#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <stdio.h>

// #define USE_HD4478 1 /** Use the 2x16 display **/
#define USE_5110 /** Use the big display **/

#ifdef USE_5110
#define SONGS_PER_SCREEN 6
#elif USE_HD4478
#define SONGS_PER_SCREEN 2
#endif

#define DISABLE_JTAG() MCUCSR |= (1<<JTD);MCUCSR|= (1<<JTD)

/** System Defines **/
#define F_CPU 8000000UL  // 8.00 MHz

#define FALSE 0
#define TRUE 1
#define false 0
#define true 1

#define BUFFER_SIZE 512
// Global buffer instead of constantly allocating/deallocating
static uint8_t gBuffer[BUFFER_SIZE];

/** System types **/
typedef unsigned char bool;
typedef char CHAR;
typedef unsigned char BYTE;
typedef unsigned int WORD;
typedef unsigned long DWORD;

/** VS1003 defines **/
#define DEFAULT_VOLUME 0x0000
#define VOL_STEP 2
#define VOL_MAX 0x00
#define VOL_MIN 0x70

#define CLOCK_REG       0xc000          //0xc00 is fow VS1003 or higher version
//#define CLOCK_REG       0x9800        //0x9800 is for VS1011 VS1002

#define VS1003B_PORT    PORTC
#define VS1003B_DDR      DDRC
#define VS1003B_PIN      PINC

#define VS1003B_XRESET  0
#define VS1003B_DREQ    1
#define VS1003B_XDCS    2
#define VS1003B_XCS     3

#define VS1003B_INI()        VS1003B_DDR &= 0x00; VS1003B_PORT = 0x00; VS1003B_DDR |= _BV(VS1003B_XRESET)|_BV(VS1003B_XDCS)|_BV(VS1003B_XCS)

/** mmc defines **/
#define MMC_SD_PORT       PORTB
#define MMC_SD_CS_PIN     4 //mega16
#define DDR_SPI() DDRB |= _BV(4)|_BV(5)|_BV(7)  //mega16

/** fat defines **/
#define FIX_DIRECTORY 0		/* 1 means use fix directory, 0 for any directory */

#if FIX_DIRECTORY == 0
#define  RECORD_ADDR_START 0	/* eeprom start address */
#define  RECORD_ADDR_END  512	/* eeprom end address */
#endif

/** LCD 5110 defines **/
#define LCD_5110_PORT PORTA
#define LCD_5110_DDR DDRA
#define SetDC      LCD_5110_PORT |= 0b00000100
#define ClearDC    LCD_5110_PORT &=~0b00000100
#define SetDI      LCD_5110_PORT |= 0b00000010
#define ClearDI    LCD_5110_PORT &=~0b00000010
#define SetSCL     LCD_5110_PORT |= 0b00000001
#define ClearSCL   LCD_5110_PORT &=~0b00000001
#define SetSCE     LCD_5110_PORT |= 0b00001000
#define ClearSCE   LCD_5110_PORT &=~0b00001000
#define SetRST     LCD_5110_PORT |= 0b00010000
#define ClearRST   LCD_5110_PORT &=~0b00010000

/** Button processor **/
#define BUTTON_PROCESSOR_PORT PORTD
#define BUTTON_PROCESSOR_DDR DDRD
#define BUTTON_PROCESSOR_PIN PIND


#define BUTTON_UP 0x02
#define BUTTON_DOWN 0x20
#define BUTTON_LEFT 0x04
#define BUTTON_RIGHT 0x01
#define BUTTON_BACK 0x10
#define BUTTON_ENTER 0x08
#define BUTTON_PAUSE BUTTON_ENTER
#define BUTTON_STOP BUTTON_ENTER
#define BUTTON_PLAY BUTTON_RIGHT
#define BUTTON_VOL_UP BUTTON_UP
#define BUTTON_VOL_DOWN BUTTON_DOWN

#endif // __CONFIG_H__
