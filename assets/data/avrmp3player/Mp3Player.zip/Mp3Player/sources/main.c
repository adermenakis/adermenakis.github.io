/**
 *     Copyright 2012 Alexandros Dermenakis
 *
 *  This file is part of the Mp3 Player.
 *  Mp3 Player is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *
 *  Mp3 Player is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 * 	along with the Mp3 Player. If not, see http://www.gnu.org/licenses/.
**/

#include "config.h"
#include "display/lcd_5110.h"
#include "display/display.h"
#include "mmc/mmc.h"
#include "mmc/fat.h"
#include "vs1003/vs1003.h"

/** Initialize the Screen **/
void system_init()
{
	display_init();
	// Make sure JTAG is disabled since
	// we are using the JTAG pins
	BUTTON_PROCESSOR_DDR = 0x00;
	BUTTON_PROCESSOR_PORT = 0xFF;
}

extern struct SongStruct gSongs[6];
extern uint16_t gTotalSongs;			//total songs in the root directery on the SD card
extern char* gSongNameArr[6];
extern uint16_t gBufferFromSong;

int main(void)
{
  
  system_init();

  OSCCAL = 0xFF;
  
  display_clear();
  
  _delay_ms(10);

  MMC_SD_Init(); //SPI initialize
  
  _delay_ms(10);
  
  VS1003B_Init();
  
  _delay_ms(10);
  
  MMC_SD_Reset();
    
  _delay_ms(10); //wait for stable

  FAT_Init();
  
  SearchInit();

  gBufferFromSong = 0;
  FAT_GetSongs(0,SONGS_PER_SCREEN,gSongs);
  FAT_GetNumOfSongs(&gTotalSongs);
  
  _delay_ms(10);
  
  player_main_loop();
}
