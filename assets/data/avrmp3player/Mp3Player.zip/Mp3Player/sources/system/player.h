/**
 *     Copyright 2012 Alexandros Dermenakis
 *
 *  This file is part of the Mp3 Player.
 *  Mp3 Player is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *
 *  Mp3 Player is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 * 	along with the Mp3 Player. If not, see http://www.gnu.org/licenses/.
**/

#ifndef __PLAYER_H__ 
#define __PLAYER_H__

#include <stdio.h>

/* Display the songs on the screen */
void player_song_list_screen();
/* Display the song playing with the progress bar */
uint8_t player_song_playing_screen();
/* The state machine that handles all the mp3 player logic */
void player_main_loop();
/* Converts the time stamp from the mp3 player to 00:00 format */
char* player_sec_2_str(uint16_t t);

#endif // __PLAYER_H__
