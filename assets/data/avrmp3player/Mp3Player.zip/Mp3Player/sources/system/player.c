/**
 *     Copyright 2012 Alexandros Dermenakis
 *
 *  This file is part of the Mp3 Player.
 *  Mp3 Player is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *
 *  Mp3 Player is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 * 	along with the Mp3 Player. If not, see http://www.gnu.org/licenses/.
**/

#include "player.h"
#include "../config.h"
#include "../display/display.h"
#include <util/delay.h>
#include "../mmc/mmc.h"
#include "../mmc/fat.h"
#include "../vs1003/vs1003.h"

extern uint16_t SectorsPerClust;
extern uint16_t FirstDataSector; //struct of file information
extern uint8_t  FAT32_Enable;

uint16_t gCursorPos = 0; //current song, within current song block
uint16_t gMasterCursorPos = 0; //current song, within total number of songs
uint8_t gVolume = 0;
	
struct SongStruct gSongs[SONGS_PER_SCREEN];
struct SongStruct gCurrentSong;
uint16_t gTotalSongs;			//total songs in the root directery on the SD card
uint16_t gBufferFromSong;
char* gSongNameArr[SONGS_PER_SCREEN];
bool gPlaying = false; //song is playing

void player_song_list_screen()
{
	uint16_t i = 0;
	
	for(i = 0; i < SONGS_PER_SCREEN; i++)
		gSongNameArr[i] = gSongs[i].deName;
	
	display_clear();
	display_writeString_block(gCursorPos,gSongNameArr);
}

char* player_sec_2_str(uint16_t t)
{
	static char tmp_str[5] = "00:00";
	static uint16_t tmp;
	
	if (t == 0xFFFF)
	{
		tmp = 0;
		sprintf(tmp_str,"00:00");
	}
	
	else if(t != 0 && t > tmp)
	{
		sprintf(tmp_str,"%.2d:%.2d",t / 60,t % 60);
		tmp = t;
	}
	
	return tmp_str;
}

uint8_t player_song_playing_screen()
{
	uint32_t cluster = 0;
	uint16_t count = 0; //data counting
	uint32_t totalSectors = 0; //calculate the total sectors
	uint8_t i = 0;
	uint8_t j = 0;
	uint32_t sector = 0;
	uint8_t volume_ctr = 0;
	char str[5];

	
	// Make a copy because we might update the buffer of songs
	memcpy(&gCurrentSong,&gSongs[gCursorPos],sizeof(SongStruct));
	
	//the first cluster of the file
	cluster = gCurrentSong.deStartCluster+(((uint32_t)gCurrentSong.deHighClust)<<16);
	totalSectors = gCurrentSong.deFileSize / 512; //calculate the total sectors
	
	VS1003B_Send_Zeros();
	VS1003B_SoftReset();//soft reset //in case of playing wma files//Èí¼þ¸´Î»
    
    _delay_ms(500);
	
	// Zero the playing time
	player_sec_2_str(0xFFFF);
	
    while(1)
    {
		//if pause is pressed, invert present state
		if(!(BUTTON_PROCESSOR_PIN & BUTTON_ENTER))
		{
			gPlaying = !gPlaying;
			_delay_ms(200);
		}
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_RIGHT))
		{
			_delay_ms(200);
			return 1;
		}			
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_LEFT))
		{
			//Dirty way and fails under certain scenarios
			// FIX THIS!!
			if(gCursorPos > 0)
			{
				gCursorPos -= 2;
				gMasterCursorPos -= 2;
				_delay_ms(200);
				return 1;
			}
			
			
			_delay_ms(200);
			return 0;
			
		}	
		//if Right is pressed, increase volume
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_UP) && gVolume > VOL_MAX)
		{	
			//Only increase if volume if at least one volume step remains until max volume
			// 0x00 High Volume
			gVolume -= VOL_STEP;
			VS1003B_WriteCMD(SCI_VOL, (uint16_t)(gVolume | gVolume << 8));	
			volume_ctr = 1;
		}			
		//If Left is pressed, decrease volume
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_DOWN) && gVolume < VOL_MIN)
		{
			//Only decrease if at least one volume step remains until min volume
			// 0x68 low Volume
			gVolume += VOL_STEP;
			VS1003B_WriteCMD(SCI_VOL, (uint16_t)(gVolume | gVolume << 8));
			volume_ctr = 1;
		}
		//Break if stop is pressed.
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_BACK))
		{
			_delay_ms(200);
			break;
		}		
		
		// Adding some delay in screen refresh
		if(!(sector % 20) || !gPlaying)
		{
			display_clear();
			
			if(volume_ctr > 0)
			{
				volume_ctr++;
				display_volume_bar(100*(VOL_MIN-gVolume)/VOL_MIN);
			}
			
			if(volume_ctr == 3)
				volume_ctr = 0;
				
			//Display current info: Volume 0-100, Play/Pause, name of song, volume 0-100, time elapsed, and status bar		
			display_println(gCurrentSong.deName);
			display_println(player_sec_2_str(VS1003B_ReadCMD(SCI_DECODE_TIME)));
			//sprintf(str, "%d" ,gMasterCursorPos);
			//display_println(str);
			display_progress_bar(100 * sector / totalSectors);
			
			if(gPlaying)
				display_println("\x1d"); // Play character
			else
				display_println("\x07"); // Pause character
		}
		
		//Get data and send to codec, if not in pause mode
		if(gPlaying)
		{
    		for(;i < SectorsPerClust; i++) // Indexing a cluster and transmitting it
			{
				if(FAT_LoadPartCluster(cluster,i,gBuffer)) //reading a sector
					display_println("Error cluster");
			
				count = 0;
				while(count < BUFFER_SIZE)
				{
					if((VS1003B_PIN & _BV(VS1003B_DREQ)) != 0 ) //send data  honoring DREQ
					{
						for(j = 0; j < 32; j++) //32 Bytes each time
						{
							VS1003B_WriteDAT(gBuffer[count]);
							count++;
						}
						if(sector >= totalSectors) //if this is the end of the file
							return 1;
					}
				}
				sector++;
			}
        
			i = 0;
			cluster = FAT_NextCluster(cluster); //read next cluster
			if(cluster == 0x0fffffff || cluster == 0x0ffffff8 || (FAT32_Enable == 0 && cluster == 0xffff)) //no more clusters
			{
				//if(mode==REPET_ALL)songs++;
				//if(songs>gTotalSongs)songs=1;
				break;
			}
		}	
		//Delay loop if pause is activated, to decrease display flicker
		else
			_delay_ms(200);
    }

	return 0;
}

void player_main_loop()
{	
	for(;;)
	{
		//If button down is pressed and bottom of screen is reached and songs remain
		if((!(BUTTON_PROCESSOR_PIN & BUTTON_DOWN) || gPlaying) &&
				gCursorPos == SONGS_PER_SCREEN - 1 &&
				gBufferFromSong < gTotalSongs)
		{
			gBufferFromSong += SONGS_PER_SCREEN;
			FAT_GetSongs(gBufferFromSong,SONGS_PER_SCREEN,gSongs);
			gCursorPos = 0;
			gMasterCursorPos++;
		}
		//Else if DOWN is pressed and cursor position is not at screen bottom and 
		//master cursor is less then number of songs on the disk 
		else if((!(BUTTON_PROCESSOR_PIN & BUTTON_DOWN) || gPlaying) &&
									gCursorPos < SONGS_PER_SCREEN - 1 &&
									gMasterCursorPos < gTotalSongs - 1)
		{
			gCursorPos++;
			gMasterCursorPos++;
		}
		//If UP is pressed and at top of screen and "upper" songs remain
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_UP) && gCursorPos == 0 &&
												gBufferFromSong != 0)
		{
			gBufferFromSong -= SONGS_PER_SCREEN;
			FAT_GetSongs(gBufferFromSong,SONGS_PER_SCREEN,gSongs);
			gCursorPos = 5;
			gMasterCursorPos--;
		}		
		//Else if UP is pressed and not at top of screen
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_UP) && gCursorPos > 0 )
		{
			gCursorPos--;
			gMasterCursorPos--;
		}
		//if ENTER is pressed
		else if(!(BUTTON_PROCESSOR_PIN & BUTTON_ENTER))
			gPlaying = true;
					
		if(gPlaying == false)	//if not playing, display current block of songs
			player_song_list_screen();
		else               //else, reset playing flag and go to play screen
		{
			if(gCursorPos == -1)
			{
				gMasterCursorPos += 1;
				gCursorPos = 0;
			}	
			gPlaying = player_song_playing_screen();
			
			if(gMasterCursorPos == gTotalSongs - 1)
				gPlaying = false;
		}
		_delay_ms(200); 
	}
}
