/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#include "stdafx.h"
#include "Cloth.h"

void Cloth::handleCollision(float r, Vector3f p)
{
    // use openMP to parallelize the expand the for loop
    // according to the number of logical cores of the system
    //#pragma omp parallel for
    for(int i = 0; i < mParticles.size(); i++)
    {
        ClothParticle &particle = mParticles[i];

        Vector3f v = particle.getPos()-p;
        float l = v.norm();
        if ( v.norm() < r) // if the particle is inside the ball
        {
             // project the particle to the surface of the ball
            particle.offsetPos(v.normalized()*r);
        }
    }
}

void Cloth::addWindForce(const Vector3f direction)
{
    for(int i = 0; i < mTriangles.size(); i++)
    {
        addWindForceToTriangle(*mTriangles[i],direction);
    }
}

void Cloth::addForce(const Vector3f direction)
{
    std::vector<ClothParticle>::iterator particle;
    for(particle = mParticles.begin(); particle != mParticles.end(); particle++)
    {
        (*particle).addForce(direction); // add the forces to each particle
    }

}

void Cloth::update()
{
    std::vector<ParticleConnection>::iterator constraint;

    // Perform 15 iterations for the simulation. Solves the particle
    // constraints 15 times per frame
    for(int i = 0; i < 15; i++)
    {
        // use openMP to parallelize the expand the for loop
        // according to the number of logical cores of the system
        //#pragma omp parallel for
        for(int j = 0; j < mConnections.size(); j++)
        {
            // satisfy constraint
            mConnections[j].satisfyConstraint();
        }
    }

    std::vector<ClothParticle>::iterator particle;
    for(particle = mParticles.begin(); particle != mParticles.end(); particle++)
    {
        // Solve the system
        (*particle).update(mDampingCoeff, 0.25f);
    }
}


void Cloth::draw()
{
    // Glow has seems to load the textures in separate thread and loading
    // the textures in a different OpenGL Context when using
    // The UI to directly loa the texture, hence the code was transfered here
    if(!TextureManager::getInstance()->hasTexture(mTexture))
        TextureManager::getInstance()->loadTexture(mTextureWPath, mTexture);

    glDisable(GL_COLOR_MATERIAL);
    glEnable(GL_TEXTURE_2D);
    glColor3f(1.0f, 1.0f, 1.0f);
    TextureManager::getInstance()->enableTexture(mTexture);
    glBegin(GL_TRIANGLES);
    glTexCoord2f(0.0f, 0.0f);

    // Draw the cloth's triangles
    for(int i = 0; i < mTriangles.size(); i++)
        mTriangles[i]->draw();

    glTexCoord2f(1.0f, 1.0f);
    glEnd();

    glDisable(GL_TEXTURE_2D);
}

void Cloth::prepareCloth()
{
    mParticles.clear();
    mParticles.resize(mHorizontalParticles*mVerticalParticles); //I am essentially using this vector as an array with room for mHorizontalParticles*mVerticalParticles mParticles

    // creating mParticles in a grid of mParticles from (0,0,0) to (width,0,-height)
    for(int x = 0; x < mHorizontalParticles; x++)
    {
        for(int y = 0; y < mVerticalParticles; y++)
        {
            // Compute the initial cloth particle positions
            // by default the cloth lyies on the XZ plane
            Vector3f pos = Vector3f(mWidth * (x/(float)mHorizontalParticles),
                0,
                mHeight * (y/(float)mVerticalParticles));
            mParticles[y*mHorizontalParticles+x]= ClothParticle(pos); 
        }
    }

    // Prepare the triangles that are being drawn
    for(int x = 0; x < mHorizontalParticles-1; x++)
    {
        for(int y = 0; y < mVerticalParticles-1; y++)
        {
            // Construct triangles between the particles and add them to the cloth
            Triangle *tr1 = new Triangle(getParticle(x+1,y),getParticle(x,y),getParticle(x,y+1), x, y, mHorizontalParticles, mVerticalParticles, false);
            Triangle *tr2 = new Triangle(getParticle(x+1,y+1),getParticle(x+1,y),getParticle(x,y+1), x, y, mHorizontalParticles, mVerticalParticles, true);

            getParticle(x+1,y)->addTriange(tr1);
            getParticle(x,y)->addTriange(tr1);
            getParticle(x,y+1)->addTriange(tr1);

            getParticle(x+1,y+1)->addTriange(tr2);
            getParticle(x+1,y)->addTriange(tr2);
            getParticle(x,y+1)->addTriange(tr2);

            mTriangles.push_back(tr1);
            mTriangles.push_back(tr2);
        }
    }

    // construct the connections between the particles according to the
    // algorithm discussed on the papers referenced on www.alexandrosdermenakis.com/clothsimulation
    for(int x = 0; x < mHorizontalParticles; x++)
    {
        for(int y = 0; y < mVerticalParticles; y++)
        {
            if (x < mHorizontalParticles-1) addConnection(getParticle(x,y),getParticle(x+1,y));
            if (y < mVerticalParticles-1) addConnection(getParticle(x,y),getParticle(x,y+1));
            if (x < mHorizontalParticles-1 && y < mVerticalParticles-1) addConnection(getParticle(x,y),getParticle(x+1,y+1));
            if (x < mHorizontalParticles-1 && y < mVerticalParticles-1) addConnection(getParticle(x+1,y),getParticle(x,y+1));
        }
    }

    for(int x = 0; x < mHorizontalParticles; x++)
    {
        for(int  y= 0; y < mVerticalParticles; y++)
        {
            if (x < mHorizontalParticles-2) addConnection(getParticle(x,y),getParticle(x+2,y));
            if (y < mVerticalParticles-2) addConnection(getParticle(x,y),getParticle(x,y+2));
            if (x < mHorizontalParticles-2 && y<mVerticalParticles-2) addConnection(getParticle(x,y),getParticle(x+2,y+2));
            if (x  <mHorizontalParticles-2 && y<mVerticalParticles-2) addConnection(getParticle(x+2,y),getParticle(x,y+2));			}
    }
    
    // Make the top corners unmovable
    getParticle(0 ,0)->makeUnmovable();
    getParticle(mHorizontalParticles-1 ,0)->makeUnmovable();
}

// Apply a wind force to the triangles of the 
void Cloth::addWindForceToTriangle(Triangle triangle, const Vector3f direction)
{
    Vector3f d = triangle.getNormal();
    Vector3f force = triangle.getNormal()*(d.dot(direction));
    triangle.getParticle1()->addForce(force);
    triangle.getParticle2()->addForce(force);
    triangle.getParticle3()->addForce(force);
}