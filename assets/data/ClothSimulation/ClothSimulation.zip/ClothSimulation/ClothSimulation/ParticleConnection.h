/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef PARTCILECONNECTION_H
#define PARTCILECONNECTION_H

class ParticleConnection
{
private:
	float mRestDistance;
    ClothParticle *mParticle1, *mParticle2;

public:
	ParticleConnection(ClothParticle *p1, ClothParticle *p2) :  mParticle1(p1),mParticle2(p2)
	{
		Vector3f vec = mParticle1->getPos() - mParticle2->getPos();
        mRestDistance = vec.norm();
	}

    /* places two particles in rest distance from each other several
    times per cycle */
	void satisfyConstraint()
	{
		Vector3f part1ToPart2 = mParticle2->getPos() - mParticle1->getPos(); // vector from p1 to p2
		float current_distance = part1ToPart2.norm(); // current distance between p1 and p2
		Vector3f correctionVector = part1ToPart2*(1 - mRestDistance/current_distance); // The offset vector that could moves p1 into a distance of rest_distance to p2
		Vector3f correctionVectorHalf = correctionVector*0.5f; // Lets make it half that length, so that we can move BOTH p1 and p2.
		mParticle1->offsetPos(correctionVectorHalf); // correctionVectorHalf is pointing from p1 to p2, so the length should move p1 half the length needed to satisfy the constraint.
		mParticle2->offsetPos(-correctionVectorHalf); // we must move p2 the negative direction of correctionVectorHalf since it points from p2 to p1, and not p1 to p2.	
	}

};

#endif // PARTCILECONNECTION_H