/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef CLOTH_H
#define CLOTH_H

#include <vector>
#include "ClothParticle.h"
#include "ParticleConnection.h"
#include "TextureManager.h"
#include "Triangle.h"

#include <Eigen/Dense>

using namespace Eigen;

class Cloth
{
private:

	int mHorizontalParticles;
	int mVerticalParticles;
	float mWidth;
    float mHeight;
    float mMass;

    std::string mTexture;
    std::string mTextureWPath;
	std::vector<ClothParticle> mParticles; // all mParticles that are part of this cloth
	std::vector<ParticleConnection> mConnections; // alle constraints between mParticles as part of this cloth
    std::vector<Triangle*> mTriangles;

    float mDampingCoeff;

	ClothParticle* getParticle(int x, int y) { return &mParticles[y*mHorizontalParticles + x]; }
	inline void addConnection(ClothParticle *p1, ClothParticle *p2) { mConnections.push_back(ParticleConnection(p1,p2)); }

	/* A private method used by windForce() to calcualte the wind force for a single triangle 
	defined by p1,p2,p3*/
	void addWindForceToTriangle(Triangle triangle, const Vector3f direction);

    void prepareCloth();

public:

	/* This is a important constructor for the entire system of mParticles and constraints*/
	Cloth(float width, float height, int horizontalParticles, int verticalParticles, float dampingCoeff)
        : mWidth(width), mHeight(height), mHorizontalParticles(horizontalParticles),
        mVerticalParticles(verticalParticles), mDampingCoeff(dampingCoeff),
        mTexture("20-carpet-texture.jpg"), mTextureWPath("20-carpet-texture.jpg")
	{
        prepareCloth();
	}


	void draw();

	/* Update cycle	*/
	void update();

	/* adds constact forces to the particles */
	void addForce(const Vector3f direction);

	/* computes the wind force excerted on a each triangle */
	void addWindForce(const Vector3f direction);

	/* Sphere Collision detection using the position and radius of a sphere */
	void handleCollision(float r, Vector3f p);

    inline float getMass() { return mMass; }
    inline void setMass(float m)
    {
        mMass = m;
        float mass = m/(mHorizontalParticles*mVerticalParticles);
        for(int i = 0; i < mParticles.size(); i++) mParticles[i].setMass(mass);
    }

    inline float getWidth() { return mWidth; }
    inline void setWidth(float w) { mWidth = w; prepareCloth();}
    
    inline float getHeight() { return mHeight; }
    inline void setHeight(float h) { mHeight = h; prepareCloth();}

    inline float getDampingCoeff() { return mDampingCoeff; }
    inline void setDampingCoeff(float coeff) { mDampingCoeff = coeff; }

    inline int getNumOfHorizontalParticles() { return mHorizontalParticles; }
    inline void setNumOfHorizontalParticles(float hPart) { mHorizontalParticles = hPart; prepareCloth();}

    inline int getNumOfVerticalParticles() { return mVerticalParticles; }
    inline void setNumOfVerticalParticles(float vPart) { mVerticalParticles = vPart; prepareCloth();}
    
    inline std::string getTexture() { return mTexture; }
    inline void setTexture(std::string tex, std::string texPath = "") { mTexture = tex; mTextureWPath = texPath;}
};

#endif // CLOTH_H