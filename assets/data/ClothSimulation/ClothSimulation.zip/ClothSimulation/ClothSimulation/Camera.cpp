/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#include "StdAfx.h"
#include "Camera.h"

Camera::Camera(int iWidth, int iHeight) : 
    mZoomFactor(1.0), 
    mWindowWidth(iWidth), 
    mWindowHeight(iHeight),
    mYRot(0.0f),
    mXRot(0.0f)
{
    mAspectRatio = (float) iWidth / iHeight;

    mAxis[0] = 0.0f;
    mAxis[1] = 1.0f;
    mAxis[2] = 0.0f;

    mEye[0] = 0.0f; 
    mEye[1] = 1.0f; 
    mEye[2] = 10.0f;

    mCenter = Vector3f::Zero();
}

Camera::~Camera(void)
{
}

// Perform OpenGL Calls to apply the camera
void Camera::applyViewpoint()
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(mEye[0], mEye[1], mEye[2],
                mCenter[0], mCenter[1], mCenter[2],
                mAxis[0], mAxis[1], mAxis[2]);
        glScalef(mZoomFactor,mZoomFactor,mZoomFactor);
    glRotatef(mYRot, 0.0f, 1.0f, 0.0f);
    glRotatef(mXRot, 1.0f, 0.0f, 0.0f);
}

// Panning method
void Camera::pan(int x, int y)
{
    float dx = x;// * 0.05f;
    float dy = -y;// * 0.05f;

    mEye[0] -= dx; 
    mEye[1] -= dy;

    mCenter[0] -= dx; 
    mCenter[1] -= dy;
}

// Zooming method
void Camera::zoom(float z)
{
    mZoomFactor = z;
}

// Window resized callback
void Camera::windowSizeChange(int iWidth, int iHeight)
{
    mWindowWidth = iWidth;
    mWindowHeight = iHeight;
    mAspectRatio = (float) iWidth / iHeight;

    int wSide = (iWidth < iHeight)  ? iWidth : iHeight;
    glViewport((iWidth - wSide) / 2, (iHeight - wSide) / 2, wSide, wSide);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(FIELD_OF_VIEW * mZoomFactor, mAspectRatio, VIEW_NEAR, VIEW_FAR);  
    glViewport(0, 0, iWidth, iHeight);
    glMatrixMode(GL_MODELVIEW);
}
