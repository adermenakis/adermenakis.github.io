/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef FORCE_H
#define FORCE_H

#include "stdafx.h"

class Force
{
private:
    Vector3f mForce;
    bool mIsEnabled;

public:
    Force() { mIsEnabled = true; mForce = Vector3f(0.01f,0.01f,0.01f); }
    Force(float x, float y, float z) { mIsEnabled = true; mForce = Vector3f(x,y,z); }
    Force(Vector3f f) { mIsEnabled = true; mForce = f;  }

    inline bool isEnabled() { return mIsEnabled; }
    inline void enable(bool en) { mIsEnabled = en; }

    inline Vector3f getForce() { return (isEnabled()) ? mForce : Vector3f::Zero(); }
    inline void setForce(Vector3f f) { mForce = f; }

    void draw()
    {
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_COLOR_MATERIAL);

        if(mIsEnabled)
            glColor3f(1.0f, 0.0f, 0.0f);
        else
            glColor3f(0.5f, 0.5f, 0.5f);

        glBegin(GL_LINES);
        glVertex3f(0, 0, 0);
        glVertex3f(mForce[0], mForce[1], mForce[2]);
        glEnd();
        
        glColor3f(1.0f, 1.0f, 1.0f);
        glEnable(GL_TEXTURE_2D);
        glDisable(GL_COLOR_MATERIAL);
    }
};

#endif // FORCE_H