/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#include "stdafx.h"
#include "ClothWindow.h"
#include "Camera.h"
#include "Cloth.h"
#include "ForcePanel.h"

ClothWindow::ClothWindow()
    :GlowWindow("Cloth Simulator", GlowWindow::autoPosition, GlowWindow::autoPosition,
    640, 480, Glow::rgbaBuffer | Glow::doubleBuffer,
    Glow::mouseEvents | Glow::dragEvents | Glow::menuEvents | Glow::motionEvents),
    mCamera(NULL),
    mMenu(NULL),
    mControlWindow(NULL),
    mSelectedCloth(0),
    mIsMouseButtonClicked(false)
{
    mCamera = new Camera(640, 480);
    mMenu = new GlowMenu();

    ConstructControlWindow();
    mCloths.push_back(new Cloth(14,10,25,25, 0.01f));
    mCloths[0]->setMass(625);
}


ClothWindow::~ClothWindow()
{
    if(mCamera) { delete mCamera; mCamera = NULL; }
    if(mMenu) { delete mMenu; mMenu = NULL; }
    if(mControlWindow) { delete mControlWindow; mControlWindow = NULL; }
}

// Constructs the main control window that drives the simulation's parameters
void ClothWindow::ConstructControlWindow()
{
    mControlWindow = new GlowQuickPaletteWindow("Cloth Controls");

    std::string panelString = "Cloth Simulation\n\n"
                            + std::string("by Alexandros Dermenakis\n");
    mControlWindow->AddLabel(panelString.c_str());
    
    mZoomSlider = mControlWindow->AddSlider(1.0f, 10.0f, 10.0f, GlowSliderWidget::logarithmic, 1, "%.0f", "Zoom:\n%.0f", this);
    mDampingSlider = mControlWindow->AddSlider(0.00001f, 0.2f, 0.01f, GlowSliderWidget::logarithmic, 1, "%.2f", "Damping Coefficient:\n%.6f", this);
    mMassSlider = mControlWindow->AddSlider(0.1f, 10.0f, 1.0f, GlowSliderWidget::logarithmic, 1, "%.2f", "Mass:\n%.2f", this);

    GlowQuickPanelWidget *panel = mControlWindow->AddPanel(GlowQuickPanelWidget::etchedStyle, "Ball");
    mBallRadiusSlider = panel->AddSlider(0.1f, 10.0f, 1.0f, GlowSliderWidget::logarithmic, 1, "%.2f", "Radius:\n%.2f", this);
    mIsXBallNegativeCheckBox = panel->AddCheckBox("NegativeX", GlowCheckBoxWidget::off, this);
    mBallXSlider = panel->AddSlider(0.1f, 10.0f, 1.0f, GlowSliderWidget::logarithmic, 1, "%.2f", "Ball X:\n%.2f", this);
    mIsYBallNegativeCheckBox = panel->AddCheckBox("NegativeY", GlowCheckBoxWidget::off, this);
    mBallYSlider = panel->AddSlider(0.1f, 10.0f, 1.0f, GlowSliderWidget::logarithmic, 1, "%.2f", "Ball Y:\n%.2f", this);
    mIsZBallNegativeCheckBox = panel->AddCheckBox("NegativeZ", GlowCheckBoxWidget::off, this);
    mBallZSlider = panel->AddSlider(0.1f, 10.0f, 1.0f, GlowSliderWidget::logarithmic, 1, "%.2f", "Ball Z:\n%.2f", this);

    mLoadTextureButton = mControlWindow->AddPushButton("Load Texture", this);
    mLoadedTextures = mControlWindow->AddPopupMenu("Texture :", this);
    mAddForceButton = mControlWindow->AddPushButton("Create Force", this);
    mControlWindow->Pack();
}

// Draws the cloths. It is expandable to add more cloths but this
// version supports just one cloth
void ClothWindow::DrawCloths()
{
    for(int i = 0; i < mCloths.size(); i++)
        mCloths[i]->draw();
}

// Default glow callback when reshaping the drawing window
void ClothWindow::OnReshape(int w, int h)
{
    mCamera->windowSizeChange(w, h);
}

// Handles clicks on push buttons
void ClothWindow::OnMessage(const GlowPushButtonMessage& m)
{
    if(m.widget == mLoadTextureButton)
    {
        std::string fileName = OpenFileDialog();
        if(fileName != "")
        {
            string name = fileName.substr(fileName.find_last_of('\\')+1, fileName.find_last_of('.'));

            TextureManager::getInstance()->loadTexture(fileName.c_str(),name);
            mCloths[mSelectedCloth]->setTexture(fileName.c_str(), name);
            mLoadedTextures->AddItem(name.c_str());
        }
    }
    else if(m.widget == mAddForceButton)
    {
        mForcePanels.push_back(new ForcePanel());
    }
}

// Handles popup menu clicks. More specifically the texture loading window
void ClothWindow::OnMessage(const GlowPopupMenuMessage& m)
{
    mCloths[mSelectedCloth]->setTexture(m.widget->GetItemLabel(m.widget->GetCurItem()));
}

// Uses the default windows C code for the open file dialog
std::string ClothWindow::OpenFileDialog(const char* filter)
{
OPENFILENAME ofn;
char fileName[MAX_PATH] = "";
ZeroMemory(&ofn, sizeof(ofn));
 
ofn.lStructSize = sizeof(OPENFILENAME);
ofn.hwndOwner = NULL;
ofn.lpstrFilter = filter;
ofn.lpstrFile = fileName;
ofn.nMaxFile = MAX_PATH;
ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
ofn.lpstrDefExt = "";
 
string fileNameStr;
 
if ( GetOpenFileName(&ofn) )
fileNameStr = fileName;

return fileNameStr;
}

// Handles checkbox callbacks
void ClothWindow::OnMessage(const GlowCheckBoxMessage& m)
{
}

// Handles callbacks on sliders for changind simulation parameters
void ClothWindow::OnMessage(const GlowSliderMessage& m)
{
    Cloth *cloth = mCloths[mSelectedCloth];

    // Damping coefficient
    if(m.widget == mDampingSlider)
        cloth->setDampingCoeff(m.value);
    // Mass
    else if(m.widget == mMassSlider)
        cloth->setMass(m.value*cloth->getNumOfHorizontalParticles()
                                *cloth->getNumOfVerticalParticles());
    // Ball radius
    else if(m.widget == mBallRadiusSlider)
        mSphere.setRadius(m.value);
    // Ball's X Y Z position
    else if(m.widget == mBallXSlider)
    {
        Vector3f p = mSphere.getPosition();
        p[0] = m.value * ((mIsXBallNegativeCheckBox->GetState() == GlowCheckBoxWidget::on) ? -1 : 1);
        mSphere.setPosition(p);
    }
    else if(m.widget == mBallYSlider)
    {
        Vector3f p = mSphere.getPosition();
        p[1] = m.value * ((mIsYBallNegativeCheckBox->GetState() == GlowCheckBoxWidget::on) ? -1 : 1);
        mSphere.setPosition(p);
    }
    else if(m.widget == mBallZSlider)
    {
        Vector3f p = mSphere.getPosition();
        p[2] = m.value * ((mIsZBallNegativeCheckBox->GetState() == GlowCheckBoxWidget::on) ? -1 : 1);
        mSphere.setPosition(p);
    }
    // Zooming
    else if(m.widget == mZoomSlider)
    {
        mCamera->zoom(mZoomSlider->GetValue()/10.0f);
    }
}

// Update method for calculating the parameters of the next frame
void ClothWindow::Update()
{
    for(int i = 0; i < mCloths.size(); i++)
    {
        mCloths[i]->handleCollision(mSphere.getRadius(), mSphere.getPosition());
        for(int j = 0; j < mForcePanels.size(); j++)
        {
            if(mForcePanels[j]->isWind())
                mCloths[i]->addWindForce(mForcePanels[j]->getForce().getForce());
            else
                mCloths[i]->addForce(mForcePanels[j]->getForce().getForce());
        }
        // Gavitational force always applied
        mCloths[i]->addForce(Vector3f(0,-0.005,0));
        mCloths[i]->update();
    }
}

// Callback when pressing mouse buttons
void ClothWindow::OnMouseDown(Glow::MouseButton button, int x, int y, Glow::Modifiers modifiers)
{
    mIsMouseButtonClicked = true;
    mLastMouseButton = button;

    // Allow panning when pressing the middle mouse
    if(button == Glow::MouseButton::middleButton ||
        button == Glow::MouseButton::leftButton)
   {
       mLastMouseButton = button;
       mMouseDx = 0;
       mMouseDy = 0;
   }
}

// Callback when a mouse button is released
void ClothWindow::OnMouseUp(Glow::MouseButton button, int x, int y, Glow::Modifiers modifiers)
{
    mIsMouseButtonClicked = false;
    mLastMouseButton = button;

    if(button == Glow::MouseButton::middleButton ||
        button == Glow::MouseButton::leftButton)
   {
       mLastMouseButton = button;
       mMouseDx = 0;
       mMouseDy = 0;
   }
}

// Allow panning if the mouse button is pressed
void ClothWindow::OnMouseDrag(int x, int y)
{
    OnMouseMotion(x, y);
}
                                            
// Keeps the last position of the mouse within the window
void ClothWindow::OnMouseMotion(int x, int y)
{
   static int lastX,lastY;

   mMouseDx = x - lastX;
   mMouseDy = y - lastY;

   if(mLastMouseButton == Glow::MouseButton::middleButton &&
                                mIsMouseButtonClicked)
   {
       mCamera->pan(mMouseDx*0.3, mMouseDy*0.3);
   }
   else if(mLastMouseButton == Glow::MouseButton::leftButton &&
                                mIsMouseButtonClicked)
   {
       mCamera->rotate(mMouseDy*0.1,mMouseDx*0.1);
   }

   lastX = x;
   lastY = y;
}

// Default draw method similar to glutDisplayFunc which is called
// by GLOW on the background
void ClothWindow::OnEndPaint()
{
    // Seems that something gets screwed either by Glow
    // of by the drawing code hence need to re-initialize
    // before attempting to draw
    Init();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

    // Apply the camera
    mCamera->applyViewpoint();
    
	glEnable(GL_LIGHTING);

    // The update function is called here because there were issues
    // when setting up a timer to update the screen. The update method
    // was taking long and the timer was getting un-registered
    Update();
    DrawCloths(); // finally draw the cloth with smooth shading
    
    // Draw all the forces coming from the force panels
    for(int i = 0; i < mForcePanels.size(); i++)
        mForcePanels[i]->getForce().draw();

    glEnable(GL_LIGHTING);

    // Draw the sphere
    mSphere.draw();

    Refresh();
}

// OpenGL initialization method
void ClothWindow::Init()
{
    glShadeModel(GL_SMOOTH);
	glClearColor(0.2f, 0.2f, 0.4f, 0.5f);				
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	GLfloat lightPos[4] = {-1.0,1.0,0.5,0.0};
	glLightfv(GL_LIGHT0,GL_POSITION,(float *) &lightPos);

	glEnable(GL_LIGHT1);

	GLfloat lightAmbient1[4] = {0.0,0.0,0.0,0.0};
	GLfloat lightPos1[4] = {1.0,0.0,-0.2,0.0};
	GLfloat lightDiffuse1[4] = {0.5,0.5,0.3,0.0};

	glLightfv(GL_LIGHT1,GL_POSITION,(float *) &lightPos1);
	glLightfv(GL_LIGHT1,GL_AMBIENT,(float *) &lightAmbient1);
	glLightfv(GL_LIGHT1,GL_DIFFUSE,(float *) &lightDiffuse1);

	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);
}