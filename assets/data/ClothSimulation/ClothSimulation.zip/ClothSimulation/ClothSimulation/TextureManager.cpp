/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#include "stdafx.h"
#include "TextureManager.h"
#include "Soil/SOIL.h"

TextureManager* TextureManager::mInstance = NULL;

// Return the texture id that was generated from SOIL
GLuint TextureManager::getTexture(string iName)
{
  return mTextures[iName];
}

// load the texture specified from the path and add it to a hash map with the name provided
GLuint TextureManager::loadTexture(string iFilename, string iName)
{
    if (mTextures[iName] != NULL)
    {
        return mTextures[iName];
    }
    else
    {
        // 2D Textures MUST be enabled when loading with SOIL
        glEnable(GL_TEXTURE_2D);
        GLuint lTexture = SOIL_load_OGL_texture
            (
            iFilename.c_str(),
            SOIL_LOAD_AUTO,
            SOIL_CREATE_NEW_ID,
            SOIL_FLAG_MULTIPLY_ALPHA | SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
            );

        /* check for an error during the load process */
        if( lTexture == 0 )
        {
            //__debugbreak();
            printf( "SOIL loading error: '%s'\n", SOIL_last_result() );
            return NULL;
        }

        mTextures[iName] = lTexture;

        glDisable(GL_TEXTURE_2D);

        return lTexture;
    }
}

TextureManager::TextureManager()
{

}

// Singleton class, hence this method returns the single instance of the class
TextureManager* TextureManager::getInstance()
{
    if(!mInstance)
        mInstance = new TextureManager();

    return mInstance;
}

// Enable the texture specified as argument
void TextureManager::enableTexture(std::string iName)
{
    // Default OpenGL code for binding a texture
    glBindTexture(GL_TEXTURE_2D, getTexture(iName));

    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
}
