/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef TEXTUREMANAGER_H
#define TEXTUREMANAGER_H

#include <map>
#include <string>
#include <GL/gl.h>

using std::string;

/**
TextureManager class

A class which facilitates loading textures
and binding them in OpenGL.
**/
class TextureManager
{
private:
    
    static TextureManager * mInstance;
    std::map<string, GLuint> mTextures;
    TextureManager();
   
protected:
public:
    
    /** Load a texture and put it in a hash map **/
    GLuint loadTexture(string iFilename, string iName);

    /** Return the ID of the texture associated with this name **/
    GLuint getTexture(string iName);

    /** Bing the texture associated with this name **/
    void enableTexture(string iName);
    
    bool hasTexture(string iName) { return (mTextures.count(iName) == 1); }

    /** Retruns the instance of the singleton **/
    static TextureManager* getInstance();
    
};

#endif // TEXTUREMANAGER_H
