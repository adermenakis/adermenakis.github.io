/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef CLOTHWINDOW_H
#define CLOTHWINDOW_H

#include "UI/GLOW/glow.h"
#include "UI/GLOW/glowQuickPalette.h"
#include "Sphere.h"

GLOW_NAMESPACE_USING

class MandelData;
class Cloth;
class Camera;
class ForcePanel;

// Notice the class inherits from GlowWindow. All toplevel window objects
// must inherit from this class.
class ClothWindow : public GlowWindow,
                    public GlowSliderReceiver, public GlowPushButtonReceiver,
                    public GlowPopupMenuReceiver, public GlowCheckBoxReceiver
{
	public:
	
		ClothWindow();
		virtual ~ClothWindow();

	protected:
	
		std::string OpenFileDialog(const char* filter = "All Files (*.*)\0*.*\0");

		virtual void OnEndPaint();
	    virtual void Init();
        virtual void OnReshape(int w, int h);
        virtual void OnMessage(const GlowSliderMessage& m);
        virtual void OnMessage(const GlowPushButtonMessage& m);
        virtual void OnMessage(const GlowPopupMenuMessage& m);
        virtual void OnMessage(const GlowCheckBoxMessage& m);
        virtual void OnMouseDown(Glow::MouseButton button, int x, int y,
                                            Glow::Modifiers modifiers);
        virtual void OnMouseUp(Glow::MouseButton button, int x, int y,
                                            Glow::Modifiers modifiers);
        virtual void OnMouseMotion(int x, int y);
        virtual void OnMouseDrag(int x, int y);

        void ConstructControlWindow();

        void Update();
        void DrawCloths();

	private:

        Glow::MouseButton mLastMouseButton;
        bool mIsMouseButtonClicked;
        int mMouseDx;
        int mMouseDy;

        //UI Controls
        int mSelectedCloth;
        GlowSliderWidget *mDampingSlider;
        GlowSliderWidget *mMassSlider;
        GlowPushButtonWidget *mLoadTextureButton;
        GlowPushButtonWidget *mAddForceButton;
        GlowLabeledPopupMenuWidget *mLoadedTextures;
        GlowSliderWidget *mZoomSlider;

        GlowSliderWidget *mBallRadiusSlider;
        GlowSliderWidget *mBallXSlider;
        GlowSliderWidget *mBallYSlider;
        GlowSliderWidget *mBallZSlider;
        
        GlowCheckBoxWidget *mIsXBallNegativeCheckBox;
        GlowCheckBoxWidget *mIsYBallNegativeCheckBox;
        GlowCheckBoxWidget *mIsZBallNegativeCheckBox;

        std::vector<ForcePanel*> mForcePanels;
        GlowQuickPaletteWindow *mControlWindow;

        Sphere mSphere;

        GlowMenu *mMenu;
        Camera *mCamera;
        std::vector<Cloth*> mCloths;
};


#endif // CLOTHWINDOW_H