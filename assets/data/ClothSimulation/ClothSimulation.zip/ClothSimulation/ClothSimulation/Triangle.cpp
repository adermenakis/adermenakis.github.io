/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#include "StdAfx.h"
#include "Triangle.h"
#include "ClothParticle.h"

Triangle::Triangle(ClothParticle *p1, ClothParticle *p2, ClothParticle *p3,
                                int x, int y, int horPart, int verPart, bool isTop)
    {
        if(!isTop)
        {
            mTextureCoord[0][0] = (float)(x+1)/(float)horPart;
            mTextureCoord[0][1] = 1.0f-(float)y/(float)verPart;

            mTextureCoord[1][0] = (float)(x)/(float)horPart;
            mTextureCoord[1][1] = 1.0f-(float)y/(float)verPart;

            mTextureCoord[2][0] = (float)(x)/(float)horPart;
            mTextureCoord[2][1] = 1.0f-(float)(y+1)/(float)verPart;
        }
        else
        {
            mTextureCoord[0][0] = (float)(x+1)/(float)horPart;
            mTextureCoord[0][1] = 1.0f-(float)(y+1)/(float)verPart;

            mTextureCoord[1][0] = (float)(x+1)/(float)horPart;
            mTextureCoord[1][1] = 1.0f-(float)y/(float)verPart;

            mTextureCoord[2][0] = (float)(x)/(float)horPart;
            mTextureCoord[2][1] = 1.0f-(float)(y+1)/(float)verPart;
        }

        mParticle1 = p1;
        mParticle2 = p2;
        mParticle3 = p3;
    }

    // return the normal of the current triangle
    Vector3f Triangle::getNormal()
    {
		Vector3f v1 = mParticle2->getPos()-mParticle1->getPos();
		Vector3f v2 = mParticle3->getPos()-mParticle1->getPos();

        return v1.cross(v2).normalized();
    }

    // Draw the triangle
    void Triangle::draw()
    {

        glTexCoord2fv(mTextureCoord[0]);
		glNormal3fv((float*)&(mParticle1->getNormal().normalized()));
		glVertex3fv((float*)&(mParticle1->getPos()));

        glTexCoord2fv(mTextureCoord[1]);
		glNormal3fv((float*)&(mParticle2->getNormal().normalized()));
		glVertex3fv((float*)&(mParticle2->getPos()));

        glTexCoord2fv(mTextureCoord[2]);
		glNormal3fv((float*)&(mParticle3->getNormal().normalized()));
		glVertex3fv((float*)&(mParticle3->getPos()));
    }