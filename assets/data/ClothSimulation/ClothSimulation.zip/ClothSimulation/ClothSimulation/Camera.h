/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef CAMERA_H
#define CAMERA_H

#define VIEW_NEAR 0.01
#define VIEW_FAR 1000.0
#define FIELD_OF_VIEW 30.0

class Camera
{
public:
    Camera(int iWidth, int iHeight);
    ~Camera(void);

    void zoom(float z);
    void windowSizeChange(int iWidth, int iHeight);
    void pan(int x, int y);

    // Function which applies the camera details to the opengl context
    // Called on the paint (or equiv.) function on each iteration
    void applyViewpoint();

    inline void setCenter(GLfloat iX, GLfloat iY, GLfloat iZ)
    {
        mCenter[0] = iX;
        mCenter[1] = iY;
        mCenter[2] = iZ;
    }

    inline void setCameraPosition(GLfloat iX, GLfloat iY, GLfloat iZ)
    {
        mEye[0] = iX;
        mEye[1] = iY;
        mEye[2] = iZ;
    }
    
    inline void rotate(float x, int y)
    {
        mYRot += y;
        mXRot += x;
    }

private:
    Vector3f mCenter;
    Vector3f mEye;
    Vector3f mAxis;
    float mXRot;
    float mYRot;

    int mWindowWidth;
    int mWindowHeight;

    double mZoomFactor; 
    double mAspectRatio;

};

#endif