/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef FORCEPANEL_H
#define FORCEPANEL_H

#include "UI/GLOW/glowQuickPalette.h"
#include "Force.h"

GLOW_NAMESPACE_USING

class ForcePanel : public GlowQuickPaletteWindow, public GlowSliderReceiver,
                    public GlowCheckBoxReceiver, public GlowPushButtonReceiver
{
public:
    ForcePanel();
    ~ForcePanel();

    inline Force getForce() { return mForce; }
    bool isWind();
protected:
    virtual void OnMessage(const GlowSliderMessage& m);
    virtual void OnMessage(const GlowPushButtonMessage& m);
    virtual void OnMessage(const GlowCheckBoxMessage& m);

private:

    void constructPanel();
   
    Force mForce;

    GlowSliderWidget *mXMagnitudeSlider;
    GlowSliderWidget *mYMagnitudeSlider;
    GlowSliderWidget *mZMagnitudeSlider;

    GlowCheckBoxWidget *mIsEnabledCheckBox;
    GlowCheckBoxWidget *mIsWindCheckBox;

    GlowCheckBoxWidget *mIsXNegativeCheckBox;
    GlowCheckBoxWidget *mIsYNegativeCheckBox;
    GlowCheckBoxWidget *mIsZNegativeCheckBox;

    static int sForceCounter;
};

#endif // FORCEPANEL_H