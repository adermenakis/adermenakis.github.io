/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef CLOTHPARCTICLE_H
#define CLOTHPARCTICLE_H

class Triangle;
#include <vector>
#include "Triangle.h"

/* The particle class represents a particle of mass that can move around in 3D space*/
class ClothParticle
{
private:
	bool mIsMovable; // can the particle move or not ? used to pin parts of the cloth

	float mMass; // the mass of the particle (is always 1 in this example)
	Vector3f mPosition; // the current position of the particle in 3D space
	Vector3f mPrevPosition; // the position of the particle in the previous time step, used as part of the verlet numerical integration scheme
	Vector3f mAcceleration; // a vector representing the current acceleration of the particle
    
    std::vector<Triangle*> mTriangles;

public:
	ClothParticle(Vector3f pos) : mPosition(pos), mPrevPosition(pos),mAcceleration(Vector3f(0,0,0)),
                                                mMass(1), mIsMovable(true) {}
	ClothParticle(){}

    inline void addTriange(Triangle * triangle) { mTriangles.push_back(triangle);}

	void addForce(Vector3f f)
	{
        // Applying Newton's first law to compute the acceleration
        // using the force and mass of the object
		mAcceleration += f/mMass;
	}

    // Update method that computes the constrains for the cloth
	void update(float dampingCoeff, float timeStep)
	{
		if(mIsMovable)
		{
			Vector3f temp = mPosition;
			mPosition = mPosition + (mPosition-mPrevPosition)*(1.0-dampingCoeff) + mAcceleration*timeStep;
			mPrevPosition = temp;
            mAcceleration = Vector3f::Zero();
		}
	}

	Vector3f& getPos() {return mPosition;}

    inline void setMass(float m) { mMass = m; }
    inline float getMass() { return mMass; }

    inline Vector3f getAcceleration() { return mAcceleration; }

    inline Vector3f getVelocity() { return mPosition-mPrevPosition; }

	void resetAcceleration() {mAcceleration = Vector3f::Zero();}

	void offsetPos(const Vector3f v) { if(mIsMovable) mPosition += v;}

    void setPosition(Vector3f p) { mPosition = p; }

	void makeUnmovable() {mIsMovable = false;}

    // Computes the normals for all triangles
	Vector3f getNormal()
	{
        Vector3f n = Vector3f::Zero();
        for(int i = 0; i < mTriangles.size(); i++)
        {
            n += mTriangles[i]->getNormal();
        }

        n = n / mTriangles.size();

        return n;
	}
};

#endif // PARCTICLE_H