/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef SPHERE_H
#define SPHERE_H

#include <Eigen/Dense>

using namespace Eigen;

class Sphere
{
private:
    float mRadius;
    Vector3f mPosition;

public:
    Sphere() { mRadius = 1.0f; }
    Sphere(float r) { mRadius = r; }

    inline void setRadius(float r) { mRadius = r; }
    inline float getRadius() { return mRadius; }

    inline void setPosition(Vector3f p) { mPosition = p; }
    inline Vector3f getPosition() { return mPosition; } 

    void draw();
};

#endif // SPHERE_H