/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#include "StdAfx.h"
#include "ForcePanel.h"

int ForcePanel::sForceCounter = 0;

ForcePanel::ForcePanel()
    :GlowQuickPaletteWindow("")
{
    char title[255];
    sprintf(title, "Force %i Control Window", ++sForceCounter);

    SetTitle((const char*)&title);
    constructPanel();
    Pack();
}

ForcePanel::~ForcePanel()
{
}

// Handle slider callbacks
void ForcePanel::OnMessage(const GlowSliderMessage& m)
{
    Vector3f force = mForce.getForce();

    if(m.widget == mXMagnitudeSlider)
    {
        force[0] = m.value * ((mIsXNegativeCheckBox->GetState() == GlowCheckBoxWidget::on) ? -1 : 1);
        mForce.setForce(force);
    }
    else if(m.widget == mYMagnitudeSlider)
    {
        force[1] = m.value * ((mIsYNegativeCheckBox->GetState() == GlowCheckBoxWidget::on) ? -1 : 1);
        mForce.setForce(force);
    }
    else if(m.widget == mZMagnitudeSlider)
    {
        force[2] = m.value * ((mIsZNegativeCheckBox->GetState() == GlowCheckBoxWidget::on) ? -1 : 1);
        mForce.setForce(force);
    }
}

// returns if the force is of type wind. This is used in the ClothWindow class
bool ForcePanel::isWind()
{
    return mIsWindCheckBox->GetState();
}

void ForcePanel::OnMessage(const GlowPushButtonMessage& m)
{

}

// handle checkbox clicks
void ForcePanel::OnMessage(const GlowCheckBoxMessage& m)
{
    if(m.widget == mIsEnabledCheckBox)
     mForce.enable(m.state);        
}

// Construct the force panel
void ForcePanel::constructPanel()
{
    GlowQuickPanelWidget *panel = AddPanel(GlowQuickPanelWidget::etchedStyle, "Magnitude");
    mIsXNegativeCheckBox = panel->AddCheckBox("NegativeX", GlowCheckBoxWidget::off, this);
    mXMagnitudeSlider = panel->AddSlider(0.01f, 1.0f, 0.01f, GlowSliderWidget::logarithmic, 1, "%.2f", "X\n%.2f", this);
    mIsYNegativeCheckBox = panel->AddCheckBox("NegativeY", GlowCheckBoxWidget::off, this);
    mYMagnitudeSlider = panel->AddSlider(0.01f, 1.0f, 0.01f, GlowSliderWidget::logarithmic, 1, "%.2f", "Y\n%.2f", this);
    mIsZNegativeCheckBox = panel->AddCheckBox("NegativeZ", GlowCheckBoxWidget::off, this);
    mZMagnitudeSlider = panel->AddSlider(0.01f, 1.0f, 0.01f, GlowSliderWidget::logarithmic, 1, "%.2f", "Z\n%.2f", this);

    mIsWindCheckBox = AddCheckBox("Wind", GlowCheckBoxWidget::on, this);
    mIsEnabledCheckBox = AddCheckBox("Enabled", GlowCheckBoxWidget::on, this);    

}