/********************************************************************************
	PROJECT:
	
		Real Time Cloth Simulation
	
	PROGRAMMERS:
	
		Alexandros Dermenakis (AD)  <alexandros.dermenakis@gmail.com>
	
	COPYRIGHT:
	
		Copyright (C) 2011 Alexandros Dermenakis
		
		This library is free software; you can redistribute it and/or
		modify it under the terms of the GNU Lesser General Public
		License as published by the Free Software Foundation; either
		version 2.1 of the License, or (at your option) any later version.
		
		This library is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
		GNU Lesser General Public License for more details.
		
		You should have received a copy of the GNU Lesser General Public
		License along with this library; if not, write to
			Free Software Foundation, Inc.
			59 Temple Place, Suite 330
			Boston, MA 02111-1307 USA
********************************************************************************/

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <Eigen/Dense>

using namespace Eigen;

class ClothParticle;

class Triangle
{
private:
    ClothParticle *mParticle1;
    ClothParticle *mParticle2;
    ClothParticle *mParticle3;

    float mTextureCoord[3][2];
public:

    Triangle(ClothParticle *p1, ClothParticle *p2, ClothParticle *p3, int x, int y, int horPart, int verPart, bool isTop);

    Vector3f  getNormal();

    void draw();

    inline ClothParticle* getParticle1() { return mParticle1; }
    inline ClothParticle* getParticle2() { return mParticle2; }
    inline ClothParticle* getParticle3() { return mParticle3; }
};

#endif // TRIANGLE_H