﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace ZombieGame.Managers
{
    class ModelManager
    {
        private static Dictionary<String, Model> models = new Dictionary<String, Model>();
        private static ContentManager contentManager;

        public static void Load(ContentManager iContent)
        {
            contentManager = iContent;
            // Load the scenery
            models.Add("Cactus1", iContent.Load<Model>("cactus"));
            models.Add("Cactus2", iContent.Load<Model>("cactus2"));
            models.Add("Cactus3", iContent.Load<Model>("cactus3"));
            models.Add("Cactus4", iContent.Load<Model>("cactus4"));
            models.Add("Crate", iContent.Load<Model>("crate"));
            models.Add("House1", iContent.Load<Model>("House"));
            models.Add("RoadBlock", iContent.Load<Model>("RoadBlock"));
            models.Add("Bear", iContent.Load<Model>("Bear"));

            // Load the cars
            models.Add("Tank", iContent.Load<Model>("tank"));
            models.Add("Nissan", iContent.Load<Model>("nissan"));
            models.Add("Delorian", iContent.Load<Model>("delorian"));
            models.Add("Viper", iContent.Load<Model>("racecar"));

            // Load the zombies
            models.Add("Zard", iContent.Load<Model>("zard"));
            models.Add("Slug", iContent.Load<Model>("slug"));
            models.Add("HumanZombie", iContent.Load<Model>("humanZombie"));

            // Load othe objects
            models.Add("Wheel", iContent.Load<Model>("wheel"));
            models.Add("Flag", iContent.Load<Model>("Flag"));
            models.Add("CheckPointArrow", iContent.Load<Model>("Arrow"));

            // Load Menu Objects
            models.Add("ContinueButton", iContent.Load<Model>("Menus\\Continue"));
            models.Add("OptionsButton", iContent.Load<Model>("Menus\\Options"));
            models.Add("NewGameButton", iContent.Load<Model>("Menus\\New Game"));
            models.Add("ReturnMenuButton", iContent.Load<Model>("Menus\\Return"));
            models.Add("Track1Menu", iContent.Load<Model>("Menus\\Track1Menu"));
            models.Add("Track2Menu", iContent.Load<Model>("Menus\\Track2Menu"));

            AddItem("checkPoint");
            AddItem("box");

            // Load Tracks
            models.Add("Track1", iContent.Load<Model>("track1"));
            models.Add("Track2", iContent.Load<Model>("track2"));

        }
        private static void AddItem(String s)
        {
            models.Add(s, contentManager.Load<Model>(s));
        }

        public static Dictionary<String, Model> Models { get { return models; } }
    }
}