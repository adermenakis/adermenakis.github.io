﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace ZombieGame.Managers
{
    class FontManager
    {
        private static Dictionary<String, SpriteFont> models = new Dictionary<String, SpriteFont>();

        public static void Load(ContentManager iContent)
        {
            models.Add("Font", iContent.Load<SpriteFont>("Font"));
        }

        public static Dictionary<String, SpriteFont> Fonts { get { return models; } }
    }
}
