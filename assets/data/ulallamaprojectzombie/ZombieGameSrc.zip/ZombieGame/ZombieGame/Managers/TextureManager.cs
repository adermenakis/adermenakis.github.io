﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace ZombieGame.Managers
{
    class TextureManager
    {
        private static Dictionary<String, Texture2D> textures = new Dictionary<String, Texture2D>();

        public static void Load(ContentManager iContent)
        {
            textures.Add("Help", iContent.Load<Texture2D>("Menus/Help"));
            textures.Add("MenuBackGround", iContent.Load<Texture2D>("Menus/Front Page"));
            textures.Add("OKButton", iContent.Load<Texture2D>("Screen/ok"));
            textures.Add("CancelButton", iContent.Load<Texture2D>("Screen/cancel"));
            textures.Add("StartButton", iContent.Load<Texture2D>("Screen/start"));
            textures.Add("PauseButton", iContent.Load<Texture2D>("Screen/pause"));
            textures.Add("Select", iContent.Load<Texture2D>("Screen/select"));
            textures.Add("Title", iContent.Load<Texture2D>("Screen/title"));
            textures.Add("Track1", iContent.Load<Texture2D>("track1Image"));
            textures.Add("Viper", iContent.Load<Texture2D>("viperSelection"));
            textures.Add("Tank", iContent.Load<Texture2D>("tankSelection"));
            textures.Add("Delorian", iContent.Load<Texture2D>("delorianSelection"));
            textures.Add("UpButton", iContent.Load<Texture2D>("up"));
            textures.Add("DownButton", iContent.Load<Texture2D>("down"));
            textures.Add("Nissan", iContent.Load<Texture2D>("nissanSelection"));
            textures.Add("Sky", iContent.Load<Texture2D>("sky"));
            textures.Add("Exit", iContent.Load<Texture2D>("Screen/Exit"));
            textures.Add("Numbers", iContent.Load<Texture2D>("numbers"));
            textures.Add("Gameplay UI", iContent.Load<Texture2D>("UIHUD"));
            textures.Add("Damage Screen", iContent.Load<Texture2D>("damage"));
            textures.Add("Speedometer", iContent.Load<Texture2D>("speedometer"));
            textures.Add("Speedometer Arrow", iContent.Load<Texture2D>("speedarrow"));
            textures.Add("Green Health", iContent.Load<Texture2D>("health"));
            textures.Add("SelectTrack", iContent.Load<Texture2D>("Menus\\Select Track"));
            textures.Add("SelectVehicle", iContent.Load<Texture2D>("Menus\\Select Vehicle"));
            textures.Add("Game Over", iContent.Load<Texture2D>("Menus\\Game Over"));
            
        }

        public static Dictionary<String, Texture2D> Textures { get { return textures; } }
    }
}
