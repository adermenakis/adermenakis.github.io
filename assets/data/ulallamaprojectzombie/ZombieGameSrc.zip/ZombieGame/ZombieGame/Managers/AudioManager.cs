using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;

namespace ZombieGame.Managers
{
    class AudioManager
    {
        private static Dictionary<String, SoundEffect> sounds = new Dictionary<String, SoundEffect>();

        public static void Load(ContentManager iContent)
        {
            sounds.Add("Engine1", iContent.Load<SoundEffect>("Sounds\\Engine1"));
            sounds.Add("Engine2", iContent.Load<SoundEffect>("Sounds\\Engine2"));
            sounds.Add("Engine3", iContent.Load<SoundEffect>("Sounds\\Engine3"));
            sounds.Add("Engine4", iContent.Load<SoundEffect>("Sounds\\Engine4"));
            sounds.Add("Engine5", iContent.Load<SoundEffect>("Sounds\\Engine5"));
            sounds.Add("Engine6", iContent.Load<SoundEffect>("Sounds\\Engine6"));
            sounds.Add("Target", iContent.Load<SoundEffect>("Sounds\\Target"));
            sounds.Add("Checkpoint", iContent.Load<SoundEffect>("Sounds\\Checkpoint"));
            sounds.Add("Brake", iContent.Load<SoundEffect>("Sounds\\Brake"));
            sounds.Add("Splat", iContent.Load<SoundEffect>("Sounds\\Splat"));
            sounds.Add("CarDamage", iContent.Load<SoundEffect>("Sounds\\CarDamage"));
            sounds.Add("ClickMenu", iContent.Load<SoundEffect>("Sounds\\ClickMenu"));
            sounds.Add("MenuMove", iContent.Load<SoundEffect>("Sounds\\MoveMenu"));
        }

        public static Dictionary<String, SoundEffect> Sounds { get { return sounds; } }
    }
}