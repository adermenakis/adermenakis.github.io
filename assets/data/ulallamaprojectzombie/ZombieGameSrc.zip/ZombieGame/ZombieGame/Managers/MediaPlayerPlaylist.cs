﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace ZombieGame.Managers
{
    class MediaPlayerPlaylist
    {
        private static MediaPlayerPlaylist instance = new MediaPlayerPlaylist();

        public static MediaPlayerPlaylist Instance { get { return instance; } }

        private Dictionary<String,Song> songs = new Dictionary<String,Song>();
        private int songPlayingID = 0;
        private MediaPlayerPlaylist() { }
        private Boolean isPlaying = true;

        public void Play()
        {
            //MediaPlayer.Play(songs.ElementAt(songPlayingID).Value);
            //isPlaying = true;
        }

        public Boolean IsPlaying { get { return isPlaying; } }

        public void Stop()
        {
            //isPlaying = false;
            //MediaPlayer.Stop();
        }

        public void Next()
        {
            //songPlayingID++;

            //if (songPlayingID >= songs.Count)
            //    songPlayingID = 0;
            
            //Play();
        }

        public void Load(ContentManager iContent)
        {
            //songs.Add("Menu1", iContent.Load<Song>("Songs\\Menu1"));
            //songs.Add("Menu2", iContent.Load<Song>("Songs\\Menu2"));

            //songs.Add("Swallow and Sleep", iContent.Load<Song>("Songs\\02 Swallow and Sleep"));
            //songs.Add("Zombie Inc.", iContent.Load<Song>("Songs\\05 Zombie Inc."));
            //songs.Add("Vengeance", iContent.Load<Song>("Songs\\07 Vengeance"));
            //songs.Add("Never Die", iContent.Load<Song>("Songs\\05 Never Die"));
            //songs.Add("Like You Better Dead", iContent.Load<Song>("Songs\\05 Like You Better Dead"));
            //songs.Add("We Will Rise", iContent.Load<Song>("Songs\\We Will Rise"));

            //Random rnd = new Random();
            //songPlayingID = rnd.Next(songs.Count - 2) + 2;
        }

        public void Update()
        {
            //if (MediaPlayer.State == MediaState.Stopped &&
                //isPlaying)
                //Next();
        }

        public void Play(String iName)
        {
            //MediaPlayer.Play(songs[iName]);
        }
    }
}
