﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using ZombieGame.PhysicObjects;
using JigLibX.Physics;
using ZombieGame.Screens;

namespace ZombieGame.Controllers
{
    class ZombieController : Controller
{
    List<ZombieObject> zombies;
    float WANDERING_RADIUS = 50.0f;
    float CLOSE_DISTANCEX = 70;
    float CLOSE_DISTANCEZ = 50;
    //Stack<Screen> screenStack;
    ZombieGame zombieGame;

    public ZombieController()
    {
        zombies = new List<ZombieObject>();
    }

    public ZombieController(ZombieGame zGame)
        : this()
    {
        zombieGame = zGame;
    }

    public void addZombie( ZombieObject z)
    {
        zombies.Add(z);
    }

    public void ClearAll()
    {
        zombies.ForEach(z =>
        {
            z.PhysicsBody.DisableBody();
            PhysicsSystem.CurrentPhysicsSystem.RemoveBody(z.PhysicsBody);
            PhysicsSystem.CurrentPhysicsSystem.CollisionSystem.RemoveCollisionSkin(z.PhysicsSkin);
            z.Dispose();
        });
        zombies.Clear();
    }

    public override void UpdateController(float dt)
    {
        foreach(ZombieObject zombie in zombies)
        {
            DisableNonLocal(zombie);
                    
            Body body = zombie.PhysicsBody;

            if(body == null)
                return;
            //if (screenStack == )
            //{
            //var a = zombieGame.CurrentScreen.GetType();
            if (zombie.Dying)
            {
                if (zombie.PhysicsBody.IsActive)
                {
                    zombie.PhysicsBody.ApplyWorldImpulseAux(new Vector3(-5, 10, 0));
                    zombie.PhysicsBody.SetOrientation(Matrix.CreateRotationZ(MathHelper.PiOver2));
                    zombie.PhysicsBody.SetDeactivationTime(5);
                }
                else
                {
                    zombie.Dead = true;
                    zombie.Dying = false;
                }
            }
            else
            {
                var distanceWithCar = CheckCarApproach(zombie);
                var x = Math.Abs(distanceWithCar.X);
                var z = Math.Abs(distanceWithCar.Z);
                if (zombie.action == ZombieObject.Action.Wandering)
                {
                    if (x < CLOSE_DISTANCEX && z < CLOSE_DISTANCEZ)
                    {
                        zombie.action = ZombieObject.Action.Chasing;
                    }
                    else
                    {
                        zombie.WanderingAngle++;
                        var angleRad = MathHelper.ToRadians(zombie.WanderingAngle);
                        float x1 = (float)Math.Sin(angleRad) * WANDERING_RADIUS;
                        float z1 = (float)Math.Cos(angleRad) * WANDERING_RADIUS;
                        zombie.PhysicsBody.AddBodyForce(new Vector3(x1, 0, z1));
                        zombie.PhysicsBody.SetDeactivationTime(10000);
                    }
                }
                else if (zombie.action == ZombieObject.Action.Chasing)
                {
                    if (!(x < CLOSE_DISTANCEX && z < CLOSE_DISTANCEZ))
                    {
                        zombie.action = ZombieObject.Action.Wandering;
                    }
                    else
                    {
                        var angle = Math.Atan(distanceWithCar.X / distanceWithCar.Z) -
                        Math.Atan(zombie.PhysicsBody.Orientation.Forward.X / zombie.PhysicsBody.Orientation.Forward.Z);
                        zombie.PhysicsBody.SetOrientation(Matrix.CreateRotationY((float)angle));
                        zombie.PhysicsBody.AddWorldForce(distanceWithCar * 0.9f);
                        zombie.PhysicsBody.SetDeactivationTime(10000);
                    }
                }
            }
        //}
        }
    }

    private void DisableNonLocal(ZombieObject zombie)
    {
        ZombieGame game = ZombieGame.Instance;
        Vector3 carPos = game.CarPosition;

        Vector3 zombiePos = zombie.PhysicsBody.Position;
        if ((Math.Abs(zombiePos.X - carPos.X) > 150) ||
            (Math.Abs(zombiePos.Y - carPos.Y) > 500) ||
            (Math.Abs(zombiePos.Z - carPos.Z) > 150))
        {
            zombie.Visible = false;
            zombie.Enabled = false;
            zombie.PhysicsBody.DisableBody();
        }
        else
        {
            zombie.PhysicsBody.EnableBody();
            zombie.Visible = true;
            zombie.Enabled = true;
        }
            
    }

    private Vector3 CheckCarApproach(ZombieObject zombie)
    {
        Vector3 distance = new Vector3();
        var carPos = zombieGame.CarPosition;
        var zombiePos = zombie.PhysicsBody.Position;
        distance = carPos - zombiePos;
        return distance;
    }
}

}
