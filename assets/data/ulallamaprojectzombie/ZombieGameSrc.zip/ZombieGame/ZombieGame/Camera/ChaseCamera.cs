﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;


namespace ZombieGame.Cameras
{
    class GameCamera : Camera
    {
        CanBeFollowed objectToFollow;
        float distanceFromObject = 10;

        public GameCamera(Game game)
            : base(game)
        {
        }
        public void setObjectToFollow(CanBeFollowed objToFollow)
        {
            objectToFollow = objToFollow;
            previousPosition = objToFollow.getPosition();
        }

       
        protected override void onProcessInput(float amountOfMovement)
        {
            Vector3 moveVector = new Vector3();

            KeyboardState keys = Keyboard.GetState();
            if (keys.IsKeyDown(Keys.D))
                moveVector.X += amountOfMovement;
            if (keys.IsKeyDown(Keys.A))
                moveVector.X -= amountOfMovement;
            if (keys.IsKeyDown(Keys.S))
                moveVector.Z += amountOfMovement;
            if (keys.IsKeyDown(Keys.W))
                moveVector.Z -= amountOfMovement;
            if (keys.IsKeyDown(Keys.Z))
                moveVector.Y += amountOfMovement;
            if (keys.IsKeyDown(Keys.X) && position.Y > 1.0f)
                moveVector.Y -= amountOfMovement;
            if (keys.IsKeyDown(Keys.PageDown))
                distanceFromObject += amountOfMovement;
            

        }

        private Vector3 previousPosition;
        protected override void onUpdate(GameTime gameTime)
        {
            

            if (objectToFollow != null)
            {
                Vector3 deltaPosition = new Vector3();
                Vector3 distanceFromObj = new Vector3();

                Matrix cameraRotation = Matrix.CreateRotationX(angles.X) * Matrix.CreateRotationY(angles.Y);

                deltaPosition = objectToFollow.getPosition() - previousPosition;
                distanceFromObj = position - objectToFollow.getPosition();
                /*
                float directionAngle = -(float)Math.Atan(deltaPosition.Z / deltaPosition.X);

                distanceFromObj.X = (float)Math.Cos((double)directionAngle) * distanceFromObject;
                distanceFromObj.Y = distanceFromObject / 2;
                distanceFromObj.Z = (float)Math.Sin((double)directionAngle) * distanceFromObject;
                 */
                
                position += Vector3.Transform(deltaPosition, cameraRotation);
                previousPosition = objectToFollow.getPosition();
            }

            FocalPoint = objectToFollow.getPosition();
            
        }
    }
}
