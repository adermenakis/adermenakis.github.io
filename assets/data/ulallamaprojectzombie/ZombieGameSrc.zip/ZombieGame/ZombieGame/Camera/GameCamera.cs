﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;


namespace ZombieGame.Cameras
{
    class GameCamera : Camera
    {
        public enum CameraType { CHASE, CIRCLE, FPS, BIRDSEYE };
        CameraType cameraMode = CameraType.CHASE;
        float circleModeAngle = 0;
        float camDistance = 20;
        float height = 0;
        bool rearView = false;

        CanBeFollowed objectToFollow;

        public GameCamera(Game game) : base(game)
        {
        }
        public void setObjectToFollow(CanBeFollowed objToFollow)
        {
            objectToFollow = objToFollow;
        }


        protected override void onProcessInput(float amountOfMovement)
        {
            switch (cameraMode)
            {
                case CameraType.CHASE: followControls(); break;
                case CameraType.BIRDSEYE: birdsEyeControls(); break;
                case CameraType.FPS: fpsControls(); break;
                case CameraType.CIRCLE: circleControls(); break;
            }

            //global controls
            if (Input.InputManager.isPressed(Keys.Tab, Buttons.Y))
            {
                toggleCamera();
            }
        }

        private void fpsControls()
        {

        }

        private void followControls()
        {
            if (Input.InputManager.isDown(Keys.S, Buttons.RightThumbstickDown))
            {
                zoomRadious(.125f);
            }
            else if (Input.InputManager.isDown(Keys.W, Buttons.RightThumbstickUp))
            {
                zoomRadious(-.125f);
            }
            else if (Input.InputManager.isDown(Keys.E, Buttons.RightShoulder))
            {
                rearView = true;
            }
            else if (Input.InputManager.isUp(Keys.E, Buttons.LeftShoulder))
            {
                rearView = false;
            }
        }
        private void circleControls()
        {

            followControls();

            if (Input.InputManager.isDown(Keys.A, Buttons.RightThumbstickLeft))
            {
                circleAroundObject(.0625f);
            }
            else if (Input.InputManager.isDown(Keys.D, Buttons.RightThumbstickRight))
            {
                circleAroundObject(-.0625f);
            }
            else if (Input.InputManager.isDown(Keys.Q, Buttons.RightStick))
            {
                followMode(); //Set camera behind car
            }
        }
        private void birdsEyeControls()
        {
            if (objectToFollow == null)
                return;

            float amountOfMovement = .5f;
            if (Input.InputManager.isUp(Keys.R, Buttons.RightShoulder))
            {
                FocalPoint = objectToFollow.getPosition();
            }
            if (Input.InputManager.isDown(Keys.Q, Buttons.RightThumbstickLeft))
            {
                incrementHeight(amountOfMovement);
            }
            if (Input.InputManager.isDown(Keys.E, Buttons.RightThumbstickRight))
            {
                incrementHeight(-amountOfMovement);
            }
            if (Input.InputManager.isDown(Keys.W, Buttons.RightThumbstickUp))
            {
                moveFocalPoint(new Vector3(0, 0, amountOfMovement));
            }
            if (Input.InputManager.isDown(Keys.S, Buttons.RightThumbstickDown))
            {
                moveFocalPoint(new Vector3(0, 0, -amountOfMovement));
            }
            if (Input.InputManager.isDown(Keys.A, Buttons.RightThumbstickLeft))
            {
                moveFocalPoint(new Vector3(amountOfMovement, 0, 0));
            }
            if (Input.InputManager.isDown(Keys.D, Buttons.RightThumbstickRight))
            {
                moveFocalPoint(new Vector3(-amountOfMovement, 0, 0));
            }
            position = FocalPoint + (Vector3.Up * height*10) +(Vector3.Forward);
        }

        private void moveFocalPoint(Vector3 amount)
        {
            FocalPoint += amount;
        }

        private void incrementHeight(float amount)
        {
            height += amount;
        }

        private void circleAroundObject(float amount)
        {
            circleModeAngle += amount;
        }

        private void zoomRadious(float amount)
        {
            if ((camDistance + amount < 500) && (camDistance + amount >= 5))
            {
                camDistance += amount;
            }
        }

        private void toggleCamera()
        {
            switch (cameraMode)
            {
                case CameraType.CHASE: setCameraMode(CameraType.CIRCLE); break;
                case CameraType.BIRDSEYE: setCameraMode(CameraType.FPS); break;
                case CameraType.FPS: setCameraMode(CameraType.CHASE); break;
                case CameraType.CIRCLE: setCameraMode(CameraType.BIRDSEYE); break;
                default: setCameraMode(CameraType.CHASE); break;
            }
        }

        public void setCameraMode(CameraType cameraType)
        {
            cameraMode = cameraType;
        }

        protected override void onUpdate(GameTime gameTime)
        {
            switch (cameraMode)
            {
                case CameraType.CHASE: followMode(); break;
                case CameraType.BIRDSEYE: birdsEyeMode(); break;
                case CameraType.FPS: fpsMode(); break;
                case CameraType.CIRCLE: circleMode(); break;
                default: followMode(); break;
            }

          //  this.onProcessInput(0);

        }

        private void birdsEyeMode()
        {
        }
        private void circleMode()
        {
            if (objectToFollow == null)
                return;

            upVector = Vector3.Up;
            height = camDistance / 4;//;200
            FocalPoint = objectToFollow.getPosition();
            float angle = circleModeAngle;

            if (rearView)
            {
                angle += MathHelper.Pi;
            }
            position.Z = FocalPoint.Z + (camDistance * (float)Math.Sin(angle));
            position.X = FocalPoint.X + (camDistance * (float)Math.Cos(angle));
            position.Y = FocalPoint.Y + height;
            #region notes
            /*
           * http://gpwiki.org/forums/viewtopic.php?t=4213
x, y is the origin. 
x', y' is the point you want to march about, initially the starting point. 

r = sqrt( (x' - x)² + (y' - y)² ) 

That's your radius. 

θ = arctan( (y' - y)÷(x' - x) ) 

That's your current angle. 

y' = y + r sin θ 
x' = x + r cos θ 

That's your location to be at for any other angle along the circle. 
           */
            #endregion
        }

        private void followMode()
        {
            if (objectToFollow == null)
                return;
            upVector = Vector3.Up;
            float height = camDistance / 4;
            FocalPoint = objectToFollow.getPosition();

            if (rearView)
            {
                position = FocalPoint - (objectToFollow.getForward() * new Vector3(-1, 0, -1) * camDistance) + (Vector3.Up * height);
            }
            else
            {
                position = FocalPoint - (objectToFollow.getForward() * camDistance) + (Vector3.Up * height);
            }
            position.Y = FocalPoint.Y + height;

            circleModeAngle = (float)Math.Atan((FocalPoint.Z - position.Z) / (FocalPoint.X - position.X));

            #region notes
            /*
           * http://gpwiki.org/forums/viewtopic.php?t=4213
x, y is the origin. 
x', y' is the point you want to march about, initially the starting point. 

r = sqrt( (x' - x)² + (y' - y)² ) 

That's your radius. 

θ = arctan( (y' - y)÷(x' - x) ) 

That's your current angle. 

y' = y + r sin θ 
x' = x + r cos θ 

That's your location to be at for any other angle along the circle. 
           */
            #endregion

        }
        private void fpsMode()//FPS
        {
            upVector = objectToFollow.getUp();
            Vector3 forward = objectToFollow.getForward();
            position = objectToFollow.getPosition() + (Vector3.Up * 2) + (forward * 3);
            if (rearView)
            {
                FocalPoint = position + (forward * -100);
            }
            else
            {
                FocalPoint = position + (forward * 100);
            }

        }
    }
}
