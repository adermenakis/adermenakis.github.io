using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace ZombieGame.Cameras
{
    public class Camera : DrawableGameComponent
    {
        static protected Matrix view;
        static protected Matrix projection;
        static protected Vector3 upVector = Vector3.Up;

        protected Vector3 position = new Vector3(0, 10, 60);

        protected float fieldOfView = Microsoft.Xna.Framework.MathHelper.PiOver4;
        protected float aspectRatio;
        protected float nearPlaneDistance = 0.1f;
        protected float farPlaneDistance = 500.0f;

        protected Vector3 focalPoint = Vector3.One;
        
        public Camera(Game game): base(game)
        {
            aspectRatio = (float)game.Window.ClientBounds.Width / (float)game.Window.ClientBounds.Height;
            UpdateProjection();
        }

    #region Getters and setters


        public Vector3 FocalPoint { get { return focalPoint; } set { focalPoint = value; } }
        static public Matrix View { get { return view; } }
        static public Matrix Projection { get { return projection; } set { projection = value; } }
        static public Matrix ViewProjection { get { return view * projection; } }
        public Vector3 Position { get { return position; } set { position = value; } }
        public float FieldOfView { get { return fieldOfView; } set { fieldOfView = value; UpdateProjection(); } }
        public float AspectRatio { get { return aspectRatio; } set { aspectRatio = value; UpdateProjection(); } }
        public float NearPlaneDistance { get { return nearPlaneDistance; } set { nearPlaneDistance = value; UpdateProjection(); } }
        public float FarPlaneDistance { get { return farPlaneDistance; } set { farPlaneDistance = value; UpdateProjection(); } }
    #endregion

        public override void Update(GameTime gameTime)
        {
            double elapsedTime = (double)gameTime.ElapsedGameTime.Ticks / (double)TimeSpan.TicksPerSecond;
            ProcessInput((float)elapsedTime * 50.0f);
            UpdateView();
            base.Update(gameTime);

            onUpdate(gameTime);
        }
        /// <summary>
        /// Hook added by chris to avoid touching the Update function. //to be overwritten
        /// </summary>
        virtual protected void onUpdate(GameTime gameTime)
        {
            //to be overwritten
        }
        /// <summary>
        /// Hook added by chris to avoid touching the ProcessInput function. //to be overwritten
        /// </summary>
        /// <param name="gameTime"></param>
        virtual protected void onProcessInput(float amountOfMovement)
        {
            //to be overwritten
        }

        private void ProcessInput(float amountOfMovement)
        {
            onProcessInput(amountOfMovement);
        }

        private void UpdateProjection()
        {
            projection = Matrix.CreatePerspectiveFieldOfView(fieldOfView, aspectRatio, nearPlaneDistance, farPlaneDistance);
        }

        private void UpdateView()
        {
            view = Matrix.CreateLookAt(position, focalPoint, upVector);
        }
    }
}
