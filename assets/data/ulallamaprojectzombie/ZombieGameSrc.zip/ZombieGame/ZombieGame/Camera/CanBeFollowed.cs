﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ZombieGame.Cameras
{
    interface CanBeFollowed
    {
        Vector3 getPosition();
        Vector3 getUp();

        Vector3 getForward();
    }
}
