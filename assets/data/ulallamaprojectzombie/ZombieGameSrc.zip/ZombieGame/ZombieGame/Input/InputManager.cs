﻿#region Using Statements
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
#endregion

namespace ZombieGame.Input
{
    class InputManager
    {
#if XBOX360
        static private GamePadState currentGamePadState;
        static private GamePadState lastGamePadState;

#else
        static private KeyboardState currentKeyboardState;
        static private KeyboardState lastKeyboardState;
#endif

        static public void handleInput()
        {
#if XBOX360
            lastGamePadState = currentGamePadState;
           currentGamePadState = GamePad.GetState(PlayerIndex.One);
#else
            lastKeyboardState = currentKeyboardState;
            currentKeyboardState = Keyboard.GetState();
#endif
        }


        /// <summary>
        /// Checks whether the specified key or button has been pressed.
        /// </summary>
        static public bool isPressed(Keys key, Buttons button)
        {
#if XBOX360
            return (currentGamePadState.IsButtonDown(button) && lastGamePadState.IsButtonUp(button));
#else
            return (currentKeyboardState.IsKeyDown(key) && lastKeyboardState.IsKeyUp(key));
#endif

        }

        internal static bool isDown(Keys key, Buttons button)
        {
#if XBOX360
            return currentGamePadState.IsButtonDown(button);
#else
            return currentKeyboardState.IsKeyDown(key);
#endif
        }

        internal static bool isUp(Keys key, Buttons button)
        {
#if XBOX360
            return currentGamePadState.IsButtonUp(button);
#else
            return currentKeyboardState.IsKeyUp(key);
#endif        
        }
    }
}
