﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

using ZombieGame.Managers;
using ZombieGame.GameLogic;
using ZombieGame.Factories;

using Microsoft.Xna.Framework.Input;

namespace ZombieGame.Screens
{
    class GameOverScreen : Screen
    {
        private RotatingMenuObject car = null;
        private RotatingMenuObject track = null;
        private MenuObject btnContinue = new MenuButton(ModelManager.Models["ContinueButton"],
                                                            new Vector3(60.0f, -200.0f, 0.0f), 1.0f);

        private String carTitle, trackTitle, message;

        public GameOverScreen(GraphicsDeviceManager iGraphics, Stack<Screen> stack, Game game)
            : base(iGraphics, stack)
        {
            background = new Sprite(TextureManager.Textures["Game Over"],
               new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height));

            btnContinue.IsSelected = true;

            switch (Player.Instance.Car)
            {
                case CarType.EDelorian:
                    car = new RotatingMenuObject(ModelManager.Models["Delorian"],
                                                    new Vector3(200.0f, 130.0f, 0.0f),
                                                    50.0f);
                    carTitle = "Delorian";
                    break;
                case CarType.EDogdeViper:
                    car = new RotatingMenuObject(ModelManager.Models["Viper"],
                                                    new Vector3(200.0f, 130.0f, 0.0f),
                                                    50.0f);
                    carTitle = "Viper";
                    break;
                case CarType.ENissanPickup:
                    car = new RotatingMenuObject(ModelManager.Models["Nissan"],
                                                    new Vector3(200.0f, 130.0f, 0.0f),
                                                    50.0f);
                    carTitle = "Pickup";
                    break;
            }

            switch (Player.Instance.Track)
            {
                case 1:
                    track = new RotatingMenuObject(ModelManager.Models["Track1Menu"],
                                                    new Vector3(-200.0f, 130.0f, 0.0f),
                                                    0.75f);
                    trackTitle = "Track 1";
                    break;
                case 2:
                    track = new RotatingMenuObject(ModelManager.Models["Track2Menu"],
                                                    new Vector3(-200.0f, 130.0f, 0.0f),
                                                    0.75f);
                    trackTitle = "Track 2";
                    break;
            }

            if (((ZombieGame)game).IsGameWon)
                message = "Congratulations!! You have won the game";
            else
                message = "Sorry, you lose... Try Again";

            Vector3 lRotations = car.Rotation;
            lRotations.X = -10.0f;
            lRotations.Z = 10.0f;

            car.Rotation = lRotations;
            car.RotationStep = 0.05f;

        }

        public override void Update()
        {
            track.Update();
            car.Update();

            if (Input.InputManager.isPressed(Keys.Enter, Buttons.A) && btnContinue.IsSelected)
            {
                Player.Instance.ResetScores();

                screenStack.Pop();
                screenStack.Push(new CarScreen(graphics, screenStack));
                screenStack.Push(new TrackScreen(graphics, screenStack));
                screenStack.Push(new MainScreen(graphics, screenStack));
            }
        }

        public override void Draw(SpriteBatch iSpriteBatch)
        {
             iSpriteBatch.Begin();

            background.Draw(iSpriteBatch);

            iSpriteBatch.DrawString(FontManager.Fonts["Font"], carTitle,
                                    new Vector2(150.0f, 320.0f), Color.Red);
            iSpriteBatch.DrawString(FontManager.Fonts["Font"], trackTitle,
                                    new Vector2(500.0f, 320.0f), Color.Red);

            iSpriteBatch.DrawString(FontManager.Fonts["Font"], message,
                                    new Vector2(150.0f, 400.0f), Color.Yellow);

            iSpriteBatch.DrawString(FontManager.Fonts["Font"], String.Format("Score : {0}", Player.Instance.Score),
                                                                new Vector2(150.0f, 450.0f), Color.YellowGreen);

            iSpriteBatch.End();

            RestoreRenderState();

            Draw(car, false);
            Draw(track, false);
            Draw(btnContinue, true);
        }
}
}
