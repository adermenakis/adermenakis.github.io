using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace ZombieGame.Screens
{
    abstract class Screen
    {

        protected Sprite background = null;
        protected GraphicsDeviceManager graphics = null;
        protected Stack<Screen> screenStack = null;

        protected Matrix Projection { get; private set; }
        protected Matrix View { get; private set; }

        private float selectedScale = 1.0f;
        private float coef = 1.0f;

        public Screen(GraphicsDeviceManager iGraphics, Stack<Screen> stack)
        {
            graphics = iGraphics;
            screenStack = stack;

            View = Matrix.CreateLookAt(new Vector3(0.0f, 0.0f, -10.0f),
                                        Vector3.Zero,
                                        Vector3.Up);
            Projection = Matrix.CreateOrthographic(iGraphics.GraphicsDevice.Viewport.Width,
                                                  iGraphics.GraphicsDevice.Viewport.Height,
                                                  -1000.0f,
                                                  1000.0f);
        }

        public virtual void Update()
        {
            if (selectedScale < 1.0f)
            {
                selectedScale = 1.0f;
                coef *= -1.0f;
            }
            else if (selectedScale > 1.1f)
            {
                selectedScale = 1.1f;
                coef *= -1.0f;
            }
                selectedScale += coef * 0.005f;
        }

        public abstract void Draw(SpriteBatch iSpriteBatch);

        protected void RestoreRenderState()
        {
            this.graphics.GraphicsDevice.RenderState.DepthBufferEnable = true;
            this.graphics.GraphicsDevice.RenderState.AlphaTestEnable = true;
            this.graphics.GraphicsDevice.SamplerStates[0].AddressU = TextureAddressMode.Wrap;
            this.graphics.GraphicsDevice.SamplerStates[0].AddressV = TextureAddressMode.Wrap;
            this.graphics.GraphicsDevice.RenderState.AlphaBlendEnable = true;
        }

        public void Draw(MenuObject iModel, bool iDrawHighlight)
        {
            RestoreRenderState();

            Matrix[] transforms = new Matrix[iModel.Model.Bones.Count];
            iModel.Model.CopyAbsoluteBoneTransformsTo(transforms);

            // Draw the model. A model can have multiple meshes, so loop.
            foreach (ModelMesh mesh in iModel.Model.Meshes)
            {
                // This is where the mesh orientation is set, as well as our camera and projection.
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();

                    if (iModel.IsSelected)
                    {
                        if(iDrawHighlight)
                            effect.DiffuseColor = Color.Yellow.ToVector3();

                        effect.World = Matrix.CreateScale(selectedScale) *
                                        transforms[mesh.ParentBone.Index] *
                                        iModel.Transformation;
                    }
                    else
                    {
                        effect.DiffuseColor = iModel.OriginalColor;
                        effect.World = transforms[mesh.ParentBone.Index] * iModel.Transformation;
                    }

                    effect.View = View;
                    effect.Projection = Projection;
                }
                // Draw the mesh, using the effects set above.
                mesh.Draw();
            }
        }
    }
}