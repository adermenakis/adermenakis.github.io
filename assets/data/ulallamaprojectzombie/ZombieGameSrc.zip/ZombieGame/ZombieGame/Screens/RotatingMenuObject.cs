﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

using ZombieGame.Managers;

namespace ZombieGame.Screens
{
    class RotatingMenuObject : MenuObject
    {
        private float yRotation = 0.0f;
        public float RotationStep { get; set; }
        public static Vector3 LeftMost = new Vector3(600.0f, -100.0f, 0.0f);
        public static Vector3 RightMost = new Vector3(-600.0f, -100.0f, 0.0f);
        public static Vector3 Center = new Vector3(-150.0f, -100.0f, 0.0f);
        public bool IsMoving { get; private set; }
        public Vector3 DestinationPosition { get; private set; }
        private float Velocity { get; set; }

        public RotatingMenuObject(Model iModel, Vector3 iPosition, float iScale)
            : base(iModel, iPosition, iScale)
        {
            Rotation = new Vector3(MathHelper.ToRadians(-45.0f), 0.0f, MathHelper.ToRadians(-45.0f));
            IsMoving = false;
            RotationStep = 0.5f;
        }

        public override void Update()
        {
            yRotation += RotationStep;

            if (yRotation >= 360.0f)
                yRotation = 0.0f;

            if (IsMoving)
            {
                Vector3 lNewPosition = Position;
                if (Math.Abs(Position.X - DestinationPosition.X) <= 10.0f)
                    IsMoving = false;

                    lNewPosition.X += Velocity;
                    Position = lNewPosition;
            }
     
            UpdateTransformation();
        }

        public void MoveTo(Vector3 iPosition, float iVelocity)
        {
            IsMoving = true;
            DestinationPosition = iPosition;
            Velocity = iVelocity;

        }

        public override void UpdateTransformation()
        {
            Transformation = Matrix.CreateScale(ScaleFactor) *
                Matrix.CreateRotationY(MathHelper.ToRadians(yRotation)) *
                    Matrix.CreateFromYawPitchRoll(Rotation.Y,
                                                    Rotation.X,
                                                    Rotation.Z) *
                    Matrix.CreateTranslation(Position);
        }
    }
}
