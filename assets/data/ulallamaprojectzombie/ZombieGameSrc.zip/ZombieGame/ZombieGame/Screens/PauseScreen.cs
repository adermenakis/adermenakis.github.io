﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

using ZombieGame.Managers;
using ZombieGame.GameLogic;

using Microsoft.Xna.Framework.Input;


namespace ZombieGame.Screens
{
    class PauseScreen : Screen
    {
        private MenuObject btnContinue = new MenuButton(ModelManager.Models["ContinueButton"],
                                                            new Vector3(50.0f, 0.0f, 0.0f), 1.0f);
        private MenuObject btnReturn = new MenuButton(ModelManager.Models["ReturnMenuButton"],
                                                            new Vector3(50.0f, -80.0f, 0.0f), 1.0f);

        public PauseScreen(GraphicsDeviceManager iGraphics, Stack<Screen> stack)
            : base(iGraphics, stack)
        {
            btnContinue.IsSelected = true;
            background = new Sprite(TextureManager.Textures["MenuBackGround"],
                                    new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width,
                                                    graphics.GraphicsDevice.Viewport.Height));
        }

        public override void Update()
        {
            if (Input.InputManager.isPressed(Keys.Escape, Buttons.Start))
            {
                    AudioManager.Sounds["ClickMenu"].Play();
                    btnContinue.IsSelected = false;
                    btnReturn.IsSelected = false;
                    Draw(btnContinue, false);
                    Draw(btnReturn, false);
                    screenStack.Pop();
            }

            if (btnContinue.IsSelected)
            {
                if (Input.InputManager.isPressed(Keys.Down, Buttons.LeftThumbstickDown))
                {
                    btnContinue.IsSelected = false;
                    btnReturn.IsSelected = true;
                    AudioManager.Sounds["MenuMove"].Play();
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A))
                {
                    AudioManager.Sounds["ClickMenu"].Play();
                    btnContinue.IsSelected = false;
                    btnReturn.IsSelected = false;
                    Draw(btnContinue, false);
                    Draw(btnReturn, false);
                    screenStack.Pop();
                }
            }
            else if (btnReturn.IsSelected)
            {
                if (Input.InputManager.isPressed(Keys.Up, Buttons.LeftThumbstickUp))
                {
                    btnContinue.IsSelected = true;
                    AudioManager.Sounds["MenuMove"].Play();
                    btnReturn.IsSelected = false;
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A))
                {
                    btnContinue.IsSelected = false;
                    btnReturn.IsSelected = false;
                    Draw(btnContinue, false);
                    Draw(btnReturn, false);
                    AudioManager.Sounds["ClickMenu"].Play();

                    screenStack.Pop();
                    screenStack.Push(new CarScreen(graphics, screenStack));
                    screenStack.Push(new TrackScreen(graphics, screenStack));
                    screenStack.Push(new MainScreen(graphics, screenStack));
                }
            }

            base.Update();

            /*
            if (Input.InputManager.isPressed(Keys.Enter, Buttons.Back) && selectedID == 1)
            {
                screenStack.Pop();
            }
            else if (Input.InputManager.isPressed(Keys.Enter, Buttons.Back) && selectedID == 0)
            {
                screenStack.Pop();
                screenStack.Pop();
                screenStack.Push(new CarScreen(graphics, screenStack));
                screenStack.Push(new TrackScreen(graphics, screenStack));
                screenStack.Push(new MainScreen(graphics, screenStack));
            }
            else if (Input.InputManager.isPressed(Keys.Down, Buttons.Back))
                HighLightNext();
            else if (Input.InputManager.isPressed(Keys.Up, Buttons.Back))
                HighLightPrevious();*/
        }

        public override void Draw(SpriteBatch iSpriteBatch)
        {
            iSpriteBatch.Begin();
            background.Draw(iSpriteBatch);


            iSpriteBatch.End();

            RestoreRenderState();

            Draw(btnContinue, true);
            Draw(btnReturn, true);
        }
    }
}
