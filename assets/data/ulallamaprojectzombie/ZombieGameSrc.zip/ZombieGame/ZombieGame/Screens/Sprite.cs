﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace ZombieGame.Screens
{
    class Sprite
    {
        private Texture2D sprite = null;
        public Vector2 Position { get; set; }
        public Rectangle Rectangle { get; set; }
        public Boolean IsDrawWithRect { get; set; }
        public Color Color { get; set; }
        public Boolean HighLight { get; set; }

        public Sprite(Texture2D iSprite, Vector2 iPosition, Color iColor)
        {
            sprite = iSprite;
            Color = iColor;
            Position = iPosition;
            IsDrawWithRect = false;
        }

        public Sprite(Texture2D iSprite, Vector2 iPosition)
        {
            sprite = iSprite;
            Color = Color.White;
            Position = iPosition;
            IsDrawWithRect = false;
        }

        public Sprite(Texture2D iSprite, Rectangle iRectangle, Color iColor)
        {
            sprite = iSprite;
            Color = iColor;
            Rectangle = iRectangle;
            IsDrawWithRect = true;
        }

        public Sprite(Texture2D iSprite, Rectangle iRectangle)
        {
            sprite = iSprite;
            Color = Color.White;
            Rectangle = iRectangle;
            IsDrawWithRect = true;
        }

        public Sprite(Texture2D iSprite)
        {
            sprite = iSprite;
            Color = Color.White;
            Position = Vector2.Zero;
            IsDrawWithRect = false;
        }

        public void Draw(SpriteBatch iSpriteBatch)
        {
            Color temp = Color;

            if(HighLight)
                temp = Color.Yellow;
            if(IsDrawWithRect)
                iSpriteBatch.Draw(sprite, Rectangle, temp);
            else
                iSpriteBatch.Draw(sprite, Position, temp);
        }
    }
}
