﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

using ZombieGame.Managers;

namespace ZombieGame.Screens
{
    class MainScreen : Screen
    {
        private MenuObject btnNewGame = new MenuButton(ModelManager.Models["NewGameButton"],
                                                new Vector3(60.0f, -20.0f, 0.0f),
                                                1.0f);
        private MenuObject btnOptions = new MenuButton(ModelManager.Models["OptionsButton"],
                                                new Vector3(60.0f, -100.0f, 0.0f),
                                                1.0f);


        public MainScreen(GraphicsDeviceManager iGraphics, Stack<Screen> stack)
            : base(iGraphics, stack)
        {
            background = new Sprite(TextureManager.Textures["MenuBackGround"], new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height));
            btnNewGame.IsSelected = true;
        }

        public override void Update()
        {
            if (btnNewGame.IsSelected)
            {
                if (Input.InputManager.isPressed(Keys.Down, Buttons.LeftThumbstickDown))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    btnNewGame.IsSelected = false;
                    btnOptions.IsSelected = true;
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A))
                {
                    AudioManager.Sounds["ClickMenu"].Play();
                    btnNewGame.IsSelected = false;
                    btnOptions.IsSelected = false;
                    Draw(btnNewGame, false);
                    Draw(btnOptions, false);
                    screenStack.Pop();
                }
            }
            else if (btnOptions.IsSelected)
            {
                if (Input.InputManager.isPressed(Keys.Up, Buttons.LeftThumbstickUp))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    btnNewGame.IsSelected = true;
                    btnOptions.IsSelected = false;
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A))
                {
                    AudioManager.Sounds["ClickMenu"].Play();
                    screenStack.Push(new HelpScreen(graphics, screenStack));
                }
            }

            base.Update();
        }

        public override void Draw(SpriteBatch iSpriteBatch)
        {
              iSpriteBatch.Begin();
              background.Draw(iSpriteBatch);

            iSpriteBatch.End();
            
            Draw(btnNewGame, true);
            Draw(btnOptions, true);
        }
    }
}
