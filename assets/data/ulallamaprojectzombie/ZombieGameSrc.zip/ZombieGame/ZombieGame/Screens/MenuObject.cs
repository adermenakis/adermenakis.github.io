﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using ZombieGame.Managers;

namespace ZombieGame.Screens
{
    abstract class MenuObject
    {
        public Model Model { get; private set; }
        public Matrix Transformation { get; protected set; }
        public Vector3 Position { get; set; }
        public Vector3 Rotation { get; set; }
        public float ScaleFactor { get; set; }
        public Boolean IsSelected { get; set; }
        public Vector3 OriginalColor { get; private set; }

        public MenuObject(Model iModel, Vector3 iPosition, float iScale)
        {
            Model = iModel;
            OriginalColor = ((BasicEffect)iModel.Meshes[0].Effects[0]).DiffuseColor;

            Position = iPosition;
            ScaleFactor = iScale;
            IsSelected = false;

            UpdateTransformation();
        }

        public virtual void UpdateTransformation()
        {
            Transformation = Matrix.CreateScale(ScaleFactor) *
                                Matrix.CreateFromYawPitchRoll(Rotation.Y,
                                                                Rotation.X,
                                                                Rotation.Z) *
                                Matrix.CreateTranslation(Position);
        }

        public abstract void Update();
    }
}
