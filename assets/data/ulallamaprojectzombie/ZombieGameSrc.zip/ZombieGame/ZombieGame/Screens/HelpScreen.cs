﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

using ZombieGame.Managers;
using ZombieGame.GameLogic;

using Microsoft.Xna.Framework.Input;


namespace ZombieGame.Screens
{
    class HelpScreen : Screen
    {
        private MenuObject btnReturn = new MenuButton(ModelManager.Models["ReturnMenuButton"], new Vector3(380.0f, -250.0f, 0.0f), 1.0f);

        private String contolsString = "Car Controls\n" +
                                        "Acceleration/Decelleration : Up/Down\n" +
                                        "Hand Brake : Space\n" +
                                        "Steering : Left/Right\n" +
                                        "Reset : R" +
                                        "\n\nCamera\n" +
                                        "Toggle : Tab\n" +
                                        "Move/Zoom/Rotate : W/S/A/D\n" +
                                        "Pause : Escape";

        private String objectivesString = "Game Objective\n" +
                                            "The objective of the game is to reach the last checkpoint\n" +
                                            " and complete the game with a high score. Throughout the game\n" +
                                            "there are checkpoints and objectives; objectives are destroying  piles\n" +
                                            "of boxes which sometimes are hidded. Eveytime a checkpoint is reached,\n" +
                                            "the countdown timer is updated. When objectives are completed and\n" +
                                            "checkpoints are reached, points are accumulated. Additionally, points\n" +
                                            "can be gathered by killing zombies. Zombies have to be hit\n" +
                                            "with the front side of the car, otherwise they will damage it.";

        private String currentMessage = null;

        public HelpScreen(GraphicsDeviceManager iGraphics, Stack<Screen> stack)
            : base(iGraphics, stack)
        {
            btnReturn.IsSelected = true;
            background = new Sprite(TextureManager.Textures["Help"],
                                    new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width,
                                                    graphics.GraphicsDevice.Viewport.Height));

            currentMessage = contolsString;
        }

        public override void Update()
        {
                    if (Input.InputManager.isPressed(Keys.Left, Buttons.LeftThumbstickLeft))
                    {
                        currentMessage = contolsString;
                    AudioManager.Sounds["MenuMove"].Play();
                    }
                else if (Input.InputManager.isPressed(Keys.Right, Buttons.LeftThumbstickRight))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    currentMessage = objectivesString;
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A) ||
                            Input.InputManager.isPressed(Keys.Escape, Buttons.Start))
                {
                    btnReturn.IsSelected = false;
                    Draw(btnReturn, false);
                    AudioManager.Sounds["ClickMenu"].Play();
                    screenStack.Pop();
                }

            base.Update();
        }

        public override void Draw(SpriteBatch iSpriteBatch)
        {
            iSpriteBatch.Begin();
            background.Draw(iSpriteBatch);

            
            iSpriteBatch.DrawString(FontManager.Fonts["Font"],
                        currentMessage, new Vector2(20.0f, 100.0f),
                        Color.DarkGray);

            iSpriteBatch.DrawString(FontManager.Fonts["Font"],
            "Press Left/Right to navigate the help screen", new Vector2(20.0f, 500.0f),
            Color.DarkGray);


            iSpriteBatch.End();

            RestoreRenderState();

            Draw(btnReturn, true);
        }
    }
}
