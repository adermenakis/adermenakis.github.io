﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

using ZombieGame.GameLogic;
using ZombieGame.Managers;

namespace ZombieGame.Screens
{
    class TrackScreen : Screen
    {
        private RotatingMenuObject track1 = new RotatingMenuObject(ModelManager.Models["Track1Menu"], RotatingMenuObject.Center, 1.0f);
        private RotatingMenuObject track2 = new RotatingMenuObject(ModelManager.Models["Track2Menu"], RotatingMenuObject.RightMost, 1.0f);

        private MenuObject btnContinue = new MenuButton(ModelManager.Models["ContinueButton"], new Vector3(-250.0f, -250.0f, 0.0f), 1.0f);
        private MenuObject btnReturn = new MenuButton(ModelManager.Models["ReturnMenuButton"], new Vector3(380.0f, -250.0f, 0.0f), 1.0f);

        private bool isConfirm = false;

        public TrackScreen(GraphicsDeviceManager iGraphics, Stack<Screen> stack)
            : base(iGraphics, stack)
        {
            background = new Sprite(TextureManager.Textures["SelectTrack"],
                new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height));

            btnContinue.IsSelected = true;
            Player.Instance.Track = 1;
        }

        public override void Update()
        {
            track1.Update();
            track2.Update();

            if (!isConfirm)
            {
                if (Input.InputManager.isPressed(Keys.Right, Buttons.LeftThumbstickRight))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    track1.MoveTo(RotatingMenuObject.LeftMost, 9.0f);
                    track2.MoveTo(RotatingMenuObject.Center, 9.0f);
                    Player.Instance.Track = 2;
                }
                else if (Input.InputManager.isPressed(Keys.Left, Buttons.LeftThumbstickLeft))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    track1.MoveTo(RotatingMenuObject.Center, -9.0f);
                    track2.MoveTo(RotatingMenuObject.RightMost, -9.0f);
                    Player.Instance.Track = 1;
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A))
                {
                    AudioManager.Sounds["ClickMenu"].Play();
                    isConfirm = true;
                }
                else if (Input.InputManager.isPressed(Keys.Escape, Buttons.B))
                {
                    Draw(btnContinue, false);
                    Draw(btnReturn, false);
                    screenStack.Push(new MainScreen(graphics, screenStack));
                    AudioManager.Sounds["ClickMenu"].Play();
                }
            }
            else
            {
                if (Input.InputManager.isPressed(Keys.Left, Buttons.LeftThumbstickLeft))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    btnReturn.IsSelected = true;
                    btnContinue.IsSelected = false;
                }
                else if (Input.InputManager.isPressed(Keys.Right, Buttons.LeftThumbstickRight))
                {
                    AudioManager.Sounds["MenuMove"].Play();
                    btnReturn.IsSelected = false;
                    btnContinue.IsSelected = true;                    
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A) && btnContinue.IsSelected)
                {
                    AudioManager.Sounds["ClickMenu"].Play();
                    btnContinue.IsSelected = false;
                    Draw(btnReturn, false);
                    Draw(btnContinue, false);
                    screenStack.Pop();
                }
                else if (Input.InputManager.isPressed(Keys.Escape, Buttons.B) ||
                            (Input.InputManager.isPressed(Keys.Enter, Buttons.A)
                                                            && btnReturn.IsSelected))
                {
                    isConfirm = false;
                    Draw(btnReturn, false);
                    Draw(btnContinue, false);
                    AudioManager.Sounds["ClickMenu"].Play();
                }
            }


            base.Update();
        }

        public override void Draw(SpriteBatch iSpriteBatch)
        {
            
            iSpriteBatch.Begin();

            background.Draw(iSpriteBatch);

            iSpriteBatch.End();
            
            Draw(track1, false);
            Draw(track2, false);

            if (isConfirm)
            {
                Draw(btnReturn, true);
                Draw(btnContinue, true);
            }
        }
    }
}
