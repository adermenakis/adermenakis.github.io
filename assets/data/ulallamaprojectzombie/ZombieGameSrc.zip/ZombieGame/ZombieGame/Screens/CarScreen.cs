﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

using ZombieGame.Factories;
using ZombieGame.GameLogic;
using ZombieGame.Managers;

namespace ZombieGame.Screens
{
    class CarScreen : Screen
    {
        private RotatingMenuObject car1 = new RotatingMenuObject(ModelManager.Models["Viper"], RotatingMenuObject.Center, 50.0f);
        private RotatingMenuObject car2 = new RotatingMenuObject(ModelManager.Models["Delorian"], RotatingMenuObject.RightMost, 50.0f);
        private RotatingMenuObject car3 = new RotatingMenuObject(ModelManager.Models["Nissan"], RotatingMenuObject.RightMost, 50.0f);

        private MenuObject btnContinue = new MenuButton(ModelManager.Models["ContinueButton"], new Vector3(-250.0f, -250.0f, 0.0f), 1.0f);
        private MenuObject btnReturn = new MenuButton(ModelManager.Models["ReturnMenuButton"], new Vector3(380.0f, -250.0f, 0.0f), 1.0f);

        private bool isConfirm = false;

        public CarScreen(GraphicsDeviceManager iGraphics, Stack<Screen> stack)
            : base(iGraphics, stack)
        {
            background = new Sprite(TextureManager.Textures["SelectVehicle"],
                new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height));

            btnContinue.IsSelected = true;
            Vector3 lRotations = car1.Rotation;
            lRotations.X = -10.0f;
            lRotations.Z = 10.0f;

            car1.Rotation = lRotations;
            car2.Rotation = lRotations;
            car3.Rotation = lRotations;
            car1.RotationStep = 0.5f;
            car2.RotationStep = 0.5f;
            car3.RotationStep = 0.5f;

            Player.Instance.Car = CarType.EDogdeViper;

            car1.IsSelected = true;
            Player.Instance.Track = 1;
        }

        public override void Update()
        {
            car1.Update();
            car2.Update();
            car3.Update();

            if (!isConfirm)
            {
                if (Input.InputManager.isPressed(Keys.Right, Buttons.LeftThumbstickRight))
                {
                    if (Math.Abs(car1.Position.X - RotatingMenuObject.Center.X) <= 10.0f)
                    {
                        car1.MoveTo(RotatingMenuObject.LeftMost, 9.0f);
                        car2.MoveTo(RotatingMenuObject.Center, 9.0f);
                        car1.IsSelected = false;
                        car2.IsSelected = true;
                        Player.Instance.Car = CarType.EDelorian;
                        AudioManager.Sounds["MenuMove"].Play();
                    }
                    else if (Math.Abs(car2.Position.X - RotatingMenuObject.Center.X) <= 10.0f)
                    {
                        car2.MoveTo(RotatingMenuObject.LeftMost, 9.0f);
                        car3.MoveTo(RotatingMenuObject.Center, 9.0f);
                        car2.IsSelected = false;
                        car3.IsSelected = true;
                        Player.Instance.Car = CarType.ENissanPickup;
                        AudioManager.Sounds["MenuMove"].Play();
                    }
                }
                else if (Input.InputManager.isPressed(Keys.Left, Buttons.LeftThumbstickLeft))
                {
                    if (Math.Abs(car3.Position.X - RotatingMenuObject.Center.X) <= 10.0f)
                    {
                        car3.MoveTo(RotatingMenuObject.RightMost, -9.0f);
                        car2.MoveTo(RotatingMenuObject.Center, -9.0f);
                        car3.IsSelected = false;
                        car2.IsSelected = true;
                        Player.Instance.Car = CarType.EDelorian;
                        AudioManager.Sounds["MenuMove"].Play();
                    }
                    else if (Math.Abs(car2.Position.X - RotatingMenuObject.Center.X) <= 10.0f)
                    {
                        car2.MoveTo(RotatingMenuObject.RightMost, -9.0f);
                        car1.MoveTo(RotatingMenuObject.Center, -9.0f);
                        car2.IsSelected = false;
                        car1.IsSelected = true;
                        Player.Instance.Car = CarType.EDogdeViper;
                        AudioManager.Sounds["MenuMove"].Play();
                    }
                }
                else if (Input.InputManager.isPressed(Keys.Escape, Buttons.B))
                {
                    Draw(btnContinue, false);
                    Draw(btnReturn, false );
                    screenStack.Push(new TrackScreen(graphics, screenStack));
                    AudioManager.Sounds["ClickMenu"].Play();
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A))
                {
                    isConfirm = true;
                    AudioManager.Sounds["ClickMenu"].Play();
                }
            }
            else
            {
                if (Input.InputManager.isPressed(Keys.Left, Buttons.LeftThumbstickLeft))
                {
                    btnReturn.IsSelected = true;
                    btnContinue.IsSelected = false;
                    AudioManager.Sounds["MenuMove"].Play();
                }
                else if (Input.InputManager.isPressed(Keys.Right, Buttons.LeftThumbstickRight))
                {
                    btnReturn.IsSelected = false;
                    btnContinue.IsSelected = true;
                    AudioManager.Sounds["MenuMove"].Play();
                }
                else if (Input.InputManager.isPressed(Keys.Enter, Buttons.A) && btnContinue.IsSelected)
                {
                    MediaPlayerPlaylist.Instance.Next();
                    screenStack.Pop();
                    screenStack.Push(new GameScreen(graphics, screenStack));
                    car1.IsSelected = false;
                    car2.IsSelected = false;
                    car3.IsSelected = false;
                    btnContinue.IsSelected = false;
                    btnReturn.IsSelected = false;
                    Draw(btnContinue, false);
                    Draw(btnReturn, false );
                    Draw(car1, false);
                    Draw(car2, false);
                    Draw(car3, false);
                    AudioManager.Sounds["ClickMenu"].Play();
                    ZombieGame.Instance.ResetGame();
                }
                else if (Input.InputManager.isPressed(Keys.Escape, Buttons.B) ||
                            (Input.InputManager.isPressed(Keys.Enter, Buttons.A)
                                                            && btnReturn.IsSelected))
                {
                    isConfirm = false;
                    Draw(btnReturn, false);
                    Draw(btnContinue, false);
                    AudioManager.Sounds["ClickMenu"].Play();
                }
            }


            base.Update();
        }

        public override void Draw(SpriteBatch iSpriteBatch)
        {
            
            iSpriteBatch.Begin();

            background.Draw(iSpriteBatch);

            iSpriteBatch.End();

            Draw(car1, false);
            Draw(car2, false);
            Draw(car3, false);

            if (isConfirm)
            {
                Draw(btnReturn, true);
                Draw(btnContinue, true);
            }
        }
    }
}