﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using JigLibX.Physics;

using ZombieGame.PhysicObjects;

namespace ZombieGame.Factories
{
    /// <summary>
    /// Used to choose the power up type
    /// </summary>
    enum PowerupType
    {
    }

    public class PowerupFactory : AbstractFactory
    {
        static PowerupFactory instance;

        private Dictionary<PowerupType, Model> carModelList = new Dictionary<PowerupType, Model>();

        /// <summary>
        /// Private constructor to restring to singleton
        /// </summary>
        private PowerupFactory() { }

        /// <summary>
        /// Creates a new instance of CarObject which is related to the appropriate
        /// model and contains predifined physic components such as acceleration and steering
        /// </summary>
        /// <param name="iCarType">the type of car we wish to create</param>
        /// <returns>a new CarObject instance</returns>
        CarObject createCar(PowerupType iPowerupType)
        {
            /*switch (iPowerupType)
            {
            }*/

            return null;
        }

        /// <summary>
        /// Returns the singleton instance
        /// </summary>
        /// <returns>CarFactory instance</returns>
        public static PowerupFactory getInstance()
        {
            if (instance == null)
                instance = new PowerupFactory();

            return instance;
        }
    }
}
