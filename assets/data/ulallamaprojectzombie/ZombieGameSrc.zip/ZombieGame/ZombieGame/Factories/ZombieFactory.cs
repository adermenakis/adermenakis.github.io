﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using JigLibX.Physics;

using ZombieGame.PhysicObjects;

namespace ZombieGame.Factories
{
    /// <summary>
    /// Used to choose the zombie type
    /// </summary>
    enum ZombieType
    {
        EZard,
        EHuman,
        EWolfMan,
        ESlug
    }

    public class ZombieFactory : AbstractFactory
    {
        static ZombieFactory instance;

        private Dictionary<ZombieType, Model> zombieModelList = new Dictionary<ZombieType, Model>();

        /// <summary>
        /// Private constructor to restring to singleton
        /// </summary>
        private ZombieFactory() { }

        /// <summary>
        /// Creates a new instance of CarObject which is related to the appropriate
        /// model and contains predifined physic components such as acceleration and steering
        /// </summary>
        /// <param name="iCarType">the type of car we wish to create</param>
        /// <returns>a new CarObject instance</returns>
        CarObject createCar(ZombieType iZombieType)
        {
            /*switch (iZombieType)
            {

            }*/

            return null;
        }

        /// <summary>
        /// Returns the singleton instance
        /// </summary>
        /// <returns>CarFactory instance</returns>
        public static ZombieFactory getInstance()
        {
            if (instance == null)
                instance = new ZombieFactory();

            return instance;
        }
    }
}
