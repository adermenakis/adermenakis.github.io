﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using JigLibX.Physics;

using ZombieGame.PhysicObjects;
using ZombieGame.Managers;
using ZombieGame;

namespace ZombieGame.Factories
{
    /// <summary>
    /// Used to choose the car type
    /// </summary>
    enum CarType
    {
        EDelorian,
        ETank,
        ENissanPickup,
        EDogdeViper
    }

    /// <summary>
    /// A factory class that is used to create instances of all the objects
    /// that appear in the game (Cars, zombies, tracks etc.)
    /// </summary>
    class CarFactory
    {

        /// <summary>
        /// Creates a new instance of CarObject which is related to the appropriate
        /// model and contains predifined physic components such as acceleration and steering
        /// </summary>
        /// <param name="iCarType">the type of car we wish to create</param>
        /// <returns>a new CarObject instance</returns>
        public static CarObject createCar(CarType iCarType, ZombieGame game, PhysicsSystem physicSystem)
        {
            switch (iCarType)
            {
                case CarType.EDogdeViper:
                    return new CarObject(game, ModelManager.Models["Viper"], ModelManager.Models["Wheel"], true, true, 30.0f,
                                         5.0f, 4.7f, 5.0f, 0.20f, 0.4f, 0.05f, 0.45f, 0.3f,
                                         1, 820.0f, physicSystem.Gravity.Length(), 100.0f, AudioManager.Sounds["Engine2"], 500);
                case CarType.ETank:
                    return new CarObject(game, ModelManager.Models["Tank"], ModelManager.Models["Wheel"], true, true, 30.0f,
                                         5.0f, 4.7f, 5.0f, 0.20f, 0.4f, 0.05f, 1.0f, 0.9f,
                                         1, 1000.0f, physicSystem.Gravity.Length(), 300.0f, AudioManager.Sounds["Engine3"], 1000);
                case CarType.ENissanPickup:
                    return new CarObject(game, ModelManager.Models["Nissan"], ModelManager.Models["Wheel"], true, true, 30.0f,
                                         5.0f, 4.7f, 5.0f, 0.20f, 0.4f, 0.05f, 0.70f, 0.1f,
                                         1, 500.0f, physicSystem.Gravity.Length(), 200.0f, AudioManager.Sounds["Engine4"], 800);
                case CarType.EDelorian:
                    return new CarObject(game, ModelManager.Models["Delorian"], ModelManager.Models["Wheel"], true, true, 30.0f,
                                         5.0f, 4.7f, 5.0f, 0.20f, 0.4f, 0.05f, 0.7f, 0.8f,
                                         1, 700.0f, physicSystem.Gravity.Length(), 50.0f, AudioManager.Sounds["Engine5"], 400);
            }

            return null;
        }
    }
}
