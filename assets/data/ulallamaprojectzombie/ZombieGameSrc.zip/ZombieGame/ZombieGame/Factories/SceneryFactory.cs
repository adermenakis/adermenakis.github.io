﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using JigLibX.Physics;
using JigLibX.Geometry;

using ZombieGame.PhysicObjects.Obstacles;
using ZombieGame.PhysicObjects;
using ZombieGame.Managers;

namespace ZombieGame.Factories
{
    /// <summary>
    /// Used to choose the zombie type
    /// </summary>
    enum ObstacleType
    {
        ECactus2,
        ECactus3,
        ECactus4,
        ECrate,
        EHouse1,
        ERoadBlock,
        ECactus1,
        EBear,
    }

    class SceneryFactory
    {
        private static Game game;

        public static void Load(Game iGame)
        {
            game = iGame;
        }

        public static Obstacle CreateObstacle(ObstacleType iType, Vector3 iPosition, Matrix iOrientation)
        {
            switch (iType)
            {
                case ObstacleType.ECactus1:
                    return new BigCactus(game, iOrientation, iPosition);
                case ObstacleType.ECactus2:
                    return new SmallCactus(game, iOrientation, iPosition, ModelManager.Models["Cactus2"]);
                case ObstacleType.ECactus3:
                    return new SmallCactus(game, iOrientation, iPosition, ModelManager.Models["Cactus3"]);
                case ObstacleType.ECactus4:
                    return new SmallCactus(game, iOrientation, iPosition, ModelManager.Models["Cactus4"]);
                case ObstacleType.ECrate:
                    return new Crate(game, iOrientation, iPosition);
                case ObstacleType.EHouse1:
                    return new Generic(game, iOrientation, iPosition, ModelManager.Models["House1"],
                                new Box(new Vector3(-2.5f, 0.0f, -1.5f), Matrix.CreateTranslation(0.0f, 0.0f, 0.0f), new Vector3(5.0f, 2.5f, 3.0f)), 1);
                case ObstacleType.ERoadBlock:
                    return new Generic(game, iOrientation, iPosition, ModelManager.Models["RoadBlock"],
                                new Box(new Vector3(-0.1f, 0.0f, -0.7f), Matrix.CreateTranslation(0.0f, 0.0f, 0.0f), new Vector3(0.5f, 1.2f, 1.5f)), 1);
                case ObstacleType.EBear:
                    return new Generic(game, iOrientation, iPosition, ModelManager.Models["Bear"],
                                new Box(new Vector3(0.1f, 0.0f, -0.7f), Matrix.CreateTranslation(0.0f, 0.0f, 0.0f), new Vector3(0.5f, 1.2f, 1.5f)), 1);
            }

            return null;
        }
    }
}
