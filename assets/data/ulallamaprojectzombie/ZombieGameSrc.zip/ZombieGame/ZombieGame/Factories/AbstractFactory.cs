﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using JigLibX.Physics;

namespace ZombieGame.Factories
{
    public abstract class AbstractFactory
    {
        protected PhysicsSystem physicSystem = null;

        protected ZombieGame game = null;
    }
}
