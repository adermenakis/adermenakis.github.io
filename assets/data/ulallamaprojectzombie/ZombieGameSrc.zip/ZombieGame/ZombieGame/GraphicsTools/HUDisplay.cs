﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using JigLibX.Physics;

using ZombieGame.GameLogic;
using ZombieGame.Managers;
using ZombieGame.Screens;

namespace ZombieGame.GraphicsTools
{
    class HUDisplay : DrawableGameComponent
    {
        #region Attributes
        ContentManager content;

        SpriteBatch spriteBatch;
        SpriteFont spriteFont, spriteFont2;
        ZombieGame _game;

        int lifesize;
        Color lifecolor;
        int frameRate = 0;
        int frameCounter = 0;
        TimeSpan elapsedTime = TimeSpan.Zero;

        Vector3 changeInPosition, thisFramePosition, lastFramePosition;
        float unitsPerFrame;
        float unitsPerSecond;
        float kmPerHour;
        int carHealth;

        #endregion

        public HUDisplay(Game game)
            :base(game)
        {
            content = new ContentManager(game.Services);
            _game = (ZombieGame)game;
            lifesize = 183;
            lifecolor = Color.Green;
            carHealth = -1;
            //thisFramePosition = _game.CarPosition;
        }
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = content.Load<SpriteFont>("Content/HUDFont");
            spriteFont2 = content.Load<SpriteFont>("Content/HUDTimerFont");

        }

        protected override void UnloadContent()
        {
            content.Unload();
        }

        public override void Update(GameTime gameTime)
        {
            elapsedTime += gameTime.ElapsedGameTime;

            if (elapsedTime > TimeSpan.FromSeconds(1))
            {
                elapsedTime -= TimeSpan.FromSeconds(1);
                frameRate = frameCounter;
                frameCounter = 0;
            }

            
            
/*
            lastFramePosition = thisFramePosition;
            thisFramePosition = _game.CarPosition;
            changeInPosition = thisFramePosition - lastFramePosition;

            unitsPerFrame = changeInPosition.Length();
            unitsPerSecond = unitsPerFrame / (float)gameTime.ElapsedGameTime.TotalSeconds;
            kmPerHour = unitsPerSecond / 1000f * 60f * 60f;*/
        }

        public override void Draw(GameTime gametime)
        {
            frameCounter++;
            string time = ((ZombieGame)this.Game).gameTimer.RemainingTime + "";
            string fps = "FPS : " + frameRate.ToString();
            lifesize = (int)(((float)_game.CarHealth / carHealth) * 183.0f);

            if (((float)_game.CarHealth / carHealth) <= 0.30f)
                lifecolor = Color.Red;
            else
                lifecolor = Color.Green;

            if (carHealth == -1)
                carHealth = _game.CarHealth;

            spriteBatch.Begin();

            //HUD background display
            spriteBatch.Draw(TextureManager.Textures["Gameplay UI"], new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.White);
            
            
           
            
            //Speed o meter with arrow
            //spriteBatch.Draw(TextureManager.Textures["Speedometer"], new Vector2(GraphicsDevice.Viewport.Width - 200, GraphicsDevice.Viewport.Height - 200), Color.White);
            //spriteBatch.Draw(TextureManager.Textures["Speedometer Arrow"], new Vector2(), Color.White);

            //Drawing Score
            spriteBatch.DrawString(spriteFont, String.Format("{0}", Player.Instance.Score), new Vector2(706, 46), Color.Black);
            spriteBatch.DrawString(spriteFont, String.Format("{0}", Player.Instance.Score), new Vector2(707, 47), Color.DarkGray);
            
            //Drawing Laps
            //spriteBatch.DrawString(spriteFont, String.Format("Laps : {0}/{1}", _game.ElapsedLaps, Player.Instance.Laps), new Vector2(50, 45), Color.Black);
            //spriteBatch.DrawString(spriteFont, String.Format("Laps : {0}/{1}", _game.ElapsedLaps, Player.Instance.Laps), new Vector2(51, 46), Color.DarkGray);

            //Drawing Health
            spriteBatch.DrawString(spriteFont, String.Format("Health : {0}", _game.CarHealth), new Vector2(308, 500), lifecolor);
            spriteBatch.Draw(TextureManager.Textures["Green Health"], new Rectangle(309, 563, lifesize, 25), Color.White);
            
            //Drawing Time
            spriteBatch.DrawString(spriteFont2, time.Substring(0,5), new Vector2(330, 46), Color.Black);
            spriteBatch.DrawString(spriteFont2,  time.Substring(0,5), new Vector2(331, 47), Color.DarkGray);

            //Drawing FPS
            spriteBatch.DrawString(spriteFont, fps, new Vector2(80, 6), Color.Black);
            spriteBatch.DrawString(spriteFont, fps, new Vector2(81, 7), Color.DarkGray);

            //Drawing Damage Screen
            if (_game.isDamaged)
            {
                spriteBatch.Draw(TextureManager.Textures["Damage Screen"], new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.White);
            }

            spriteBatch.End();

            ((ZombieGame)this.Game).RestoreRenderState();
        }
    }
}
