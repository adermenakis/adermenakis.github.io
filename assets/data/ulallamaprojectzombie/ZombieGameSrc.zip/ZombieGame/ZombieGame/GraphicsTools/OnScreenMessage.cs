﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using JigLibX.Physics;

using ZombieGame.GameLogic;
using ZombieGame.Managers;
using ZombieGame.Screens;

namespace ZombieGame.GraphicsTools
{
    class OnScreenMessage : DrawableGameComponent
    {
        ContentManager content;

        SpriteBatch spriteBatch;
        SpriteFont spriteFont;
        GraphicsDeviceManager _Graphics;
        static float duration = 0;
        static String message = "", lastMessage = "";

        public OnScreenMessage(GraphicsDeviceManager iGraphics)
            : base(ZombieGame.Instance)
        {
            content = new ContentManager(ZombieGame.Instance.Services);
            _Graphics = iGraphics;
        }
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = content.Load<SpriteFont>("Content/Font2");
        }

        protected override void UnloadContent()
        {
            content.Unload();
        }
        static public void PostMessage(String messageText, float messageDuration)
        {
            if (messageText != lastMessage)
            {
                if (duration > 0)
                {
                    message += "\n\r" + messageText;
                }
                else
                {
                    message = messageText;
                }
                duration = messageDuration;
                lastMessage = messageText;
            }

        }

        public static void ClearMessage() { message = ""; }

        public override void Update(GameTime gameTime)
        {

        }
        public override void Draw(GameTime gametime)
        {
            if (duration > 0)
            {
                spriteBatch.Begin();

                //Drawing FPS
                spriteBatch.DrawString(spriteFont, message, new Vector2(100, 106), Color.Yellow);
                spriteBatch.DrawString(spriteFont, message, new Vector2(101, 107), Color.Black);

                spriteBatch.End();
                duration -= gametime.ElapsedGameTime.Milliseconds*.002f;
            }


            ((ZombieGame)this.Game).RestoreRenderState();
        }
    }
}
