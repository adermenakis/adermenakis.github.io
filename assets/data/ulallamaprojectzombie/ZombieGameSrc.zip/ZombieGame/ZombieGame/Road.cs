using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;
using ZombieGame.PhysicObjects;

namespace ZombieGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Road : PhysicObject
    {
        #region Attributes
        ZombieGame _game;
        GraphicsDevice device;
        BasicEffect roadEffect;
        Texture2D road;
        VertexPositionNormalTexture[] trackVertices;
        VertexDeclaration myVertexDeclaration;
        #endregion

        #region Properties
        public List<Vector3> MainRoadPoints { get; private set; } 
        #endregion

        public Road(Game game)
            : base(game)
        {
            _game = (ZombieGame)game;

            CreateMainRoadPoints();

            List<Vector3> extendedTrackPoints = GenerateTrackPoints(MainRoadPoints);
            trackVertices = GenerateTrackVertices(extendedTrackPoints);

            body = new Body();
            collision = new CollisionSkin(null);

            var roadInfo = new TriangleMesh();
            var triangleVI = new List<TriangleVertexIndices>();

            roadInfo.CreateMesh(extendedTrackPoints, triangleVI, 1, 1.0f);
            collision.AddPrimitive(roadInfo, new MaterialProperties(0.7f, 0.7f, 0.6f));

            PhysicsSystem.CurrentPhysicsSystem.CollisionSystem.AddCollisionSkin(collision);

        }

        private void CreateMainRoadPoints()
        {
            MainRoadPoints = new List<Vector3>();
            MainRoadPoints.Add(new Vector3(195, -14.6f, 10));//0
            MainRoadPoints.Add(new Vector3(180, -14.6f, -170));//1
            MainRoadPoints.Add(new Vector3(75, -14.6f, -195));//2
            MainRoadPoints.Add(new Vector3(0, -14.6f, -195));//3
            MainRoadPoints.Add(new Vector3(-75, -14.6f, -195));//4
            MainRoadPoints.Add(new Vector3(-170, -14.6f, -165));//5
            MainRoadPoints.Add(new Vector3(-200, -14.6f, -50));//6
            MainRoadPoints.Add(new Vector3(-190, -14.6f, 70));//7
            MainRoadPoints.Add(new Vector3(-170, -14.6f, 155));//8
            MainRoadPoints.Add(new Vector3(0, -14.6f, 170));//9
            MainRoadPoints.Add(new Vector3(170, -14.6f, 170));//10
        }

        Vector3 CR3D(Vector3 v1, Vector3 v2, Vector3 v3, Vector3 v4, float amount)
        {
            Vector3 result = new Vector3();

            result.X = MathHelper.CatmullRom(v1.X, v2.X, v3.X, v4.X, amount);
            result.Y = MathHelper.CatmullRom(v1.Y, v2.Y, v3.Y, v4.Y, amount);
            result.Z = MathHelper.CatmullRom(v1.Z, v2.Z, v3.Z, v4.Z, amount);

            return result;
        }
        List<Vector3> InterpolateCR(Vector3 v1, Vector3 v2, Vector3 v3, Vector3 v4)
        {
            List<Vector3> list = new List<Vector3>();
            int detail = 10;
            for (int i = 0; i < detail; i++)
            {
                Vector3 newPoint = CR3D(v1, v2, v3, v4, (float)i / (float)detail);
                list.Add(newPoint);
            }
            return list;
        }
        List<Vector3> GenerateTrackPoints(List<Vector3> basePoints)
        {
            basePoints.Add(basePoints[0]);
            basePoints.Add(basePoints[1]);
            basePoints.Add(basePoints[2]);

            List<Vector3> allPoints = new List<Vector3>();

            for (int i = 1; i < basePoints.Count - 2; i++)
            {
                List<Vector3> part = InterpolateCR(basePoints[i - 1], basePoints[i], basePoints[i + 1], basePoints[i + 2]);
                allPoints.AddRange(part);
            }

            return allPoints;
        }
        VertexPositionNormalTexture[] GenerateTrackVertices(List<Vector3> basePoints)
        {
            float halfTrackWidth = 5.0f;
            float textureLenght = 3.5f;

            float distance = 0;
            List<VertexPositionNormalTexture> verticesList = new List<VertexPositionNormalTexture>();

            for (int i = 1; i < basePoints.Count - 1; i++)
            {
                Vector3 carDir = basePoints[i + 1] - basePoints[i];
                Vector3 sideDir = Vector3.Cross(new Vector3(0, 1, 0), carDir);
                sideDir.Normalize();

                Vector3 outerPoint = basePoints[i] + sideDir * halfTrackWidth;
                Vector3 innerPoint = basePoints[i] - sideDir * halfTrackWidth;

                VertexPositionNormalTexture vertex;
                vertex = new VertexPositionNormalTexture(innerPoint, new Vector3(0, 1, 0), new Vector2(0, distance / textureLenght));
                verticesList.Add(vertex);
                vertex = new VertexPositionNormalTexture(outerPoint, new Vector3(0, 1, 0), new Vector2(1, distance / textureLenght));
                verticesList.Add(vertex);
                distance += carDir.Length();
            }

            VertexPositionNormalTexture extraVert = verticesList[0];
            extraVert.TextureCoordinate.Y = distance / textureLenght;
            verticesList.Add(extraVert);

            extraVert = verticesList[1];
            extraVert.TextureCoordinate.Y = distance / textureLenght;
            verticesList.Add(extraVert);

            return verticesList.ToArray();
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            device = _game.GraphicsDevice;
            roadEffect = new BasicEffect(device, null);
            road = _game.Content.Load<Texture2D>("roadWhite");
            myVertexDeclaration = new VertexDeclaration(device, VertexPositionNormalTexture.VertexElements);

            base.Initialize();
        }

        public override void ApplyEffects(BasicEffect effect)
        {
            effect.PreferPerPixelLighting = true;
        }

        public override void Draw(GameTime gameTime)
        {
            //*********render road*****************
            roadEffect.World = Matrix.Identity;
            roadEffect.View = Cameras.Camera.View;
            roadEffect.Projection = Cameras.Camera.Projection;

            roadEffect.Texture = road;
            roadEffect.TextureEnabled = true;
            roadEffect.VertexColorEnabled = false;

            roadEffect.Begin();
            foreach (EffectPass pass in roadEffect.CurrentTechnique.Passes)
            {
                pass.Begin();
                device.VertexDeclaration = myVertexDeclaration;
                device.DrawUserPrimitives<VertexPositionNormalTexture>(Microsoft.Xna.Framework.Graphics.PrimitiveType.TriangleStrip, trackVertices, 0, trackVertices.Length - 2);
                pass.End();
            }
            roadEffect.End();
            //***************************************
            base.Draw(gameTime);
        }
    }
}