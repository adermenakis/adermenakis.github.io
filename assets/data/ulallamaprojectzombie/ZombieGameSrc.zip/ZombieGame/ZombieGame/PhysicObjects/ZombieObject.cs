#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using JigLibX.Collision;
using JigLibX.Physics;
using JigLibX.Geometry;
using JigLibX.Math;
using Microsoft.Xna.Framework.Graphics;

#endregion

namespace ZombieGame.PhysicObjects
{

    public class ZombieObject : PhysicObject
    {
        #region Attributes
        public enum Action
        {
            Wandering,
            Chasing,
            Attacking
        }
        #endregion

        #region Properties
        public int zombieNumber { get; set; }
        public int Points { get; protected set; }
        public bool Dead { get; set; }
        public bool Dying { get; set; }
        public Vector3 NativePosition { get; set; }
        public Action action { get; set; }
        public int WanderingAngle { get; set; }
        #endregion


        public ZombieObject(Game game, Model model, float scale,
                            Matrix orientation, Vector3 position)
            : base(game, model)
        {
            this.position = position;
            this.orientation = orientation;
            body = new Body();
            collision = new CollisionSkin(body);
            body.CollisionSkin = collision;
            //collision.callbackFn += new CollisionCallbackFn(CollisionEventHandler.Instance.handleCollisionDetection);
            this.scale = Vector3.One * scale;
            Points = 0;
            Dead = false;
            Dying = false;
            action = Action.Wandering;
            WanderingAngle = 0;
        }

        public override void ApplyEffects(BasicEffect effect)
        {
            effect.DiffuseColor = new Vector3(1.0f, 1.0f, 1.0f);
        }
    }
}
