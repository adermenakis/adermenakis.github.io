﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Obstacles;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.PhysicObjects.Objectives
{
    class ObjectiveObj : GameObj
    {
        public ObjectiveObj(Model m, Texture2D t)
            : base(m,t)
        {
            
        }
        int direction = 1;
        public override void Update(GameTime gameTime)
        {
            angle.X = MathHelper.PiOver2;
            angle.Y += ((float)gameTime.ElapsedGameTime.Milliseconds) / 600;
            offset.Y += direction * ((float)gameTime.ElapsedGameTime.Milliseconds) / 300;
            if (offset.Y > 5)
            {
                direction = -1;                
            }
            else if(offset.Y<2)
            {
                direction = 1;
            }
        }
 
    }
}
