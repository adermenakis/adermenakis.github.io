﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion

namespace ZombieGame.GameLogic.Objectives
{
    class SceneLoader
    {
        static List<PhysicObject> objects = new List<PhysicObject>();

        public static void BuildBoxTower(Vector3 position)
        {
            Model boxModel = ModelManager.Models["box"];
            ZombieGame game = ZombieGame.Instance;

            PhysicObject physicObj;

            for (int i = 0; i < 5; i++)
            {
                Vector3 pos = new Vector3(position.X, position.Y + (i * 3f), position.Z);

                physicObj = new BoxObject(ZombieGame.Instance, boxModel, new Vector3(2, 1, 2), Matrix.Identity, pos);
                objects.Add(physicObj);
                game.Components.Add(physicObj);
            }
        }

        public static void UnloadScene()
        {
            foreach (PhysicObject p in objects)
            {
                p.PhysicsBody.DisableBody();
                PhysicsSystem.CurrentPhysicsSystem.RemoveBody(p.PhysicsBody);
                PhysicsSystem.CurrentPhysicsSystem.CollisionSystem.RemoveCollisionSkin(p.PhysicsSkin);
                ZombieGame.Instance.Components.Remove(p);
                p.Dispose();
            }
            objects = new List<PhysicObject>() ;
        }
    }
}
