﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Obstacles;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.PhysicObjects.Objectives
{
    abstract class GameObj
    {//
        protected Model model;
        protected Texture2D texture;
        protected Vector3 angle = Vector3.Zero;
        protected Vector3 offset = Vector3.Zero;
        bool isHidden = false;

        float highlightTimeLeft = 0;

        public GameObj(Model m, Texture2D t)
        {
            model = m;
            texture = t;
        }
        public abstract void Update(GameTime g);
        public void Draw(GameTime gameTime, Vector3 position)
        {
            if (isHidden)
            {
                return;
            }
            Matrix[] meshWorlds = new Matrix[3];
            meshWorlds[0] = Matrix.CreateTranslation(new Vector3(0, 0, 0));

            Matrix world =
                Matrix.CreateRotationX(angle.X) *
                Matrix.CreateRotationY(angle.Y) *
                Matrix.CreateRotationZ(angle.Z) *
                Matrix.CreateTranslation(position + offset);

            for (int index = 0; index < model.Meshes.Count; index++)
            {
                ModelMesh mesh = model.Meshes[index];
                foreach (BasicEffect effect in mesh.Effects)
                {
                    

                    effect.PreferPerPixelLighting = true;
                    effect.EnableDefaultLighting();
                    effect.World = mesh.ParentBone.Transform * meshWorlds[index] * world;
                    effect.View = Camera.View;
                    effect.Projection = Camera.Projection;
                }

                mesh.Draw();
            }
        }
        internal void highlight(float time)
        {
            highlightTimeLeft = time;
        }
        internal void Show()
        {
            isHidden = false;
        }

        internal void Hide()
        {
            isHidden = true;
        }
    }
}
