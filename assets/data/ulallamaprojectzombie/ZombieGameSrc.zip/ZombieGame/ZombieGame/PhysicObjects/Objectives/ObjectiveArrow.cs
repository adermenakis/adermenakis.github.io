﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic.Objectives;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Obstacles;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.PhysicObjects.Objectives
{
    class ObjectiveArrow : GameObj
    {
        Vector3 pointingAt = Vector3.Zero;


        public ObjectiveArrow(Model m, Texture2D t)
            : base(m,t)
        {
        }
        public void PointTo(Objective checkPoint)
        {
            pointingAt = checkPoint.Position;
        }
        public override void Update(GameTime gameTime)
        {
            Vector3 delta = pointingAt - Position;

            angle.Y = -(float)Math.Atan(delta.Z / delta.X);
            if (isPositive(delta.X))
            {
                angle.Y += MathHelper.Pi;
            }
            angle.X = -(float)Math.Atan(delta.Z / delta.Y);
            if (isPositive(delta.Y))
            {
                angle.X += MathHelper.Pi;
            }
            
       
        }
        private bool isPositive(float f)
        {
            if (f >= 0)
            {
                return true;
            }
            return false;
        }
        public Vector3 Position 
        { 
            get 
            { 
                Vector3 myPosition = ZombieGame.Instance.CarPosition; 
                myPosition.Y+=4.5f;
                 
                return myPosition;
            } 
        }


        internal void PointTo(Vector3 vector3)
        {
            pointingAt = vector3;
        }


    }
}
