﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna;
using Microsoft.Xna.Framework;

using ZombieGame.Managers;
using ZombieGame;

using JigLibX.Geometry;
using JigLibX.Collision;

namespace ZombieGame.PhysicObjects.Zombies
{
    class SlugZombie : ZombieObject
    {
        public SlugZombie(Game game)
            : base(game, ModelManager.Models["Slug"], 0.5f, Matrix.Identity, Vector3.Zero)
        {
            collision.AddPrimitive(new Box(Vector3.Zero, Matrix.CreateTranslation(2.0f, 0.0f, 3), new Vector3(5, 4.0f, 5.0f)),
                                                            new MaterialProperties(0.5f, 0.7f, 0.6f));
            //orientation = Matrix.CreateTranslation(100, 10, 10);
            Vector3 com = SetMass(100.0f);
            body.MoveTo(position + com, orientation);
            body.Mass = 1.0f;
            
            body.EnableBody();
            Points = 1000;
        }
    }
}
