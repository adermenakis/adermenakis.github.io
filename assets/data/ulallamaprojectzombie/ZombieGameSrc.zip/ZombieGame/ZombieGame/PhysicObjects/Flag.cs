﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using JigLibX.Collision;
using JigLibX.Physics;
using JigLibX.Geometry;
using JigLibX.Math;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

using ZombieGame.Managers;

namespace ZombieGame.PhysicObjects
{
    class Flag : PhysicObject
    {

        public Flag(Game game, Matrix orientation, Vector3 position)
            : base(game, ModelManager.Models["Flag"])
        {
            body = new Body();
            collision = new CollisionSkin(body);
            body.Immovable = true;
            body.CollisionSkin = this.collision;

            collision.AddPrimitive(new Box(Vector3.Zero, orientation, new Vector3(1.0f, 1.0f, 1.0f)), new MaterialProperties(0.8f, 0.8f, 0.7f));
           
            body.CollisionSkin = this.collision;
            Vector3 com = SetMass(1.0f);
            body.MoveTo(position, Matrix.Identity);
            body.EnableBody();
        }

        public override void ApplyEffects(BasicEffect effect)
        {
            //effect.DiffuseColor = color;
        }
    }
}
