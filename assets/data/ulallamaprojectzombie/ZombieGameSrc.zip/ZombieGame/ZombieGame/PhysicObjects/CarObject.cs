using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Audio;

using JigLibX.Vehicles;
using JigLibX.Collision;

using ZombieGame.Cameras;

namespace ZombieGame.PhysicObjects
{
    class CarObject : PhysicObject,CanBeFollowed
    {

        private Car car;
        private Model wheel;
        private SoundEffect engineSound;
        public int Health { get; set; }

        public bool IsDestroyed { get { return Health <= 0; } }

        public SoundEffect EngineSound { get { return engineSound; } }

        public CarObject(ZombieGame game, Model model,Model wheels, bool FWDrive,
                       bool RWDrive,
                       float maxSteerAngle,
                       float steerRate,
                       float wheelSideFriction,
                       float wheelFwdFriction,
                       float wheelTravel,
                       float wheelRadius,
                       float wheelZOffset,
                       float wheelRestingFrac,
                       float wheelDampingFrac,
                       int wheelNumRays,
                       float driveTorque,
                       float gravity,
                       float mass,
                       SoundEffect engine,
                       int health
            )
            : base(game, model)
        {
            car = new Car(FWDrive, RWDrive, maxSteerAngle, steerRate,
                wheelSideFriction, wheelFwdFriction, wheelTravel, wheelRadius,
                wheelZOffset, wheelRestingFrac, wheelDampingFrac,
                wheelNumRays, driveTorque, gravity);

            engineSound = engine;
            this.body = car.Chassis.Body;
            this.collision = car.Chassis.Skin;
            collision.callbackFn += game.CollisionFunction;
            this.wheel = wheels;
            body.Orientation = car.Chassis.Body.Orientation * Matrix.CreateRotationY(MathHelper.ToRadians(90.0f));
            Health = health;
            SetCarMass(mass);
        }

        private void DrawWheel(Wheel wh, bool rotated)
        {
            Camera camera = ((ZombieGame)this.Game).Camera;

            foreach (ModelMesh mesh in wheel.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    float steer = wh.SteerAngle;

                    Matrix rot;
                    if (rotated) rot = Matrix.CreateRotationY(MathHelper.ToRadians(180.0f));
                    else rot = Matrix.Identity;

                    effect.World = rot * Matrix.CreateRotationZ(MathHelper.ToRadians(-wh.AxisAngle)) * // rotate the wheels
                        Matrix.CreateRotationY(MathHelper.ToRadians(steer)) *
                        Matrix.CreateTranslation(wh.Pos + wh.Displacement * wh.LocalAxisUp) * car.Chassis.Body.Orientation * // oritentation of wheels
                        Matrix.CreateTranslation(car.Chassis.Body.Position); // translation

                    effect.View = Camera.View;
                    effect.Projection = Camera.Projection;
                    effect.EnableDefaultLighting();
                    effect.PreferPerPixelLighting = true;
                }
                mesh.Draw();
            }
        }


        public override void Draw(GameTime gameTime)
        {
            System.Console.Out.WriteLine(body.Position);
            DrawWheel(car.Wheels[0], true);
            DrawWheel(car.Wheels[1], true);
            DrawWheel(car.Wheels[2], false);
            DrawWheel(car.Wheels[3], false);

            base.Draw(gameTime);
        }

        public Car Car
        {
            get { return this.car; }
        }

        private void SetCarMass(float mass)
        {
            body.Mass = mass;
            Vector3 min, max;
            car.Chassis.GetDims(out min, out max);
            Vector3 sides = max - min;

            float Ixx = (1.0f / 12.0f) * mass * (sides.Y * sides.Y + sides.Z * sides.Z);
            float Iyy = (1.0f / 12.0f) * mass * (sides.X * sides.X + sides.Z * sides.Z);
            float Izz = (1.0f / 12.0f) * mass * (sides.X * sides.X + sides.Y * sides.Y);

            Matrix inertia = Matrix.Identity;
            inertia.M11 = Ixx; inertia.M22 = Iyy; inertia.M33 = Izz;
            car.Chassis.Body.BodyInertia = inertia;
            car.SetupDefaultWheels();
        }

        public override void ApplyEffects(BasicEffect effect)
        {
           
        }
        public Vector3 getPosition()
        {
            return body.Position;
        }
        public Vector3 getUp()
        {
            return body.Orientation.Up;
        }
        public Vector3 getForward()
        {
            return body.Orientation.Right;
        }
    }
}
