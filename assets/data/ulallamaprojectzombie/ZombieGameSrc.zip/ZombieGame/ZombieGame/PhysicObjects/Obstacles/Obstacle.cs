﻿#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using JigLibX.Collision;
using JigLibX.Physics;
using JigLibX.Geometry;
using JigLibX.Math;
using Microsoft.Xna.Framework.Graphics;
using ZombieGame.Managers;

#endregion

namespace ZombieGame.PhysicObjects.Obstacles
{
    class Obstacle : PhysicObject
    {
        protected int damage = 0;

        public int Damage { get { return damage; } }

        protected Obstacle(Game game, Matrix orientation, Vector3 position, Model model)
            : base(game, model)
        {
            body = new Body();
            body.Immovable = true;
            body.Mass = 1000000.0f;
            collision = new CollisionSkin(body);
            body.CollisionSkin = collision;
            this.scale = Vector3.One;
        }

        public override void ApplyEffects(BasicEffect effect)
        {
            //effect.DiffuseColor = color;
        }
    }
}
