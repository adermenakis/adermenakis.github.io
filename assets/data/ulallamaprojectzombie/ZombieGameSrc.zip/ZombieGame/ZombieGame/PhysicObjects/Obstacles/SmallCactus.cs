﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JigLibX.Collision;
using JigLibX.Physics;
using JigLibX.Geometry;
using JigLibX.Math;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace ZombieGame.PhysicObjects.Obstacles
{
    class SmallCactus : Obstacle
    {
        public SmallCactus(Game game, Matrix orientation, Vector3 position, Model model)
            : base(game, orientation, position, model)
        {
            damage = 1;

            collision.AddPrimitive(new Box(new Vector3(0.0f, -0.5f, 0.0f), Matrix.Identity, new Vector3(2.0f, 2.0f, 2.0f))
                                                                                    , new MaterialProperties(0.5f, 0.7f, 0.6f));
            Vector3 com = SetMass(100.0f);
            body.MoveTo(position + com, orientation);
            body.Mass = 1.0f;

            body.EnableBody();
        }
    }
}
