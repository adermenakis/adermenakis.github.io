﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using ZombieGame.Managers;
using ZombieGame;

using JigLibX.Geometry;
using JigLibX.Collision;

namespace ZombieGame.PhysicObjects.Obstacles
{
    class Generic : Obstacle
    {
        public Generic(Game game, Matrix orientation, Vector3 position, Model model, Box box, int damage)
            : base(game, orientation, position, model)
        {
            this.damage = damage;

            collision.AddPrimitive(box, new MaterialProperties(0.5f, 0.7f, 0.6f));

            Vector3 com = SetMass(100.0f);
            body.MoveTo(position + com, orientation);

            body.EnableBody();
        }
    }
}
