using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JigLibX.Collision;
using JigLibX.Physics;
using JigLibX.Geometry;
using JigLibX.Math;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using ZombieGame.Managers;

namespace ZombieGame.PhysicObjects.Obstacles
{
    class Crate : Obstacle
    {
        public Crate(Game game, Matrix orientation, Vector3 position)
            : base(game, orientation, position, ModelManager.Models["Crate"])
        {
            damage = 1;

            collision.AddPrimitive(new Box(new Vector3(-0.5f, 0.0f, -0.5f), Matrix.CreateTranslation(0.0f, 0.0f, 0.0f), new Vector3(1.0f, 1.0f, 1.0f)),
                                                            new MaterialProperties(0.5f, 0.7f, 0.6f));

            Vector3 com = SetMass(100.0f);
            body.MoveTo(position + com, orientation);

            body.EnableBody();
        }
    }
}