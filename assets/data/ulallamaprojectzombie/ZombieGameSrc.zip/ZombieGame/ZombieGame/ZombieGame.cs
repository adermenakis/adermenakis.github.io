#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.GameLogic.Objectives;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Obstacles;
using ZombieGame.Screens;

#endregion

namespace ZombieGame
{

    #region ImmovableSkinPredicate
    class ImmovableSkinPredicate : CollisionSkinPredicate1
    {
        public override bool ConsiderSkin(CollisionSkin skin0)
        {
            if (skin0.Owner != null && !skin0.Owner.Immovable)
                return true;
            else
                return false;
        }
    }
    #endregion

    public class ZombieGame : Microsoft.Xna.Framework.Game
    {
        #region Attributes
        GraphicsDeviceManager graphics;
        GraphicsDevice device;

        private static ZombieGame instance = new ZombieGame();
        public static ZombieGame Instance { get { return instance;}}

        Stack<Screen> screenStack = new Stack<Screen>();

        float soundVolume = 0.7f;

        PhysicsSystem physicSystem;
        DebugDrawer debugDrawer;
        Camera camera;
        OnScreenMessage messages;
        SoundEffectInstance engineSoundPlaying;
        SoundEffectInstance brakeSoundPlaying;

        CarObject carObject;

        ConstraintWorldPoint objectController = new ConstraintWorldPoint();
        ConstraintVelocity damperController = new ConstraintVelocity();
        
        SpriteBatch spriteBatch;
        List<Obstacle> obstacles;

        ObjectiveManager checkpoints;

        public GameLogic.Timer gameTimer = new GameLogic.Timer();

        Track track;
        Controllers.ZombieController zombieController = null;

        int damageTimer;
        #endregion

        #region Game States
        public enum GameStates
        {
            MainScreen,
            TrackSelectionScreen,
            CarSelectionScreen,
            GameplayScreen,
            OptionScreen,
            PauseScreen,
            GameOverScreen
        }
        #endregion

        #region Properties
        public static GameStates GameState { get; set; }
        public DebugDrawer DebugDrawer
        {
            get { return debugDrawer; }
        }
        public Camera Camera
        {
            get { return camera; }
        }
        //public Road Road { get; set; }
        public Vector3 CarPosition { get { return carObject.getPosition(); } }
        public Matrix CarOrientation { get { return carObject.PhysicsBody.Orientation; } }
        
        public int ElapsedLaps { get; private set; }
        public int CarHealth 
        {
            get
            {
                return carObject.Health;
            }
        }
        public bool IsGameWon { get; set; }
        public bool IsGameLost { get; set; }
		public bool isDamaged { get; set; }
        #endregion

        #region Constructor
        public ZombieGame()
        {
            zombieController = new Controllers.ZombieController(this);
            graphics = new GraphicsDeviceManager(this);

            Content.RootDirectory = "content";
            GameState = GameStates.MainScreen;
            device = graphics.GraphicsDevice;

            graphics.SynchronizeWithVerticalRetrace = false;
            this.IsFixedTimeStep = true;
            physicSystem = new PhysicsSystem();            
            obstacles = new List<Obstacle>();

            physicSystem.CollisionSystem = //new CollisionSystemGrid(100, 100, 100, 100, 100, 100);
                new CollisionSystemSAP();

            physicSystem.Gravity = new Vector3(0.0f, -40.0f, 0.0f);

            physicSystem.EnableFreezing = true;
            physicSystem.SolverType = PhysicsSystem.Solver.Normal;
            physicSystem.CollisionSystem.UseSweepTests = true;

            physicSystem.NumCollisionIterations = 1;
            physicSystem.NumContactIterations = 1;
            physicSystem.NumPenetrationRelaxtionTimesteps = 15;

            camera = new GameCamera(this);

            HUDisplay HUDisp = new HUDisplay(this);           

            debugDrawer = new DebugDrawer(this);
            debugDrawer.Enabled = false;

            Components.Add(HUDisp);

            Components.Add(camera);
            Components.Add(debugDrawer);

            HUDisp.DrawOrder = 2;

            debugDrawer.DrawOrder = 3;
            this.IsMouseVisible = false;
        }
        #endregion

        public void RestoreRenderState()
        {
            this.graphics.GraphicsDevice.RenderState.DepthBufferEnable = true;
            this.graphics.GraphicsDevice.RenderState.AlphaTestEnable = true;
            this.graphics.GraphicsDevice.SamplerStates[0].AddressU = TextureAddressMode.Wrap;
            this.graphics.GraphicsDevice.SamplerStates[0].AddressV = TextureAddressMode.Wrap;
            this.graphics.GraphicsDevice.RenderState.AlphaBlendEnable = true;
        }
       
        private void InitializeCar()
        {
            ElapsedLaps = 0;
            track = Track.CreateTrack(Player.Instance.Track, this);
            if (track == null) System.Console.Out.WriteLine(Track.MessageError);
            Components.Add(track);
            PlaceInitialZombies();

            carObject = CarFactory.createCar(Player.Instance.Car, this, physicSystem);
            carObject.Car.Chassis.Body.MoveTo(track.RoadControlPoints[0], Matrix.CreateRotationY(track.InitialYorientation));
            carObject.Car.EnableCar();
            carObject.Car.Chassis.Body.AllowFreezing = false;
            this.Components.Add(carObject);
            ((GameCamera)camera).setObjectToFollow(carObject);

            //if (Player.Instance.Track 
            //checkpoints = ObjectiveLoader.loadCheckpoints(0);//loads level check points
            //if (!ObjectiveLoader.isLoaded())
            //{
                //Components.Remove(checkpoints);
            IsGameWon = false;
            IsGameLost = false;
            OnScreenMessage.ClearMessage();
            //if (checkpoints != null) 
            //{ 
            //    checkpoints.ClearAll(); 
            //    Objective.ClearNumberOfObjectives(); 
            //}
                //Components.Add(checkpoints);
            //}
            Components.Remove(checkpoints);
            Components.Remove(messages);

            checkpoints = ObjectiveLoader.loadCheckpoints(Player.Instance.Track);//loads level check points

            Components.Add(checkpoints);
            Components.Add(messages);

        }

        private SoundEffectInstance carDamage;

        public bool handleCollisionDetection(CollisionSkin owner, CollisionSkin collidee)
        {
            
            if (owner != null && owner.Equals(carObject.Car.Chassis.Skin) &&
                collidee != null && collidee.Owner != null && !collidee.Owner.Immovable)
            {
                foreach (DrawableGameComponent gc in Components)
                {
                    if (gc is ZombieObject)
                    {
                        ZombieObject zombie = (ZombieObject)gc;
                        if (zombie.PhysicsSkin == collidee)
                        {
                            if (!zombie.Dead && !zombie.Dying)
                            {
                                //check zombie orientation
                                if (CheckZombieAttack(zombie))
                                {
                                    if (carDamage == null)
                                    {
                                        carDamage = AudioManager.Sounds["CarDamage"].CreateInstance();
                                        carDamage.Play();
                                    }
                                    else if (carDamage.State == SoundState.Stopped)
                                        carDamage.Play();

                                    zombie.PhysicsBody.AddBodyForce(-zombie.PhysicsBody.Velocity);
                                    zombie.PhysicsBody.SetDeactivationTime(60);
                                    carObject.Health -= 10;
                                    isDamaged = true;
                                    damageTimer = 1000;
                                }
                                else
                                {
                                    zombie.Dying = true;
                                    AudioManager.Sounds["Splat"].Play();
                                    Player.Instance.Score += zombie.Points;
                                    
                                }
                            }
                            return true;
                        }
                    }
                    else if (gc is Obstacle)
                    {
                        Obstacle o = (Obstacle)gc;
                        if (o.PhysicsSkin == collidee)
                        {
                            //if (!zombie.Dead)
                            {
                                carObject.Health -= o.Damage;
                            }
                            carObject.Health -= o.Damage;
                            return true;
                        }
                    }
                }
            }
            return true;
        }

        private bool CheckZombieAttack(ZombieObject zombie)
        {
            bool isZombieAttack = true;
            var zombieDirection = carObject.Car.Chassis.Body.Position - zombie.PhysicsBody.Position;
            var carDirection = carObject.Car.Chassis.Body.Velocity;
            var angle = Math.Atan2(zombieDirection.Z, zombieDirection.X) - Math.Atan2(carDirection.Z, carDirection.X);
            var angleGrad = MathHelper.ToDegrees((float)angle) % 360;
            if (angleGrad < 0) angleGrad += 360;
            if (angleGrad > 120 && angleGrad < 240) isZombieAttack = false;

            return isZombieAttack;
        }

        public CollisionCallbackFn CollisionFunction { get { return new CollisionCallbackFn(handleCollisionDetection); } }

        #region Load/Unload Content
        protected override void  LoadContent()
        {
            device =  graphics.GraphicsDevice;
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Services.AddService(typeof(SpriteBatch), spriteBatch);
            Services.AddService(typeof(GraphicsDeviceManager), graphics);
            
            AudioManager.Load(Content);
            TextureManager.Load(Content);
            FontManager.Load(Content);
            ModelManager.Load(Content);
            SceneryFactory.Load(this);
            MediaPlayerPlaylist.Instance.Load(Content);

            MediaPlayerPlaylist.Instance.Play("Menu1");

            damageTimer = 1000;

            screenStack.Push(new CarScreen(graphics, screenStack));
            screenStack.Push(new TrackScreen(graphics, screenStack));
            screenStack.Push(new MainScreen(graphics, screenStack));
            #region DO NOT REMOVE!!! Ineed it for testing objects
            /*
            for (int i = 0; i < 1; i++)
            {
                HeightmapObject heightmapObj = new HeightmapObject( this, ModelManager.Models["Sculptor"], new Vector2(0, -256 * i));
                this.Components.Add(heightmapObj);
            }*/

            //TriangleMeshObject triObj = new TriangleMeshObject(this, ModelManager.Models["Track2"], Matrix.Identity, Vector3.Zero);
            //this.Components.Add(triObj);

            //Vector3 flagPosition = Road.MainRoadPoints[0];
            //flagPosition.Z += -15.0f;
            //var flagPosition = track.RoadControlPoints[0];
            //flagPosition.Y += 5.0f;
            //Components.Add(new Flag(this, Matrix.Identity, flagPosition));

            // DO NOT REMOVE!!! Ineed it for testing objects
            //flagPosition.Y = 10.0f;
            //flagPosition.Z += 10.0f;
            //Components.Add(SceneryFactory.CreateObstacle(ObstacleType.ECactus1, flagPosition, Matrix.Identity));
            

            

            //PlaceInitialZombies();

            //HUDisplay disp = new HUDisplay(this, spriteBatch);
            //disp.Enabled = true;
            //disp.Visible = true;
            //disp.DrawOrder = 4;
            //Components.Add(disp);
            #endregion

            ((GameCamera)camera).setObjectToFollow(carObject);

            messages = new OnScreenMessage(graphics);
            base.LoadContent();
        }

        protected override void UnloadContent()
        {
            Content.Unload();
            base.UnloadContent();
        }

        #endregion

        public void PlaceInitialZombies()
        {
            zombieController.ClearAll();
            List<Vector3> zombiesPositions = SetZombiesPositions();
            Random ran = new Random();
            int i = 1;
            foreach (var zombiePosition in zombiesPositions)
            {
  
                ZombieObject zombie = new SlugZombie(this);
                int isZard = ran.Next();
                if (isZard % 2 == 1) { zombie = new ZardZombie(this); }

                zombie.PhysicsBody.CollisionSkin.SetMaterialProperties(0, new MaterialProperties(0.7f, 0.3f, 0.3f));
                zombie.PhysicsBody.AllowFreezing = false;
                zombie.PhysicsBody.DoShockProcessing = false;
                this.Components.Add(zombie);

                zombie.PhysicsBody.MoveTo(zombiePosition, Matrix.Identity);
                zombie.NativePosition = zombiePosition;
                zombie.zombieNumber = i++;
                zombieController.addZombie(zombie);
            }
            physicSystem.AddController(zombieController);
        }

        private List<Vector3> SetZombiesPositions()
        {
            List<Vector3> zombiesPositions = new List<Vector3>();
            //zombiesPositions.Add(new Vector3(-170, 10.62f, -157));
            //zombiesPositions.Add(new Vector3(-250, 10.62f, -157));
            //zombiesPositions.Add(new Vector3(-300, 10.62f, -157));
            track.ZombieSections.ForEach(zs =>
            {
                float diffrX = (zs.End.X - zs.Start.X) / zs.NumOfZombies;
                float diffrZ = (zs.End.Z - zs.Start.Z) / zs.NumOfZombies;
                float yPosition = zs.Start.Y + 5.0f;
                for (int i = 1; i <= zs.NumOfZombies; i++)
                {
                    zombiesPositions.Add(zs.Start + new Vector3(diffrX * i, yPosition, diffrZ * i));
                }
            });

            return zombiesPositions;
        }

        bool singleStep = false;
        Stopwatch sw = new Stopwatch();

        private void ResetCar()
        {
            Vector3 gotoPos = checkpoints.lastCheckpointCleared.position;
            gotoPos.Y+=2;
            carObject.Car.Chassis.Body.Position = gotoPos;
            carObject.PhysicsBody.MoveTo(gotoPos, checkpoints.lastCheckpointCleared.orientation);

        }

        public void ResetGame()
        {
            ElapsedLaps = 0;
            if (carObject != null)
            {
                carObject.Car.Chassis.DisableChassis();
                carObject.Car.DisableCar();
                carObject.Dispose();
            }

            if (track != null)
            {
                physicSystem.RemoveBody(track.PhysicsBody);
                physicSystem.CollisionSystem.RemoveCollisionSkin(track.PhysicsSkin);
                Components.Remove(track);
                track.PhysicsBody.DisableBody();
                track.Dispose();
            }

            ResetTimerAndScore();
            InitializeCar();
        }

        private void ResetTimerAndScore()
        {
            gameTimer.Reset();
            foreach (DrawableGameComponent gc in Components)
            {
                if (gc is ZombieObject)
                {
                    ZombieObject zombie = (ZombieObject)gc;

                    zombie.Dead = false;
                    Player.Instance.Score = 0;
                }
            }
        }

        protected override void Update(GameTime gameTime)
        {
            MediaPlayerPlaylist.Instance.Update();
            Input.InputManager.handleInput();

            if (Input.InputManager.isPressed(Keys.R, Buttons.X))
            {
                ResetCar();
            }

            if (screenStack.Peek() is GameScreen &&
                carObject == null)
                InitializeCar();

            screenStack.Peek().Update();

            if (screenStack.Peek() is GameScreen && carObject != null)
            {
                if(Input.InputManager.isPressed(Keys.Escape, Buttons.Start))
                {
                    screenStack.Push(new PauseScreen(graphics, screenStack));
                }

                if (ElapsedLaps == Player.Instance.Laps+1)
                {
                    screenStack.Pop();
                    screenStack.Push(new GameOverScreen(graphics, screenStack, this));
                }

                ((GameCamera)camera).Update(gameTime);
                #region carstuff
                //if (carObject.Car.Chassis.Body.Position.X > track.RoadControlPoints[0].X - 10 &&
                //        carObject.Car.Chassis.Body.Position.Z >= track.RoadControlPoints[0].Z - 5 &&
                //        carObject.Car.Chassis.Body.Position.Z < track.RoadControlPoints[0].Z - 1)
                //{
                //        if (Player.Instance.Laps - ElapsedLaps > -1)
                //        {
                //            isOutOfStart = true;
                //            if (!scoresSaved && ElapsedLaps > 0)
                //            {
                //                previousLapStat.Score = Player.Instance.Score;
                //                previousLapStat.LapNumber = ElapsedLaps;
                //                previousLapStat.LapTime = gameTimer.ElapsedTime;
                //                scoresSaved = true;
                //            }
                //            ResetTimerAndScore();
                //            gameTimer.Start();
                //        }
                //    else if (gameTimer.IsEnabled && Player.Instance.Laps == ElapsedLaps) gameTimer.Stop();
                //}
                //else if (isOutOfStart)
                //{
                //    isOutOfStart = false;
                //    scoresSaved = false;
                //    Player.Instance.Statistics.Add(previousLapStat);
                //    previousLapStat = new GameStat();
                //    ElapsedLaps++;
                //}
#endregion

                gameTimer.Update();

                if (screenStack.Peek() is GameScreen)
                {
                    UpdateGameplayScreen(gameTime);
                }

                zombieController.UpdateController(0);
            }
            if (damageTimer > 0)
                damageTimer -= gameTime.ElapsedGameTime.Milliseconds;
            else
                isDamaged = false;

            base.Update(gameTime);
        }

        private void UpdateGameplayScreen(GameTime gameTime)
        {
            GraphicsDevice.RenderState.DepthBufferEnable = true;

            if (IsGameWon) { WinningGame(); return; }
            if (carObject.Health <= 0) { carObject.Health = 0; LoosingGame("Car has been destroyed!"); return; }
            if (gameTimer.RemainingTime.Minutes < 0) { LoosingGame("Time is over!"); return; }

            KeyboardState keyState = Keyboard.GetState();
            GamePadState gp = GamePad.GetState(PlayerIndex.One);

            debugDrawer.Enabled = keyState.IsKeyDown(Keys.C);

            if (keyState.IsKeyDown(Keys.Up) || keyState.IsKeyDown(Keys.Down) ||
                gp.IsButtonDown(Buttons.RightTrigger) || gp.IsButtonDown(Buttons.LeftTrigger))
            {
                if (keyState.IsKeyDown(Keys.Up)||
                    gp.IsButtonDown(Buttons.RightTrigger))
                {
                    carObject.Car.Accelerate = 1.0f;

                    if (engineSoundPlaying == null)
                        engineSoundPlaying = carObject.EngineSound.CreateInstance();
                    else
                    {
                        if (engineSoundPlaying.Pitch < 0.2f)
                            engineSoundPlaying.Pitch += 0.01f;
                        engineSoundPlaying.Volume = soundVolume;
                        engineSoundPlaying.Play();
                    }
                }
                else
                {
                    carObject.Car.Accelerate = -1.0f;

                    if (engineSoundPlaying == null)
                        engineSoundPlaying = carObject.EngineSound.CreateInstance();
                    else
                    {
                        if (engineSoundPlaying.Pitch > -0.5f)
                            engineSoundPlaying.Pitch -= 0.01f;
                        engineSoundPlaying.Volume = soundVolume;
                        engineSoundPlaying.Play();
                    }
                }
            }
            else
            {
                carObject.Car.Accelerate = 0.0f;

                if (engineSoundPlaying == null)
                {
                    engineSoundPlaying = carObject.EngineSound.CreateInstance();
                    engineSoundPlaying.Pitch = -0.5f;
                }
                else
                {
                    if (engineSoundPlaying.Pitch > -0.5f)
                        engineSoundPlaying.Pitch -= 0.01f;

                    engineSoundPlaying.Volume = soundVolume;
                    engineSoundPlaying.Play();
                }
            }
#if WINDOWS
            if (keyState.IsKeyDown(Keys.Left) || keyState.IsKeyDown(Keys.Right))
            {
                if (keyState.IsKeyDown(Keys.Left))
                    carObject.Car.Steer = 1.0f;
                else
                    carObject.Car.Steer = -1.0f;
            }
            else
                carObject.Car.Steer = 0.0f;
#endif

#if XBOX
            carObject.Car.Steer = -1.0f*gp.ThumbSticks.Left.X;
#endif
            if (keyState.IsKeyDown(Keys.Space) || gp.IsButtonDown(Buttons.A))
            {
                carObject.Car.HBrake = 1.0f;
                if (brakeSoundPlaying == null)
                {
                    brakeSoundPlaying = AudioManager.Sounds["Brake"].CreateInstance();
                    brakeSoundPlaying.Play();
                }
            }
            else
            {
                if (brakeSoundPlaying != null)
                {
                    brakeSoundPlaying.Stop();
                    brakeSoundPlaying = null;
                }
                carObject.Car.HBrake = 0.0f;
            }

             camera.Update(gameTime);

            if (singleStep == true && keyState.IsKeyDown(Keys.Space) == false)
            {
                // don't intergrate so we can step at will
            }
            else
            {
                float timeStep = (float)gameTime.ElapsedGameTime.Ticks / TimeSpan.TicksPerSecond;
                if (timeStep < 1.0f / 60.0f) physicSystem.Integrate(timeStep);
                else physicSystem.Integrate(1.0f / 60.0f);
            }
            //zombies replacement
            //RepositionZombies();
        }

        private void LoosingGame(string message)
        {
            IsGameLost = true;
            gameTimer.Stop();
            OnScreenMessage.PostMessage(message + " Game lost!", 10);

            screenStack.Pop();
            MediaPlayerPlaylist.Instance.Play("Menu2");
            screenStack.Push(new GameOverScreen(graphics, screenStack, this));
        }

        private void WinningGame()
        {
            IsGameWon = true;
            gameTimer.Stop();
            OnScreenMessage.PostMessage(" Game won!", 10);
            MediaPlayerPlaylist.Instance.Play("Menu2");
            screenStack.Pop();

            screenStack.Push(new GameOverScreen(graphics, screenStack, this));
        }

        private Vector3 RayTo(int x, int y)
        {
            Vector3 nearSource = new Vector3(x, y, 0);
            Vector3 farSource = new Vector3(x, y, 1);

            Matrix world = Matrix.CreateTranslation(0, 0, 0);

            Vector3 nearPoint = graphics.GraphicsDevice.Viewport.Unproject(nearSource, Camera.Projection, Camera.View, world);
            Vector3 farPoint = graphics.GraphicsDevice.Viewport.Unproject(farSource, Camera.Projection, Camera.View, world);

            Vector3 direction = farPoint - nearPoint;
            //direction.Normalize();
            return direction;
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            screenStack.Peek().Draw(spriteBatch);

            if (screenStack.Peek() is GameScreen)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(TextureManager.Textures["Sky"], Vector2.Zero, Color.White);
                spriteBatch.End();
                GraphicsDevice.RenderState.DepthBufferEnable = true;
                RestoreRenderState();
                base.Draw(gameTime);
            }
        }
    }
}
