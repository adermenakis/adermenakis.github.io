﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.GameLogic.Objectives;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.GameLogic
{
    class ObjectiveLoader
    {
        static int currentTrack = 0;
        static ObjectiveManager manager;
        static public ObjectiveManager loadCheckpoints(int level)
        {
            currentTrack = level;
            manager = new ObjectiveManager();
            Checkpoint.resetCount();
            switch(level)
            {
                case 1: level1(); break;
                case 2: level2(); break;
                default: level2(); break;
            }
            return manager;
        }
        static private void level1()
        {
            AddCheckpoint(new Vector3(-55.7f, 1.7f, -154f));

            AddDestroy( new Vector3(-126f, 1.7f, -163.4f),
                        new Vector3(-155f, 1f, -167f));
            AddDestroy( new Vector3(-210f, 1.9f, -173f),
                        new Vector3(-257f, 2f, -177));
            AddDestroy( new Vector3(-308.6f, 1.5f, -149f),
                        new Vector3(-340.7f, 1f, -117f));
            AddDestroy( new Vector3(-356.6f, 1.2f, -117.6f),
                        new Vector3(-348f, 1f, 26f));

            AddCheckpoint(new Vector3(-358.3f, 1f, 54f));
            AddCheckpoint(new Vector3(-42.8f, 1f, -86.1f));
            AddCheckpoint(new Vector3(-45.8f, 1f, 144.4f));
            AddCheckpoint(new Vector3(198.3f, 1f, -183.3f));
            AddCheckpoint(new Vector3(-129.5f, 1f, 64.23f));

        }
        static private void level2()
        {
            AddCheckpoint(new Vector3(-225f,    -2.16f,  380f));
            AddCheckpoint(new Vector3(-400f,    -2.16f,  216f));
            AddCheckpoint(new Vector3(-191f,    -2.16f,  -190f));
            AddCheckpoint(new Vector3(-48.8f,   9.2f,  -133f));
            AddCheckpoint(new Vector3(194f,     -2.16f,  -181.57f));
            AddCheckpoint(new Vector3(285f,     -2.16f,  -381.3f));
            AddCheckpoint(new Vector3(428f,     -2.16f,  -276f));
            AddCheckpoint(new Vector3(450f,     -2.16f,  -84f));
            AddCheckpoint(new Vector3(416f,     -2.16f,  18f));
        }

        private static void AddCheckpoint(Vector3 position)
        {
            BoundingSphere bounds = new BoundingSphere(position, 10);
            List<GameObj> models = CreateListOfOne(new ObjectiveObj(ModelManager.Models["checkPoint"], TextureManager.Textures["Sky"]));
            manager.Add(new Checkpoint(position, bounds, models));
        }
        private static void AddDestroy(Vector3 objective, Vector3 position)
        {
            BoundingSphere bounds = new BoundingSphere(position, 10);
            List<GameObj> models = CreateListOfOne(new ObjectiveObj(ModelManager.Models["checkPoint"], TextureManager.Textures["Sky"]));
            manager.Add(new Destroy(position, bounds, models,objective));
        }

        private static void AddSearchAndDestroy(Vector3 position, Vector3 objective)
        {
            BoundingSphere bounds = new BoundingSphere(position, 10);
            List<GameObj> models = CreateListOfOne(new ObjectiveObj(ModelManager.Models["checkPoint"], TextureManager.Textures["Sky"]));
            manager.Add(new SearchAndDestroy(position, bounds, models, objective));
        }

        private static List<GameObj> CreateListOfOne(GameObj gObj)
        {
            List<GameObj> tempList = new List<GameObj>();
            tempList.Add(gObj);
            return tempList;
        }
        static internal bool isLoaded()
        {
           
            return currentTrack == Player.Instance.Track;
        }


        
    }
}
