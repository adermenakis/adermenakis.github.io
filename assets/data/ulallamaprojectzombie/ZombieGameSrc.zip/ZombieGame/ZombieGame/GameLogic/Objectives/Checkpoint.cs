﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;

using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.GameLogic.Objectives
{
    class Checkpoint : Objective
    {
        static int numberOfCheckpoints = 0;
        public static int NumberOfCheckpoints { get { return numberOfCheckpoints; } }

        public Checkpoint(Vector3 pos, BoundingSphere bounds, List<GameObj> mList) :base(pos,bounds,mList)
        {
            
        }

        public override void OnActiveUpdate(GameTime gameTime, List<Objective> checkPoints)
        {
        }
        protected override void Reward()
        {
            ZombieGame.Instance.gameTimer.AddSeconds(29);
            AudioManager.Sounds["Checkpoint"].Play();
            OnScreenMessage.PostMessage("Checkpoint: " + ZombieGame.Instance.gameTimer.RemainingTime + "\n29s added", 10);
        }

    }
}
