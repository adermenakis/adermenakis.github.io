﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.GameLogic.Objectives;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.GameLogic.Objectives
{
    class ObjectiveLoader
    {
        static int currentTrack = 0;
        static ObjectiveManager manager;
        static public ObjectiveManager loadCheckpoints(int level)
        {
            currentTrack = level;
            manager = new ObjectiveManager();
            Checkpoint.resetCount();
            switch(level)
            {
                case 1: level1(); break;
                case 2: level2(); break;
                default: level2(); break;
            }
            return manager;
        }
        static private void level1()
        {
          
            AddCheckpoint(new Vector3(-55.7f, 1.7f, -154f));

            AddDestroy( new Vector3(-126f, 1.7f, -163.4f),
                        new Vector3(-155f, 1f, -167f));
            AddDestroy( new Vector3(-210f, 1.9f, -173f),
                        new Vector3(-257f, 2f, -177));
            AddDestroy( new Vector3(-308.6f, 1.5f, -149f),
                        new Vector3(-340.7f, 1f, -117f));
            AddDestroy( new Vector3(-356.6f, 1.2f, -117.6f),
                        new Vector3(-348f, 1f, 26f));

            AddCheckpoint(new Vector3(-358.3f, 1f, 54f));

            AddDestroy(new Vector3(-381f, 1.2f, 139.7f),
                        new Vector3(-330.25f, 1f, 120.5f));
            AddDestroy(new Vector3(-380.6f, 1f, 80f),
                        new Vector3(-390f, 1.2f, 127.8f));
            AddSearchAndDestroy( new Vector3(-243.9f, 1f, 153.6f), new Vector3(-272.8f, 1f, 82f));
            AddDestroy(new Vector3(-322.4f, 1f, 52.4f),
                        new Vector3(-340.2f, 1f, 16.65f));
            AddDestroy(new Vector3(-251.4f, 1f, -114.7f),
                        new Vector3(-44.7f, 1f, -72f));

            AddCheckpoint(      new Vector3(-42.8f, 1f, -86.1f));

            AddDestroy(         new Vector3(19f, 1f, -115.5f),               new Vector3(-45.78f, 1f, -61.3f));
            AddSearchAndDestroy(new Vector3(36f, 1f, -75.6f), new Vector3(-57.8f, 1f, -71.3f));
            AddDestroy(         new Vector3(-25f, 1f, 21.9f),                new Vector3(-72f, 1f, 7.4f));
            AddDestroy(         new Vector3(-136.4f, 1f, -2.9f),             new Vector3(-182.9f, 1f, -16f));
            AddDestroy(         new Vector3(-244f, 1.6f, -36f),              new Vector3(-299f, 1.6f, -51f));
            AddDestroy(         new Vector3(-268f, 1f, 26f),                 new Vector3(-212f, 1f, 42f));
            AddDestroy(         new Vector3(-162.7f, 1f, 108f),              new Vector3(-171.1f, 1f, 138.6f));
            AddSearchAndDestroy(new Vector3(-45.8f, 1f, 144.4f), new Vector3(-193.1f, 1f, 138.6f));

            
            AddCheckpoint(new Vector3(-45.8f, 1f, 144.4f));
            AddDestroy(new Vector3(67f, 1.4f, 194f), new Vector3(96f, 1.6f, 193.7f));
            AddDestroy(new Vector3(96.5f, 1f, 86f), new Vector3(149.23f, 1f, 94.17f));
            AddDestroy(new Vector3(234.2f, 1f, 170.9f), new Vector3(207f, 1.1f, 145.6f));          
            AddCheckpoint(new Vector3(198.3f, 1f, -183.3f));

            AddDestroy(new Vector3(115.7f, 1.03f, -119f), new Vector3(182f, 1f, -114.6f));
            AddDestroy(new Vector3(166.7f, 0.7f, 4.2f), new Vector3(216.2f, 1.04f, 117.5f));
            AddDestroy(new Vector3(274.4f, 1.08f, 167.29f), new Vector3(-129.5f, 1f, 64.23f));
            //AddCheckpoint(new Vector3(-129.5f, 1f, 64.23f));

        }
        static private void level2()
        {
                                           
            //ZombieGame.Instance.gameTimer.AddSeconds(40);
            AddCheckpoint(new Vector3(-229f, -2.16f, 375f));
            AddDestroy(new Vector3(-279f,-2f,271f), new Vector3(-346f, 0f, 156f));
            AddDestroy(new Vector3(-456f,-2f,49f), new Vector3(-455f, -2f, -8.7f));
            AddSearchAndDestroy(new Vector3(-264f, -2f, -222.87f), new Vector3(-194f, -2.16f, -189.57f));
            
             
            AddCheckpoint(new Vector3(-194f,     -2.16f,  -189.57f));
            AddDestroy(new Vector3(-51f, 9f, -134.5f), new Vector3(139f, -2f, -6f));
            AddSearchAndDestroy(new Vector3(184.5f, -2f, 47.5f), new Vector3(185f, -2f, -145f));
            AddDestroy(new Vector3(186.7f, -2f,-186f), new Vector3(197.6f, 2f, -297.5f));
            AddDestroy(new Vector3(197.6f, -2f, -341), new Vector3(285f, -2.16f, -381.3f));

            AddCheckpoint(new Vector3(285f,     -2.16f,  -381.3f));
            AddDestroy(new Vector3(391f, -2f, -405f), new Vector3(556.7f, -2f, -450.4f));
            AddDestroy(new Vector3(566f, -2f, -275.6f), new Vector3(410f, -2f, -234f));
            
            AddDestroy(new Vector3(326.4f, -2f, -173.5f), new Vector3(193f, -2f, -57f));
            AddDestroy(new Vector3(141f, -2f, 77f), new Vector3(108f, -2f, 104.6f));

            AddCheckpoint(new Vector3(90f,     -2.16f,  12f));
            
            AddDestroy(new Vector3(20.9f, -2f, -39.6f), new Vector3(-56f, 10.6f, -20.18f));
            AddDestroy(new Vector3(-154f, -2f, -24f), new Vector3(-267f, -2f, -58f));
            AddSearchAndDestroy(new Vector3(-296.6f, -2f, -56.5f), new Vector3(-392f, -2.16f, 53f));
            AddCheckpoint(new Vector3(-392f,     -2.16f,  53f));

            AddDestroy(new Vector3(-463f, -2f, -86f), new Vector3(-539f, .6f, 190f));
            AddDestroy(new Vector3(-520f, -2f, 288f), new Vector3(-430f, -2f, 351f));
            AddDestroy(new Vector3(-190f, 0f, 204f), new Vector3(-216f, -2f, 272f));
            AddSearchAndDestroy(new Vector3(-49f, -2f, 343f), new Vector3(26.5f, 2f, 253f));

            AddCheckpoint(new Vector3(163f,     -2.16f,  321f));
            AddCheckpoint(new Vector3(580.2f, -2.16f, -310f));
            AddCheckpoint(new Vector3(43.9f, -2.16f, -193f));
            
        }

        private static void AddCheckpoint(Vector3 position)
        {
            BoundingSphere bounds = new BoundingSphere(position, 10);
            List<GameObj> models = CreateListOfOne(new ObjectiveObj(ModelManager.Models["checkPoint"], TextureManager.Textures["Sky"]));
            manager.Add(new Checkpoint(position, bounds, models));
        }
        private static void AddDestroy(Vector3 objective, Vector3 position)
        {
            BoundingSphere bounds = new BoundingSphere(position, 10);
            List<GameObj> models = CreateListOfOne(new ObjectiveObj(ModelManager.Models["checkPoint"], TextureManager.Textures["Sky"]));
            manager.Add(new Destroy(position, bounds, models,objective));
        }

        private static void AddSearchAndDestroy(Vector3 objective,Vector3 position)
        {
            BoundingSphere bounds = new BoundingSphere(position, 10);
            List<GameObj> models = CreateListOfOne(new ObjectiveObj(ModelManager.Models["checkPoint"], TextureManager.Textures["Sky"]));
            manager.Add(new SearchAndDestroy(position, bounds, models, objective));
        }

        private static List<GameObj> CreateListOfOne(GameObj gObj)
        {
            List<GameObj> tempList = new List<GameObj>();
            tempList.Add(gObj);
            return tempList;
        }
        static internal bool isLoaded()
        {
           
            return currentTrack == Player.Instance.Track;
        }


        
    }
}
