﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;
using System.Linq;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic.Objectives;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.GameLogic.Objectives
{
    class ObjectiveManager : DrawableGameComponent
    {
        private static ObjectiveArrow arrow = new ObjectiveArrow(ModelManager.Models["CheckPointArrow"], TextureManager.Textures["UpButton"]);
        
        public static ObjectiveArrow Arrow { get { return arrow;}}

        public struct PositionOrientation { public Vector3 position; public Matrix orientation;}

        public PositionOrientation lastCheckpointCleared;
        
        public int NumberOfCheckpoints { get { return objectives.Count; } }

        private List<Objective> objectives;

        public ObjectiveManager()
            : base(ZombieGame.Instance)
        {
            objectives = new List<Objective>();
        }

        public void ClearAll()
        {
            objectives.Clear();
        }

        public void Add(Objective c)
        {
            if (objectives.Count == 0 && c is Checkpoint)
            {
                lastCheckpointCleared.position = c.Position;
                lastCheckpointCleared.orientation = ZombieGame.Instance.CarOrientation;
            }
             

            objectives.Add(c);
        }
        public override void Update(GameTime gameTime)
        {
            Vector3 carPosition = ZombieGame.Instance.CarPosition;
            foreach (Objective objective in objectives)
            {
                
                    bool passed = objective.HasBeenPassed;
                    objective.Update(gameTime, objectives);
                    if (objective is Checkpoint)
                    {
                        if (!passed && objective.HasBeenPassed)
                        {
                            lastCheckpointCleared.position = objective.Position;
                            lastCheckpointCleared.orientation = ZombieGame.Instance.CarOrientation;
                        }
                    }
            }
             
            arrow.Update(gameTime);
            base.Update(gameTime);
        }
        public override void Draw(GameTime gameTime)
        {
            arrow.Draw(gameTime, arrow.Position);
            foreach (Objective objective in objectives)
            {
                objective.Draw(gameTime);
            }

            base.Update(gameTime);
        }


    }
}
