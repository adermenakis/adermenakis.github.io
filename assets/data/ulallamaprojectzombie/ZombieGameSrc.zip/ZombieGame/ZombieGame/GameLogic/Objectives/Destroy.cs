﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion

namespace ZombieGame.GameLogic.Objectives
{
    class Destroy : Objective
    {//
        bool isLoaded = false;
        BoundingSphere objective = new BoundingSphere(new Vector3(-300f, -2.16f, 216f), 2.5f);

        public Destroy(Vector3 pos, BoundingSphere bounds, List<GameObj> mList, Vector3 positionOfObjective) : base(pos,bounds,mList)
        {
            objective = new BoundingSphere(positionOfObjective, 2.5f);
        }

        public override void OnActiveUpdate(GameTime gameTime, List<Objective> checkPoints)
        {
            if (!isLoaded)
            {
                isLoaded = true;
                OnScreenMessage.PostMessage("Destroy!!", 5);
                SceneLoader.BuildBoxTower(objective.Center);
            }
        }

        bool carHasKnockedDown = false;
        protected override bool checkWiningCondition()
        {
            Vector3 carPosition = ZombieGame.Instance.CarPosition;
            bool carHitsCheckpoint = boundingSphere.Intersects(new BoundingSphere(carPosition, 1));
            if (!carHasKnockedDown)
            {
                carHasKnockedDown = objective.Intersects(new BoundingSphere(carPosition, 1));
                if (carHasKnockedDown)
                {
                    ObjectiveManager.Arrow.PointTo(this);
                    OnScreenMessage.PostMessage("YEAH!!", 5);
                }
                else
                {
                    ObjectiveManager.Arrow.PointTo(objective.Center);
                }

                if (carHitsCheckpoint)
                {
                    OnScreenMessage.PostMessage("You can't continue until you clear those boxes...", 5);
                }
            }

            if (carHasKnockedDown && carHitsCheckpoint)
            {
                AudioManager.Sounds["Target"].Play();
                SceneLoader.UnloadScene();
                return true;
            }
                
            return false;

        }
        protected override void Reward()
        {
            Player.Instance.Score += 45;
        }

      
    }
}
