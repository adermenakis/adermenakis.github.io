﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.GameLogic.Objectives
{//
    abstract class Objective
    {
        static int numberOfObjectives = 0;

        protected List<GameObj> gameObjects = new List<GameObj>();
        protected BoundingSphere boundingSphere = new BoundingSphere();

        protected Vector3 position = new Vector3(0, 0, 0);
        public Vector3 Position { get { return position; } }

        protected bool active = false;
        public bool IsActive { get { return active; } }

        protected bool passed = false;
        public bool HasBeenPassed { get { return passed; } }

        public Objective(Vector3 pos, BoundingSphere bounds, List<GameObj> mList)
        {
            if (numberOfObjectives == 0)
            {
                active = true;
            }
            numberOfObjectives++;
            boundingSphere = bounds;
            position = pos;
            gameObjects = mList;
        }

        //public static void ClearNumberOfObjectives() { numberOfObjectives = 0; }

        public void Draw(GameTime gameTime)
        {
            if (active)
            {
                foreach (GameObj gObj in gameObjects)
                {
                    gObj.Draw(gameTime, position);
                }
            }
        }
        

        public void Update(GameTime gameTime, List<Objective> checkPoints)
        {
            if (active)
            {
                Timer time = ZombieGame.Instance.gameTimer;
                if (!time.IsEnabled && !ZombieGame.Instance.IsGameLost && !ZombieGame.Instance.IsGameWon)
                {
                    time.AddSeconds(30);
                    time.Start();
                }
                
                ObjectiveManager.Arrow.PointTo(this);
                foreach (GameObj gObj in gameObjects)
                {
                    gObj.Update(gameTime);
                }

                if (checkWiningCondition())
                {
                    Reward();
                    active = false;
                    passed = true;
                    int indexOfNext = 1 + checkPoints.IndexOf(this);
                    if (indexOfNext < checkPoints.Count)
                    {
                        checkPoints[indexOfNext].Activate();
                    }
                    else { ZombieGame.Instance.IsGameWon = true; }
                }
                OnActiveUpdate(gameTime, checkPoints);
            }
        }

        protected abstract void Reward();
        public abstract void OnActiveUpdate(GameTime gameTime, List<Objective> checkPoints);
        

        protected virtual void Activate()
        {
            active = true;
        }
        protected virtual bool checkWiningCondition()
        {
            Vector3 carPosition = ZombieGame.Instance.CarPosition;
            bool carHitsCheckpoint = boundingSphere.Intersects(new BoundingSphere(carPosition, 1));
            return carHitsCheckpoint;
         }

        internal static void resetCount()
        {
            numberOfObjectives = 0;
        }
    }
}
