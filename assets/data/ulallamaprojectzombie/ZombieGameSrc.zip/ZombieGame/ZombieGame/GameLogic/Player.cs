﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ZombieGame.Factories;

namespace ZombieGame.GameLogic
{
    public struct GameStat
    {
        public int LapNumber;
        public Time LapTime;
        public int Score;

        public override string ToString()
        {
            return String.Format("{0}        {1}        {2}", LapNumber, LapTime, Score);
        }
    }

    class Player
    {
        private int score = 0;
        private CarType car = CarType.EDelorian;
        private static Player instance = new Player();
        private int laps = 3;
        private List<GameStat> stats = new List<GameStat>();
        public int Track { get; set; }

        public List<GameStat> Statistics { get { return stats; } }

        public void ResetScores() { stats = new List<GameStat>();}

        public int Laps
        {
            get { return laps; }

            set
            {
                if (laps > 0 || value > 0)
                    laps = value;
            }
        }

        private Player() { }

        public int Score { get { return score; } set { score = value; } }

        public CarType Car { get { return car; } set { car = value; } }

        public static Player Instance { get { return instance; } }
    }
}
