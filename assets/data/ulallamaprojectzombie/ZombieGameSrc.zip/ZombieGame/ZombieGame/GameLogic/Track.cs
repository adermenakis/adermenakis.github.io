﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using ZombieGame.PhysicObjects;
using ZombieGame.Managers;

namespace ZombieGame.GameLogic
{
    class Track : TriangleMeshObject
    {
        #region Properties
        public int trackId { get; set; }
        public static string MessageError { get; set; }
        public Vector3 StartPoint { get; set; }
        public Vector3 EndPoint { get; set; }
        public List<Vector3> CheckPoints { get; private set; }
        public List<Vector3> RoadControlPoints { get; private set; }
        public float InitialYorientation { get; private set; }
        public int NumOfStrightSections { get; private set; }
        public List<ZombieSection> ZombieSections { get; private set; }
        #endregion

        private Track(Game iGame, Model iModel, int id)
            :base(iGame, iModel, Matrix.Identity, Vector3.Zero)
        {
            trackId = id;
            CheckPoints = new List<Vector3>();
            RoadControlPoints = new List<Vector3>();
            ZombieSections = new List<ZombieSection>();
            CreateRoadControlPoints(trackId);
        }

        public static Track CreateTrack(int iTrackNumber, Game iGame)
        {
            try
            {
                return new Track(iGame, ModelManager.Models[string.Format("Track{0}", iTrackNumber)], iTrackNumber);
            }
            catch (Exception ex)
            {
                MessageError = string.Format("Error initializing track. {0}", ex);
                return null;
            }
        }

        public void AddCheckPoint(Vector3 iPosition)
        {
            CheckPoints.Add(iPosition);
        }
        void CreateRoadControlPoints(int trackId)
        {
            if (trackId == 1)
            {
                RoadControlPoints.Add(new Vector3(-49, 1.62f, -157));//0 start
                RoadControlPoints.Add(new Vector3(-330, 1.62f, -150));//1
                RoadControlPoints.Add(new Vector3(-320, 1.62f, 120));//2
                RoadControlPoints.Add(new Vector3(-300, 1.62f, -55));//3
                RoadControlPoints.Add(new Vector3(40, 1.62f, -65));//4
                RoadControlPoints.Add(new Vector3(-10, 1.62f, 20));//5
                RoadControlPoints.Add(new Vector3(-215, 1.62f, -8));//6
                RoadControlPoints.Add(new Vector3(-185, 1.62f, 100));//7
                RoadControlPoints.Add(new Vector3(50, 1.62f, 140));//8
                RoadControlPoints.Add(new Vector3(210, 1.62f, 35));//9
                RoadControlPoints.Add(new Vector3(285, 1.62f, 10));//10
                RoadControlPoints.Add(new Vector3(275, 1.62f, 150));//11
                RoadControlPoints.Add(new Vector3(110, 1.62f, -180));//12
                RoadControlPoints.Add(new Vector3(162, 1.62f, -95));//13
                RoadControlPoints.Add(new Vector3(120, 1.62f, 48));//14
                RoadControlPoints.Add(new Vector3(-97, 1.62f, 91));//15
                RoadControlPoints.Add(new Vector3(-130, 1.62f, 160));//16 finish
                InitialYorientation = MathHelper.Pi;

                ZombieSections.Add(new ZombieSection(RoadControlPoints[1], RoadControlPoints[2], 0, 4));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[3], RoadControlPoints[4], 1, 3));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[5], RoadControlPoints[6], 2, 3));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[7], RoadControlPoints[8], 3, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[8], RoadControlPoints[9], 4, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[11], RoadControlPoints[12], 5, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[13], RoadControlPoints[14], 6, 2));

            }
            else if (trackId == 2)
            {
                RoadControlPoints.Add(new Vector3(-225, -2.20f, 380));//0 start
                RoadControlPoints.Add(new Vector3(-450, -2.19f, 150));//1
                RoadControlPoints.Add(new Vector3(-340, -2.19f, -140));//2
                RoadControlPoints.Add(new Vector3(-30, -2.19f, -120));//3
                RoadControlPoints.Add(new Vector3(170, -2.19f, -125));//4
                RoadControlPoints.Add(new Vector3(168, -2.19f, -283));//5
                RoadControlPoints.Add(new Vector3(380, -2.19f, -405));//6
                RoadControlPoints.Add(new Vector3(414, -2.19f, 26));//7
                RoadControlPoints.Add(new Vector3(161, -2.19f, 81));//8
                RoadControlPoints.Add(new Vector3(112, -2.19f, 21));//9
                RoadControlPoints.Add(new Vector3(30, -2.19f, -30));//10
                RoadControlPoints.Add(new Vector3(-145, -2.19f, -20));//11
                RoadControlPoints.Add(new Vector3(-220, -2.19f, -88));//12
                RoadControlPoints.Add(new Vector3(-330, -2.19f, -66));//13
                RoadControlPoints.Add(new Vector3(-396, -2.19f, 128));//14
                RoadControlPoints.Add(new Vector3(315, -2.19f, 315));//15
                RoadControlPoints.Add(new Vector3(575, -2.19f, -315));//16            
                RoadControlPoints.Add(new Vector3(-50, -2.19f, -268));//17            
                RoadControlPoints.Add(new Vector3(45, -2.19f, -190));//18 finish
                InitialYorientation = MathHelper.Pi * 0.7f;

                ZombieSections.Add(new ZombieSection(RoadControlPoints[1], RoadControlPoints[2], 0, 3));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[3], RoadControlPoints[4], 1, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[5], RoadControlPoints[6], 2, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[7], RoadControlPoints[8], 3, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[11], RoadControlPoints[12], 4, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[13], RoadControlPoints[14], 5, 2));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[14], RoadControlPoints[15], 6, 3));
                ZombieSections.Add(new ZombieSection(RoadControlPoints[15], RoadControlPoints[16], 7, 3));

            }
        }
    }

    public struct ZombieSection
    {
        public Vector3 Start, End;
        public int SectionNumber, NumOfZombies;

        public ZombieSection(Vector3 start, Vector3 end, int secNum, int zomNum)
        {
            Start = start; End = end; SectionNumber = secNum; NumOfZombies = zomNum;
        }
    }
}
