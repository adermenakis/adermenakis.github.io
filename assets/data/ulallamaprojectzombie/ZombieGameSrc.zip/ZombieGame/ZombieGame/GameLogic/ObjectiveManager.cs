﻿#region Using Statements
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using JigLibX.Physics;
using JigLibX.Collision;
using JigLibX.Geometry;
using JigLibX.Math;
using JigLibX.Utils;
using JigLibX.Vehicles;

using ZombieGame.PhysicObjects;
using ZombieGame.Cameras;
using ZombieGame.Managers;
using ZombieGame.PhysicObjects.Zombies;
using ZombieGame.GameLogic.Objectives;
using ZombieGame.Factories;
using ZombieGame.GraphicsTools;
using ZombieGame.PhysicObjects.Objectives;
using ZombieGame.Screens;

#endregion


namespace ZombieGame.GameLogic
{
    class ObjectiveManager : DrawableGameComponent
    {

        private static ObjectiveArrow arrow = new ObjectiveArrow(ModelManager.Models["CheckPointArrow"], TextureManager.Textures["UpButton"]);
        
        public static ObjectiveArrow Arrow { get { return arrow;}}

        public Checkpoint LastCheckpointCleared { get; private set; }
        
        public int NumberOfCheckpoints { get { return objectives.Count; } }

        private List<Objective> objectives = new List<Objective>();

        public ObjectiveManager()
            : base(ZombieGame.Instance)
        {
        }
        public void Add(Objective c)
        {
            if (objectives.Count == 0 && c is Checkpoint)
                LastCheckpointCleared = (Checkpoint)c;

            objectives.Add(c);
        }
        public override void Update(GameTime gameTime)
        {
            Vector3 carPosition = ZombieGame.Instance.CarPosition;
            foreach (Objective objective in objectives)
            {
                
                    bool passed = objective.HasBeenPassed;
                    objective.Update(gameTime, objectives);
                    if (objective is Checkpoint)
                    {
                        if (!passed && objective.HasBeenPassed)
                            LastCheckpointCleared = (Checkpoint)objective;
                    }
            }
             
            arrow.Update(gameTime);
            base.Update(gameTime);
        }
        public override void Draw(GameTime gameTime)
        {
            arrow.Draw(gameTime, arrow.Position);
            foreach (Objective objective in objectives)
            {
                objective.Draw(gameTime);
            }

            base.Update(gameTime);
        }


    }
}
