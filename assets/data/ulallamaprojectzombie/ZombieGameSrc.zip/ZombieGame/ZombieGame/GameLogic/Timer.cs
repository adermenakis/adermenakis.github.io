﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZombieGame.GameLogic
{
    public struct Time
    {
        public int Minutes;
        public int Seconds;
        public int Sixtieths;


        public override string ToString()
        {
            return format(Minutes) + ":" + format(Seconds) + ":" + format(Sixtieths);
        }
        private String format(int i)
        {
            if (i < 10)
            {
                return "0" + i;
            }
            return ""+i;
        }

    }


    public class Timer
    {
        private Time remainingTime = new Time();
        private bool isEnabled = false;

        public Timer()
        {
            Reset();
        }

        public void Start() { isEnabled = true; }
        public void Stop() { isEnabled = false; remainingTime.Minutes = 0; remainingTime.Seconds = 0; }
        public bool IsEnabled { get { return isEnabled; } }
        public Time RemainingTime { get { return remainingTime; } }

        public void Update()
        {
            if (remainingTime.Minutes < 0) Stop(); 

            if (!isEnabled)
                return;

            if (remainingTime.Sixtieths == 0)
            {
                remainingTime.Sixtieths = 60;
                remainingTime.Seconds--;
            }

            if (remainingTime.Seconds == 0)
            {
                remainingTime.Seconds = 60;
                remainingTime.Minutes--;
            }
            remainingTime.Sixtieths--;
        }

        public void Reset()
        {
            remainingTime.Sixtieths = 0;
            remainingTime.Minutes = 0;
            remainingTime.Seconds = 0;
        }

        internal void AddSeconds(uint p)
        {
            remainingTime.Seconds += (int)p;
            if (remainingTime.Seconds >= 60)
            {
                remainingTime.Seconds -= 60;
                remainingTime.Minutes++;
            }
        }
    }
}
