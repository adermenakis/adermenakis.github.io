#ifndef HOSTAPINTERFACE_H
#define HOSTAPINTERFACE_H
#include <string>
#include "CommandInterface.h"

class HostAPInterface : public CommandInterface
{
  public:
    HostAPInterface(){}
    virtual void kill();
    virtual void start(std::string config, std::string iface);
    
    static std::string wpa_connection_config(std::string iface, std::string ssid,
					     std::string pass, bool isWPA2, std::string chan);
    
    static std::string noenc_connection_config(std::string iface, std::string ssid,
									std::string chan);
};

#endif // HOSTAPINTERFACE_H
