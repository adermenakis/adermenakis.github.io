#ifndef IFCONFIG_H
#define IFCONFIG_H
#include <string>

class IfConfig
{
  public:
    static void bringUP(std::string iface);
    static void bringDOWN(std::string iface);
    static void setIP(std::string iface, std::string ip);
    static void setCommand(std::string c);
  private:
    static std::string sCmd;
};

#endif // IFCONFIG_H
