#include "StartupWidget.h"

#include <iostream>
#include "DHCPInterface.h"
#include "HostAPInterface.h"
#include <qfile.h>
#include <QTextStream>
#include "NetworkHelpers.h"
#include "IfConfig.h"

void StartupWidget::_populateComboBox(QComboBox* b, std::vector< std::string > &c)
{
  for(int i = 0; i < c.size(); i++)
     b->addItem(c[i].c_str());
}

StartupWidget::StartupWidget(QWidget* parent, Qt::WindowFlags f): QWidget(parent, f)
{
  mIsSharing = false;
  mDHCPServer = new DHCPInterface();
  mHostAP = new HostAPInterface();
  
  setupUi(this);
  std::vector<std::string> ifaces = NetworkHelpers::getNetworkIntefaces();
  _populateComboBox(cmbIfaceFrom, ifaces);
  _populateComboBox(cmbIfaceTo, ifaces);
  
  if(ifaces.size() >= 0)
    cmbIfaceTo->setCurrentIndex(0);
  
  if(ifaces.size() >= 1)
    cmbIfaceTo->setCurrentIndex(1);
  
  connect(btnShare, SIGNAL(pressed()), this, SLOT(__sharing()));
  connect(chkNoEncr, SIGNAL(clicked(bool)), this, SLOT(__toggleEncryption(bool)));
  connect(chkManualNetConfig, SIGNAL(clicked(bool)), this, SLOT(__toggleManualNetConfig(bool)));

  txtDNS->setText(NetworkHelpers::getDNS().c_str());
  mDefaultIPRange = txtIPRange->text().toStdString();
  mDefaultDNS = NetworkHelpers::getDNS();
  mDefaultSubnet = txtSubnet->text().toStdString();
  
  iptables_bin = "/usr/sbin/iptables";
  ifconfig_bin = "/sbin/ifconfig";
  dhcpd_bin = "/usr/sbin/dhcpd";
  hostapd_bin = "/usr/sbin/hostapd";
  
  mDHCPServer->setCommand(dhcpd_bin);
  mHostAP->setCommand(hostapd_bin);
  IfConfig::setCommand(ifconfig_bin);
}

StartupWidget::~StartupWidget()
{

}

void StartupWidget::__sharing()
{
  if(mIsSharing)
  {
    if(chkManualNetConfig->isChecked())
    {
      txtDNS->setEnabled(true);
      txtIPRange->setEnabled(true);
      txtSubnet->setEnabled(true);
    }
    
    txtSSID->setEnabled(true);
    chkManualNetConfig->setEnabled(true);
    if(!chkNoEncr->isChecked())
    {
      chkWPA2->setEnabled(true);
      txtPassword->setEnabled(true);
    }
    
    chkNoEncr->setEnabled(true);
    cmbIfaceFrom->setEnabled(true);
    cmbIfaceTo->setEnabled(true);
    
    btnShare->setText("Start Sharing");
    mHostAP->kill();
    mDHCPServer->kill();
  }
  else
  {
    std::string lIPRange = mDefaultIPRange;
    std::string lDNS = mDefaultDNS;
    std::string lSubnet = mDefaultSubnet;
    
    if(chkManualNetConfig->isChecked())
    {
      lIPRange = txtIPRange->text().toStdString();
      lDNS = txtDNS->text().toStdString();
      lSubnet = txtSubnet->text().toStdString();
    }
    
    NetworkHelpers::enableForwarding(false);
    mHostAP->kill();
    mDHCPServer->kill();
    system((iptables_bin + " -t nat -A POSTROUTING -o " + cmbIfaceFrom->currentText().toStdString() + " -j MASQUERADE").c_str());
    system((iptables_bin + " -A FORWARD -i " + cmbIfaceFrom->currentText().toStdString() + " -o " + cmbIfaceTo->currentText().toStdString() + " -m state \
				  --state RELATED,ESTABLISHED -j ACCEPT").c_str());

    system((iptables_bin + " -A FORWARD -i " + cmbIfaceTo->currentText().toStdString() + " -o " + cmbIfaceFrom->currentText().toStdString() + " -j ACCEPT").c_str());
    NetworkHelpers::enableForwarding(true);
    IfConfig::bringDOWN(cmbIfaceTo->currentText().toStdString());
    IfConfig::bringUP(cmbIfaceTo->currentText().toStdString());
    IfConfig::setIP(cmbIfaceTo->currentText().toStdString(), lIPRange);
  
    txtDNS->setEnabled(false);
    txtPassword->setEnabled(false);
    txtIPRange->setEnabled(false);
    txtSSID->setEnabled(false);
    txtSubnet->setEnabled(false);
    chkManualNetConfig->setEnabled(false);
    chkNoEncr->setEnabled(false);
    chkWPA2->setEnabled(false);
    cmbIfaceFrom->setEnabled(false);
    cmbIfaceTo->setEnabled(false);
    
    std::string lDHCPConfig;
    lDHCPConfig = DHCPInterface::dhcp_config(lIPRange.substr(0,txtIPRange->text().toStdString().find_last_of(".")),
			     lSubnet,
			     lDNS);
    
    std::string lHostAPConfig;
    
    if(chkNoEncr->isChecked())
	lHostAPConfig = HostAPInterface::noenc_connection_config(cmbIfaceTo->currentText().toStdString(),
						    txtSSID->text().toStdString(), "11").c_str();
      else
	lHostAPConfig = HostAPInterface::wpa_connection_config(cmbIfaceTo->currentText().toStdString(),
					    txtSSID->text().toStdString(), txtPassword->text().toStdString(),
					    chkWPA2->isChecked(), "11").c_str();
    
      mDHCPServer->start(lDHCPConfig, cmbIfaceTo->currentText().toStdString());
      mHostAP->start(lHostAPConfig, cmbIfaceTo->currentText().toStdString());
      btnShare->setText("Stop Sharing");
    }
  
  mIsSharing = !mIsSharing;
}

void StartupWidget::__toggleEncryption(bool c)
{
  txtPassword->setEnabled(!c);
  chkWPA2->setEnabled(!c);
}

void StartupWidget::__toggleManualNetConfig(bool c)
{
  txtDNS->setEnabled(c);
  txtIPRange->setEnabled(c);
  txtSubnet->setEnabled(c);
}

#include "StartupWidget.moc"