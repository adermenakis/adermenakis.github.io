#ifndef COMMANDINTERFACE_H
#define COMMANDINTERFACE_H
#include <string>
#include <stdlib.h>

class CommandInterface
{
  public:
    CommandInterface(){}
    
    virtual void kill() = 0;
    virtual void start(std::string config, std::string iface) = 0;
    
    void setCommand(std::string c) { mCmd = c; }
    
  protected:
    std::string mCmd;
};

#endif // COMMANDINTERFACE_H
