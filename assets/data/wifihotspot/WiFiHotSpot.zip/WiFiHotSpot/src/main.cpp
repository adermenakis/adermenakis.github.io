#include <QtGui/QApplication>
#include "StartupWidget.h"


int main(int argc, char** argv)
{
    QApplication app(argc, argv);
    StartupWidget wgt;
    wgt.show();
    return app.exec();
}
