#ifndef DHCPINTERFACE_H
#define DHCPINTERFACE_H
#include <string>
#include "CommandInterface.h"

class DHCPInterface : public CommandInterface
{
  public:
    DHCPInterface(){}
    virtual void kill();
    virtual void start(std::string config, std::string iface);
    
    static std::string dhcp_config(std::string ipRange, std::string subnet,
				   std::string dns);
};

#endif // DHCPINTERFACE_H
