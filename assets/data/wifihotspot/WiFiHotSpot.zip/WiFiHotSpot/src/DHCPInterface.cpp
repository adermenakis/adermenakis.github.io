#include "DHCPInterface.h"
#include <stdlib.h>
#include <qfile.h>
#include <qtextstream.h>

void DHCPInterface::kill()
{
  system("kill dhcpcd");
}

void DHCPInterface::start(std::string config, std::string iface)
{
  QFile dhcp_conf("/tmp/dhcpd.conf");
  dhcp_conf.open(QIODevice::WriteOnly | QIODevice::Text);
  QTextStream out(&dhcp_conf);
  out << config.c_str();
 
  system((mCmd + " -cf /tmp/dhcpd.conf " + iface).c_str());
  // optional, as QFile destructor will already do it:
  dhcp_conf.close(); 
}


std::string DHCPInterface::dhcp_config(std::string ipRange, std::string subnet, std::string dns)
{
  std::string s;
  s = 
"option domain-name-servers " + dns +";\n\
default-lease-time 600;\n\
max-lease-time 7200;\n\
ddns-update-style none; ddns-updates off;\n\
subnet " + ipRange + ".0 netmask " + subnet + " {\n\
        range " + ipRange + ".2 " + ipRange + ".255;\n\
        option subnet-mask " + subnet + ";\n\
        option broadcast-address " + ipRange + ".255;\n\
        option routers " + ipRange + ".1;\n\
}";

return s;

}
