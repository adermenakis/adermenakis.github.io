#include "NetworkHelpers.h"
#include <cstdlib>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <net/ethernet.h>
#include <arpa/nameser.h>
#include <resolv.h>

std::vector< std::string > NetworkHelpers::getNetworkIntefaces()
{
  std::vector<std::string> interfaces;
  
  	char          buf[1024];
	struct ifconf ifc;
	struct ifreq *ifr;
	int           sck;
	int           nInterfaces;
	int           i;

	/* Get a socket handle. */
	sck = socket(AF_INET, SOCK_DGRAM, 0);
	if(sck < 0)
	{
		perror("socket");
	}

	/* Query available interfaces. */
	ifc.ifc_len = sizeof(buf);
	ifc.ifc_buf = buf;
	if(ioctl(sck, SIOCGIFCONF, &ifc) < 0)
	{
		return interfaces;
	}

	/* Iterate through the list of interfaces. */
	ifr         = ifc.ifc_req;
	nInterfaces = ifc.ifc_len / sizeof(struct ifreq);
	for(i = 0; i < nInterfaces; i++)
	{
		struct ifreq *item = &ifr[i];
		std::string strTmp = item->ifr_name;
		if(strTmp != "lo")
		  interfaces.push_back(strTmp);
	}
	
	return interfaces;
}

std::string NetworkHelpers::getDNS()
{
  std::string s;
  if(res_init() == 0)
  {
    for(int i = 0; i < _res.nscount; i++)
    {
      if(i > 0)
	s += ", ";
      s += inet_ntoa(_res.nsaddr_list[i].sin_addr);
    }
  }
  
  return s;
}

void NetworkHelpers::enableForwarding(bool e)
{
  system(("echo " + std::string((e) ? "1" : "0") + " > /proc/sys/net/ipv4/ip_forward").c_str());
}
