#ifndef NETWORKHELPERS_H
#define NETWORKHELPERS_H
#include <vector>
#include <string>

class NetworkHelpers
{
  public:
    static std::vector<std::string> getNetworkIntefaces();
    
    static std::string getDNS();
    
    static void enableForwarding(bool e = true);
};

#endif // NETWORKHELPERS_H
