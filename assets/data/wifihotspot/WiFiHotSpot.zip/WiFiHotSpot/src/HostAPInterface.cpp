#include "HostAPInterface.h"
#include <qfile.h>
#include <qtextstream.h>

using namespace std;

void HostAPInterface::kill()
{
  system("kill hostapd");
}

void HostAPInterface::start(string config, string iface)
{
  QFile dhcp_conf("/tmp/hostapd.conf");
  dhcp_conf.open(QIODevice::WriteOnly | QIODevice::Text);
  QTextStream out(&dhcp_conf);
  out << config.c_str();
 
  system((mCmd + " -B /tmp/hostapd.conf").c_str());
  // optional, as QFile destructor will already do it:
  dhcp_conf.close(); 
}


std::string HostAPInterface::noenc_connection_config(std::string iface, std::string ssid, std::string chan)
{
  std::string s;
  s = 
"\n\
auth_algs=1\n\
interface=" + iface + "\n\
driver=nl80211\n\
ssid=" + ssid + "\n\
hw_mode=g\n\
channel=" + chan +"\n\
wpa=0\n\
";

return s;
}

std::string HostAPInterface::wpa_connection_config(std::string iface, std::string ssid, std::string pass, bool isWPA2, std::string chan)
{
  std::string s;
  s = 
"\
interface=" + iface + "\n\
driver=nl80211\n\
ssid=" + ssid + "\n\
hw_mode=g\n\
channel=" + chan +"\n\
wpa=" + ((isWPA2) ? string("2") : string("1")) + "\n\
wpa_passphrase=" + pass + "\n\
wpa_key_mgmt=WPA-PSK\n\
wpa_pairwise=TKIP CCMP\n\
wpa_ptk_rekey=600\n\
";

return s;
}
