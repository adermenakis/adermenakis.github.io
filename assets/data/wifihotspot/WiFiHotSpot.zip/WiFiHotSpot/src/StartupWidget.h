#ifndef STARTUPWIDGET_H
#define STARTUPWIDGET_H

#include "ui_StartupWidget.h"

class HostAPInterface;
class DHCPInterface;
class StartupWidget : public QWidget, public Ui::StartupWidget
{
  Q_OBJECT
  public:
    StartupWidget(QWidget* parent = 0, Qt::WindowFlags f = 0);
    virtual ~StartupWidget();
    
  private:
    static void _populateComboBox(QComboBox* b, std::vector<std::string> &c);
    
    bool mIsSharing;
    std::string iptables_bin;
    std::string hostapd_bin;
    std::string ifconfig_bin;
    std::string dhcpd_bin;
    
    std::string mDefaultIPRange;
    std::string mDefaultDNS;
    std::string mDefaultSubnet;
    
    DHCPInterface *mDHCPServer;
    HostAPInterface *mHostAP;
  private slots:
    void __toggleManualNetConfig(bool c);
    void __toggleEncryption(bool c);
    void __sharing();
};

#endif // STARTUPWIDGET_H
