#include "IfConfig.h"
#include <stdlib.h>

std::string IfConfig::sCmd = "/sbin/ifconfig";

void IfConfig::bringDOWN(std::string iface)
{
  system((sCmd + " " + iface + " down").c_str());
}

void IfConfig::bringUP(std::string iface)
{
  system((sCmd + " " + iface + " up").c_str());
}

void IfConfig::setIP(std::string iface, std::string ip)
{
  system((sCmd + " " + iface + " " + ip).c_str()); 
}

void IfConfig::setCommand(std::string c)
{
  sCmd = c;
}